## FerretEntity.gd
class_name FerretEntity
extends RefCounted

const FIRST_NAMES: Array = ["Freddy","Fido","Fiona","Franz","Frieda","Felix","Frida","Frank","Finn","Flora","Frodo","Franzi","Filou","Feli","Fips"]
const LAST_NAMES: Array  = ["Frettchen","Pfote","Flausch","Fell","Schnueffel","Huepfer","Schwanz","Nase","Kralle","Zahn"]

# ── Feature (v10.10): Frettchen gehen jetzt tatsaechlich zu ihrem Arbeitsplatz
# bzw. zu einer Ressourcenquelle, statt nur zufaellig durch die Karte zu
# wandern. Bei Sammel-Gebaeuden (COLLECTOR mit WOOD/STONE/BERRIES/IRON) pendeln
# sie zwischen Gebaeude und einer konkreten, im Tile gespeicherten
# Resource-Node hin und her, "ernten" sie dort (sichtbar als kurze Pause +
# Wipp-Animation in WorldRenderer3D, siehe harvest_anim_t) und die Quelle
# verliert dabei "amount" - bis sie erschoepft ist und eine Zeit lang
# regenerieren muss (siehe WorldGenerator.tick_resource_nodes).
const NODE_RESOURCE_TYPES: Array = ["WOOD", "STONE", "BERRIES", "IRON"]
const HARVEST_DURATION: float = 3.0   # Sekunden pro Ernte-Aktion an einer Quelle
const HARVEST_AMOUNT:   float = 18.0  # wie viel "amount" eine Ernte-Aktion abbaut

var ferret_name: String = ""
var health: float = 100.0
var needs: Dictionary = {"food": 60.0, "water": 60.0, "happiness": 60.0}
var assigned_building = null
var current_construction_site = null
var home = null
var specialization: String = ""
var spec_days: float = 0.0
var age_days: float = 0.0
var is_alive: bool = true
var pos: Vector2 = Vector2.ZERO
var target_pos: Vector2 = Vector2.ZERO
var move_speed: float = 2.0   # Tiles pro Sekunde

# ── Arbeits-/Ernte-Zustand (nicht persistiert, baut sich nach dem Laden von
# selbst wieder auf, genau wie assigned_building) ────────────────────────────
var work_state: String = "IDLE"        # IDLE, TO_BUILDING, WORKING, TO_NODE, HARVESTING, RETURN
var harvest_tile: Vector2i = Vector2i(-1, -1)
var work_timer: float = 0.0
var harvest_anim_t: float = 0.0        # Lese-Flag fuer den Renderer (Wipp-Animation)
# Feature (v10.11): generische, kontinuierlich laufende "Arbeits-Uhr" -
# zaehlt waehrend der gesamten Zeit am Gebaeude (work_state == "WORKING")
# hoch, im Gegensatz zu harvest_anim_t, das nur waehrend des Node-Pendelns
# (work_state == "HARVESTING") laeuft. Wird z.B. von WaterCollectAnimation
# genutzt, da Wasser-Gebaeude keine physischen Resource-Nodes zum Pendeln
# haben und stattdessen direkt am Gebaeude "arbeiten".
var work_anim_t: float = 0.0

# ── Feature (v10.13): Schlafzyklus ───────────────────────────────────────────
# Nachts (DayNight.is_day == false) unterbrechen alle Frettchen ihre Arbeit
# und gehen schlafen: mit zugewiesenem Haus (siehe `home`) laufen sie dort
# hin, ohne Haus legen sie sich einfach dort hin, wo sie gerade stehen ("auf
# dem Boden schlafen"). is_sleeping wird true, sobald das Ziel erreicht ist;
# der Renderer nutzt das fuer eine liegende Pose + langsames Atem-Wippen.
var is_sleeping: bool = false
var sleep_anim_t: float = 0.0

# ── Feature (v10.13): Bau-Frettchen gehen jetzt zur Baustelle ───────────────
# Frettchen, die einem BUILDER-Gebaeude (Bauhof) zugewiesen sind, suchen sich
# eine aktive Baustelle im Umkreis (siehe BUILDER_SEARCH_RANGE) und laufen
# dort hin, statt nur am Bauhof zu stehen. construction_site zeigt auf die
# BuildingEntity, an der gerade gebaut wird - GameController._process_construction()
# zaehlt darueber pro Baustelle, wie viele Frettchen tatsaechlich vor Ort
# sind, und skaliert den Baufortschritt entsprechend (siehe dort).
var construction_site = null
const BUILDER_SEARCH_RANGE: float = 50.0

# ── Feature (v11.0, Timberborn-Lagersystem) ─────────────────────────────────
# Jedes Frettchen hat jetzt ein simuliertes Inventar mit fester Tragekapazitaet
# (gleich fuer ALLE Frettchen, siehe Nutzeranfrage). Genutzt von drei Rollen:
#  1) Produktions-Arbeiter, die das volle lokale Lager ihres Gebaeudes zu
#     einem Lagerhaus tragen (work_state HAUL_TO_WAREHOUSE/HAUL_RETURN)
#  2) Bau-Frettchen, die fehlendes Baumaterial vom naechsten Lagerhaus zur
#     Baustelle tragen (FETCH_TO_WAREHOUSE/FETCH_TO_SITE)
#  3) Lagerarbeiter (Frettchen in einem Lagerhaus-Gebaeude), die proaktiv
#     Produktionsgebaeude abklappern UND Material zu Baustellen liefern
#     (WH_TO_SOURCE/WH_TO_WAREHOUSE/WH_TO_SITE)
const CARRY_CAPACITY: float = 30.0
var carry_inventory: Dictionary = {}
var haul_target = null
const WAREHOUSE_SEARCH_RANGE: float = 70.0

# Feature (v11.1, Betten): Frettchen ohne eigenes Bett (home == null) werden
# zusaetzlich zur normalen Abklingrate unglücklicher - macht ausreichenden
# Wohnraum zu einer echten strategischen Notwendigkeit statt nur einer netten
# Option fuer schnelleres Wachstum.
const HOMELESS_HAPPINESS_PENALTY: float = 0.3

## Feature (Tech Tree): effektive Tragkraft/Suchradius inkl. globaler Boni aus
## dem Themenbereich "Bauwesen & Logistik" (siehe TechTree.gd). Ersetzt die
## direkte Verwendung der CARRY_CAPACITY/WAREHOUSE_SEARCH_RANGE Konstanten an
## allen Stellen unten.
func get_carry_capacity() -> float:
	return CARRY_CAPACITY + TechTreeSys.get_global_bonus("carry_capacity_bonus")

func get_warehouse_search_range() -> float:
	return WAREHOUSE_SEARCH_RANGE + TechTreeSys.get_global_bonus("warehouse_search_range_bonus")

## Feature (Tech Tree): "Schnelle Fuesse" (LOGISTICS) erhoeht das Lauftempo
## aller Frettchen global.
func get_effective_move_speed() -> float:
	return move_speed * (1.0 + TechTreeSys.get_global_bonus("move_speed_bonus"))

static func create_random() -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = FIRST_NAMES[randi() % FIRST_NAMES.size()] + " " + LAST_NAMES[randi() % LAST_NAMES.size()]
	f.health = randf_range(80.0, 100.0)
	f.move_speed = randf_range(1.5, 2.8)
	f.needs = {
		"food": randf_range(50.0, 80.0),
		"water": randf_range(50.0, 80.0),
		"happiness": randf_range(40.0, 70.0)
	}
	# Startposition: isometrische Weltkoordinaten nahe Karte-Mitte (Tile 30,30)
	# tile_to_world(30,30) = (0, 2880) — wir randomisieren etwas drumherum
	f.pos = Vector2(30.0 + randf_range(-4.0, 4.0), 30.0 + randf_range(-4.0, 4.0))
	f.target_pos = f.pos
	return f

func update(dt: float, world: Array = [], is_day: bool = true) -> void:
	age_days += dt / 60.0
	# Feature (Tech Tree): "Ausdauertraining" (BREEDING) laesst die Grund-
	# beduerfnisse global langsamer absinken.
	var decay_mult: float = 1.0 - clampf(TechTreeSys.get_global_bonus("needs_decay_reduction"), 0.0, 0.9)
	needs["food"] = maxf(0.0, float(needs["food"]) - dt * 0.8 * decay_mult)
	needs["water"] = maxf(0.0, float(needs["water"]) - dt * 1.1 * decay_mult)
	needs["happiness"] = maxf(0.0, float(needs["happiness"]) - dt * 0.4 * decay_mult)
	# Feature (v11.1, Betten): kein eigenes Bett -> zusaetzlicher Gluecksverlust.
	# Schlaeft ein Frettchen "auf dem Boden" (siehe _update_sleep()), spuert es
	# das staerker als eines mit eigenem Bett im Wohnhaus.
	if home == null:
		# Feature (Tech Tree): "Waermende Decken" (BREEDING) lindert diesen
		# Zusatzverlust.
		var penalty_mult: float = 1.0 - clampf(TechTreeSys.get_global_bonus("homeless_penalty_reduction"), 0.0, 0.9)
		needs["happiness"] = maxf(0.0, float(needs["happiness"]) - dt * HOMELESS_HAPPINESS_PENALTY * penalty_mult)
	var avg: float = (float(needs["food"]) + float(needs["water"])) / 2.0
	# Feature (v10.13): "zumindest am Anfang nicht so schnell sterben" - am
	# allerersten Tag (DayNight.day_count == 0) verursachen Hunger/Durst noch
	# KEINEN Gesundheitsschaden. Die Bedürfnis-Werte selbst sinken weiterhin
	# normal (sichtbar in der UI, motiviert schnell zu bauen), aber die
	# Kolonie bekommt einen vollen Tag Vorlauf, um die erste Nahrungs-/
	# Wasserproduktion aufzubauen, bevor das erste Frettchen sterben kann.
	# Feature (Tech Tree): "Gesunde Ernaehrung"/"Meister der Zucht" (BREEDING)
	# beschleunigen die Erholung bzw. verlangsamen den Gesundheitsverfall.
	var regen_bonus: float = TechTreeSys.get_global_bonus("health_regen_bonus")
	var mortality_mult: float = 1.0 - clampf(TechTreeSys.get_global_bonus("mortality_reduction"), 0.0, 0.9)
	if DayNight.day_count > 0:
		if avg < 20.0:
			health = maxf(0.0, health - dt * (20.0 - avg) * 0.1 * mortality_mult)
		elif avg > 60.0:
			health = minf(100.0, health + dt * (0.5 + regen_bonus))
	elif avg > 60.0:
		health = minf(100.0, health + dt * (0.5 + regen_bonus))

	if not is_day:
		_update_sleep(dt)
		return
	is_sleeping = false
	sleep_anim_t = 0.0

	if assigned_building != null:
		var ab: BuildingEntity = assigned_building
		if not ab.is_under_construction:
			spec_days += dt / 60.0
			if spec_days >= 5.0 and specialization != ab.btype:
				specialization = ab.btype
	else:
		spec_days = 0.0
	_update_work(dt, world)

## Nachts: zum zugewiesenen Haus laufen und dort schlafen, oder - falls kein
## Haus zugewiesen ist - einfach an der aktuellen Position liegen bleiben.
func _update_sleep(dt: float) -> void:
	work_state = "SLEEPING"
	harvest_anim_t = 0.0
	work_anim_t = 0.0
	var target: Vector2 = pos
	if home != null:
		var hb: BuildingEntity = home
		target = Vector2(float(hb.tile_x) + 0.5, float(hb.tile_y) + 0.5)
	if is_sleeping:
		sleep_anim_t += dt
		return
	if _move_toward(target, dt):
		is_sleeping = true
		sleep_anim_t = 0.0

## Bewegt pos einen Schritt Richtung target und haelt target_pos synchron, da
## WorldRenderer3D daraus die Blickrichtung des Frettchens berechnet
## (fe.target_pos - fe.pos).
func _move_toward(target: Vector2, dt: float) -> bool:
	target_pos = target
	var diff: Vector2 = target - pos
	if diff.length() < 0.08:
		pos = target
		return true
	pos += diff.normalized() * get_effective_move_speed() * dt
	return false

func _wander(dt: float) -> void:
	var diff: Vector2 = target_pos - pos
	if diff.length() < 0.15:
		target_pos = pos + Vector2(randf_range(-3.5, 3.5), randf_range(-3.5, 3.5))
	else:
		pos += diff.normalized() * get_effective_move_speed() * dt

func _update_work(dt: float, world: Array) -> void:
	harvest_anim_t = 0.0
	if assigned_building == null:
		work_state = "IDLE"
		harvest_tile = Vector2i(-1, -1)
		work_anim_t = 0.0
		construction_site = null
		_wander(dt)
		return
	var ab: BuildingEntity = assigned_building
	if ab.is_under_construction:
		work_anim_t = 0.0
		construction_site = null
		_wander(dt)
		return

	var building_pos: Vector2 = Vector2(float(ab.tile_x) + 0.5, float(ab.tile_y) + 0.5)

	if ab.btype == "BUILDER":
		_update_builder_work(dt, building_pos)
		return

	# Feature (v11.0): Frettchen in einem Lagerhaus ("Lagerarbeiter") holen
	# proaktiv Ressourcen aus nahen Produktionsgebaeuden und liefern Material
	# an Baustellen - komplett eigene Logik, siehe _update_warehouse_work().
	if ab.btype == "STORAGE" and ab.storage_capacity > 0.0:
		_update_warehouse_work(dt, ab, building_pos)
		return

	# Feature (v11.0): ist das lokale Lager dieses Produktionsgebaeudes voll
	# und traegt noch kein anderes zugewiesenes Frettchen gerade ab, wird
	# DIESES Frettchen zum Traeger - es produziert in der Zeit nichts (siehe
	# BuildingEntity.get_active_worker_count()).
	if work_state == "HAUL_TO_WAREHOUSE" or work_state == "HAUL_RETURN":
		_update_haul_work(dt, ab, building_pos)
		return
	if work_state == "WORKING" and ab.local_storage_capacity > 0.0 \
			and ab.is_local_storage_full() and not ab.has_hauler():
		var haul_res: String = "" if ab.local_storage.is_empty() else str(ab.local_storage.keys()[0])
		var wh: BuildingEntity = _find_nearest_storage_building(building_pos, haul_res)
		if wh != null:
			haul_target = wh
			_pickup_from_building(ab, wh.storage_filter)
			work_state = "HAUL_TO_WAREHOUSE"
			_update_haul_work(dt, ab, building_pos)
			return

	var is_node_collector: bool = (ab.btype == "COLLECTOR"
		and ab.collects_resource in NODE_RESOURCE_TYPES)

	if not is_node_collector:
		# Einfacher Fall (Werkstaetten, Bauernhoefe, Brunnen, ...): das
		# Frettchen geht ins/zum Gebaeude und bleibt dort "drinnen" stehen,
		# waehrend die eigentliche Produktion ueber den Gebaeude-Timer laeuft.
		if work_state != "WORKING" and work_state != "TO_BUILDING":
			work_state = "TO_BUILDING"
		if _move_toward(building_pos, dt):
			work_state = "WORKING"
			work_anim_t += dt
		else:
			work_anim_t = 0.0
		return

	# Sammel-Gebaeude mit physischen Ressourcen-Quellen im Terrain: zwischen
	# Gebaeude und Quelle hin- und herpendeln.
	match work_state:
		"TO_NODE":
			var target: Vector2 = Vector2(float(harvest_tile.x) + 0.5, float(harvest_tile.y) + 0.5)
			if _node_still_valid(world):
				if _move_toward(target, dt):
					work_state = "HARVESTING"
					work_timer = 0.0
			else:
				work_state = "WORKING"
		"HARVESTING":
			work_timer += dt
			harvest_anim_t = work_timer
			if work_timer >= HARVEST_DURATION:
				_finish_harvest(world)
				work_state = "RETURN"
		"RETURN":
			if _move_toward(building_pos, dt):
				work_state = "WORKING"
		_:
			var node_tile: Vector2i = _find_harvestable_node(world, ab)
			if node_tile.x >= 0:
				harvest_tile = node_tile
				work_state = "TO_NODE"
			else:
				# Keine erntbare Quelle in der Naehe (alle gerade erschoepft) -
				# am Gebaeude warten, bis wieder eine verfuegbar ist.
				work_state = "WORKING"
				_move_toward(building_pos, dt)

## Feature (v10.13): Frettchen, die einem Bauhof (btype "BUILDER") zugewiesen
## sind, suchen sich eine aktive Baustelle im Umkreis und laufen dorthin,
## statt nur am Bauhof zu stehen. Die tatsaechliche Fortschritts-Berechnung
## (abhaengig davon, wie viele Frettchen GERADE an einer Baustelle stehen)
## passiert zentral in GameController._process_construction(), die dafuer
## ueber alle Frettchen mit work_state == "BUILDING" iteriert.
##
## Feature (v11.0, Lagersystem): bevor ueberhaupt gebaut werden kann, muss das
## komplette Baumaterial an der Baustelle liegen (siehe BuildingEntity.
## is_fully_supplied()). Fehlt noch etwas, holt das Bau-Frettchen es zuerst
## vom naechsten Lagerhaus (FETCH_TO_WAREHOUSE/FETCH_TO_SITE), bevor es
## ueberhaupt in den eigentlichen "BUILDING"-Zustand wechselt.
func _update_builder_work(dt: float, yard_pos: Vector2) -> void:
	match work_state:
		"TO_SITE":
			if construction_site == null or not is_instance_valid(construction_site) or not (construction_site as BuildingEntity).is_under_construction:
				construction_site = null
				work_state = "WORKING"
				return
			var site: BuildingEntity = construction_site
			var target: Vector2 = Vector2(float(site.tile_x) + 0.5, float(site.tile_y) + 0.5)
			if site.is_fully_supplied():
				if _move_toward(target, dt):
					work_state = "BUILDING"
					work_anim_t = 0.0
			else:
				_try_start_material_fetch(dt, site, target)
		"FETCH_TO_WAREHOUSE":
			if haul_target == null or not is_instance_valid(haul_target) or construction_site == null or not is_instance_valid(construction_site):
				haul_target = null; work_state = "TO_SITE"; return
			var wh: BuildingEntity = haul_target
			if _move_toward(Vector2(float(wh.tile_x) + 0.5, float(wh.tile_y) + 0.5), dt):
				_pickup_resource_for_site(wh, construction_site)
				work_state = "FETCH_TO_SITE"
		"FETCH_TO_SITE":
			if construction_site == null or not is_instance_valid(construction_site):
				_deposit_inventory_to_resourcesys()
				work_state = "WORKING"; return
			var site3: BuildingEntity = construction_site
			if _move_toward(Vector2(float(site3.tile_x) + 0.5, float(site3.tile_y) + 0.5), dt):
				_deliver_inventory_to_site(site3)
				work_state = "TO_SITE"
		"BUILDING":
			if construction_site == null or not is_instance_valid(construction_site) or not (construction_site as BuildingEntity).is_under_construction:
				construction_site = null
				work_state = "WORKING"
			else:
				work_anim_t += dt
		_:
			construction_site = null
			var site2: BuildingEntity = _find_construction_site(yard_pos)
			if site2 != null:
				construction_site = site2
				work_state = "TO_SITE"
			else:
				# Kein aktives Bauprojekt - am Bauhof warten
				work_state = "WORKING"
				_move_toward(yard_pos, dt)

## Sucht eine zufaellige, aktuell im Bau befindliche Baustelle im Umkreis von
## BUILDER_SEARCH_RANGE Tiles um den Bauhof.
func _find_construction_site(yard_pos: Vector2) -> BuildingEntity:
	var candidates: Array = []
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if not be.is_under_construction: continue
		var d: float = yard_pos.distance_to(Vector2(float(be.tile_x), float(be.tile_y)))
		if d <= BUILDER_SEARCH_RANGE:
			candidates.append(be)
	if candidates.is_empty(): return null
	return candidates[randi() % candidates.size()]

## Feature (v11.0): entscheidet, ob ein Bau-Frettchen jetzt los soll, um
## fehlendes Material vom naechsten Lagerhaus zu holen, oder ob es lieber an
## der Baustelle wartet (kein Lagerhaus vorhanden, oder die fehlende
## Ressource ist nirgends im Lagernetzwerk verfuegbar - sinnloses Hin- und
## Herlaufen waere sonst die Folge).
func _try_start_material_fetch(dt: float, site: BuildingEntity, site_target: Vector2) -> void:
	var res: String = _pick_missing_resource(site)
	if res == "":
		_move_toward(site_target, dt)
		return
	var avail: float = float(ResourceSys.resources.get(res, 0.0))
	if avail <= 0.01:
		_move_toward(site_target, dt)
		return
	var wh: BuildingEntity = _find_nearest_storage_building(site_target, res)
	if wh == null:
		_move_toward(site_target, dt)
		return
	haul_target = wh
	work_state = "FETCH_TO_WAREHOUSE"

## Erstes noch fehlendes Material einer Baustelle (Reihenfolge der costs-Keys).
func _pick_missing_resource(site: BuildingEntity) -> String:
	for res in site.costs:
		if site.get_missing_amount(str(res)) > 0.01:
			return str(res)
	return ""

@warning_ignore("unused_parameter")
func _pickup_resource_for_site(wh: BuildingEntity, site: BuildingEntity) -> void:
	var res: String = _pick_missing_resource(site)
	if res == "": return
	var need: float = site.get_missing_amount(res)
	var avail: float = float(ResourceSys.resources.get(res, 0.0))
	var take: float = minf(get_carry_capacity(), minf(need, avail))
	if take > 0.0:
		ResourceSys.remove(res, take)
		carry_inventory[res] = float(carry_inventory.get(res, 0.0)) + take

func _deliver_inventory_to_site(site: BuildingEntity) -> void:
	for res in carry_inventory.keys().duplicate():
		site.deliver_resource(str(res), float(carry_inventory[res]))
	carry_inventory.clear()

func _deposit_inventory_to_resourcesys() -> void:
	for res in carry_inventory.keys().duplicate():
		ResourceSys.add(str(res), float(carry_inventory[res]))
	carry_inventory.clear()

## Nimmt bis zu CARRY_CAPACITY aus dem lokalen Lager eines Gebaeudes auf
## (genutzt sowohl vom selbst-abtragenden Produktions-Arbeiter als auch vom
## Lagerarbeiter, der fremde Gebaeude abklappert). Optionaler filter_res
## (v11.1, Lagerhaus-Spezialisierung): ist er gesetzt, wird NUR diese eine
## Ressource aufgenommen - relevant, wenn das Zieleagerhaus auf einen
## bestimmten Rohstoff spezialisiert ist und andere im lokalen Lager liegende
## Resten nicht mitgenommen werden sollen.
func _pickup_from_building(src: BuildingEntity, filter_res: String = "") -> void:
	var amt_taken: float = 0.0
	for res in src.local_storage.keys().duplicate():
		if amt_taken >= get_carry_capacity(): break
		if filter_res != "" and str(res) != filter_res: continue
		var avail: float = float(src.local_storage[res])
		var take: float = minf(avail, get_carry_capacity() - amt_taken)
		if take > 0.0:
			carry_inventory[res] = float(carry_inventory.get(res, 0.0)) + take
			src.local_storage[res] = avail - take
			if float(src.local_storage[res]) <= 0.001:
				src.local_storage.erase(res)
			amt_taken += take

## Feature (v11.1, Logistik-Feinschliff): "res" optional - wird ein
## Ressourcentyp angegeben, werden Lagerhaeuser mit einer Spezialisierung auf
## eine ANDERE Ressource (storage_filter) uebersprungen (siehe
## BuildingEntity.accepts_resource()). Ohne Angabe (res == "") zaehlt nur die
## Distanz, wie bisher.
func _find_nearest_storage_building(from_pos: Vector2, res: String = "") -> BuildingEntity:
	var best: BuildingEntity = null
	var best_d: float = INF
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if be.btype != "STORAGE" or be.is_under_construction or be.storage_capacity <= 0.0: continue
		if res != "" and not be.accepts_resource(res): continue
		var d: float = from_pos.distance_to(Vector2(float(be.tile_x), float(be.tile_y)))
		if d < best_d:
			best_d = d; best = be
	return best

## Feature (v11.0): ein Produktions-Arbeiter, dessen Gebaeude-Lager voll ist,
## traegt es selbst zum naechsten Lagerhaus - waehrenddessen produziert er
## nichts (siehe BuildingEntity.get_active_worker_count()).
@warning_ignore("unused_parameter")
func _update_haul_work(dt: float, ab: BuildingEntity, building_pos: Vector2) -> void:
	if haul_target == null or not is_instance_valid(haul_target):
		carry_inventory.clear(); haul_target = null; work_state = "WORKING"; return
	work_anim_t += dt
	var wh: BuildingEntity = haul_target
	match work_state:
		"HAUL_TO_WAREHOUSE":
			if _move_toward(Vector2(float(wh.tile_x) + 0.5, float(wh.tile_y) + 0.5), dt):
				_deposit_inventory_to_resourcesys()
				work_state = "HAUL_RETURN"
		"HAUL_RETURN":
			if _move_toward(building_pos, dt):
				haul_target = null
				work_state = "WORKING"

## Feature (v11.0): Frettchen, die einem Lagerhaus zugewiesen sind
## ("Lagerarbeiter"). Zwei Aufgaben, geprueft in dieser Reihenfolge:
##  1) liegt eine Baustelle mit fehlendem, im Lagernetzwerk verfuegbarem
##     Material in Reichweite - Material direkt vom Lager zur Baustelle tragen
##  2) sonst: nahes Produktionsgebaeude mit gefuelltem lokalem Lager abklappern
##     und dessen Bestand ins Lagerhaus bringen
func _update_warehouse_work(dt: float, wh: BuildingEntity, wh_pos: Vector2) -> void:
	match work_state:
		"WH_TO_SOURCE":
			if haul_target == null or not is_instance_valid(haul_target) \
					or (haul_target as BuildingEntity).get_local_storage_total() <= 0.0:
				haul_target = null; work_state = "WORKING"; return
			var src: BuildingEntity = haul_target
			work_anim_t += dt
			if _move_toward(Vector2(float(src.tile_x) + 0.5, float(src.tile_y) + 0.5), dt):
				_pickup_from_building(src, wh.storage_filter)
				work_state = "WH_TO_WAREHOUSE"
		"WH_TO_WAREHOUSE":
			work_anim_t += dt
			if _move_toward(wh_pos, dt):
				_deposit_inventory_to_resourcesys()
				haul_target = null
				work_state = "WORKING"
		"WH_TO_SITE":
			if haul_target == null or not is_instance_valid(haul_target) \
					or not (haul_target as BuildingEntity).is_under_construction:
				_deposit_inventory_to_resourcesys()
				haul_target = null; work_state = "WORKING"; return
			var site: BuildingEntity = haul_target
			work_anim_t += dt
			if _move_toward(Vector2(float(site.tile_x) + 0.5, float(site.tile_y) + 0.5), dt):
				_deliver_inventory_to_site(site)
				haul_target = null
				work_state = "WORKING"
		_:
			work_anim_t = 0.0
			_move_toward(wh_pos, dt)
			if not carry_inventory.is_empty(): return
			var site_needs: BuildingEntity = _find_site_needing_materials(wh_pos)
			if site_needs != null:
				var res: String = _pick_missing_resource(site_needs)
				# Feature (v11.1): ein spezialisiertes Lagerhaus liefert nur
				# noch die Ressource, auf die es spezialisiert ist.
				if res != "" and wh.accepts_resource(res):
					var need: float = site_needs.get_missing_amount(res)
					var avail: float = float(ResourceSys.resources.get(res, 0.0))
					var take: float = minf(get_carry_capacity(), minf(need, avail))
					if take > 0.0:
						ResourceSys.remove(res, take)
						carry_inventory[res] = take
						haul_target = site_needs
						work_state = "WH_TO_SITE"
						return
			var src2: BuildingEntity = _find_building_to_collect(wh_pos, wh)
			if src2 != null:
				haul_target = src2
				work_state = "WH_TO_SOURCE"

func _find_site_needing_materials(from_pos: Vector2) -> BuildingEntity:
	var best: BuildingEntity = null
	var best_d: float = INF
	for b in BuildingSys.get_construction_sites():
		var be: BuildingEntity = b
		if be.is_fully_supplied(): continue
		var d: float = from_pos.distance_to(Vector2(float(be.tile_x), float(be.tile_y)))
		if d <= get_warehouse_search_range() and d < best_d:
			best_d = d; best = be
	return best

## Feature (v11.1, Logistik-Feinschliff): ist das Lagerhaus "wh" auf eine
## Ressource spezialisiert, werden Produktionsgebaeude uebersprungen, deren
## lokales Lager NICHTS von dieser Ressource enthaelt - sonst wuerde der
## Lagerarbeiter dort sinnlos ankommen und nichts mitnehmen koennen.
func _find_building_to_collect(from_pos: Vector2, wh: BuildingEntity) -> BuildingEntity:
	var best: BuildingEntity = null
	var best_d: float = INF
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if be.is_under_construction or be.local_storage_capacity <= 0.0: continue
		if be.get_local_storage_total() <= 0.5: continue
		if wh.storage_filter != "" and not be.local_storage.has(wh.storage_filter): continue
		var d: float = from_pos.distance_to(Vector2(float(be.tile_x), float(be.tile_y)))
		if d <= get_warehouse_search_range() and d < best_d:
			best_d = d; best = be
	return best

func _node_still_valid(world: Array) -> bool:
	var nd: Dictionary = _get_node_dict(world, harvest_tile)
	if nd.is_empty(): return false
	if bool(nd.get("depleted", false)): return false
	return float(nd.get("amount", 0.0)) > 0.5

func _get_node_dict(world: Array, t: Vector2i) -> Dictionary:
	if t.x < 0 or t.x >= world.size(): return {}
	var col: Array = world[t.x]
	if t.y < 0 or t.y >= col.size(): return {}
	var tile: Dictionary = col[t.y]
	var nd = tile.get("resource_node")
	if nd == null or not (nd is Dictionary): return {}
	return nd

## Sucht eine zufaellige, aktuell erntbare Resource-Node desselben Typs wie
## `ab.collects_resource` im Sammelradius des Gebaeudes.
func _find_harvestable_node(world: Array, ab: BuildingEntity) -> Vector2i:
	var candidates: Array = []
	var r: int = ab.collection_radius
	var bx: int = ab.tile_x
	var by: int = ab.tile_y
	var ww: int = world.size()
	for dx in range(-r, r + 1):
		var tx: int = bx + dx
		if tx < 0 or tx >= ww: continue
		var col: Array = world[tx]
		var hh: int = col.size()
		for dy in range(-r, r + 1):
			var ty: int = by + dy
			if ty < 0 or ty >= hh: continue
			var nd: Dictionary = _get_node_dict(world, Vector2i(tx, ty))
			if nd.is_empty(): continue
			if str(nd.get("type", "")) != ab.collects_resource: continue
			if bool(nd.get("depleted", false)): continue
			if float(nd.get("amount", 0.0)) <= 1.0: continue
			candidates.append(Vector2i(tx, ty))
	if candidates.is_empty(): return Vector2i(-1, -1)
	return candidates[randi() % candidates.size()]

## Baut die geerntete Quelle ab; wird sie leer, gilt sie als "depleted" und
## braucht danach Zeit zum Regenerieren (siehe WorldGenerator.tick_resource_nodes).
func _finish_harvest(world: Array) -> void:
	var nd: Dictionary = _get_node_dict(world, harvest_tile)
	if nd.is_empty(): return
	var amt: float = float(nd.get("amount", 0.0)) - HARVEST_AMOUNT
	if amt <= 0.0:
		nd["amount"] = 0.0
		nd["depleted"] = true
		nd["regen_timer"] = 0.0
	else:
		nd["amount"] = amt

func get_happiness() -> float:
	return float(needs["happiness"])

func serialize() -> Dictionary:
	return {
		"name": ferret_name, "health": health,
		"needs": needs.duplicate(), "age_days": age_days,
		"specialization": specialization, "spec_days": spec_days,
		"pos_x": pos.x, "pos_y": pos.y
	}

static func deserialize(data: Dictionary) -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = str(data.get("name", "Unbekannt"))
	f.health = float(data.get("health", 100.0))
	var n = data.get("needs", {"food": 60.0, "water": 60.0, "happiness": 60.0})
	f.needs = (n as Dictionary).duplicate()
	f.age_days = float(data.get("age_days", 0.0))
	f.specialization = str(data.get("specialization", ""))
	f.spec_days = float(data.get("spec_days", 0.0))
	# Pos: ältere Saves hatten Pixel-Koordinaten (~2880) – sicher auf Tile-Range clampen
	var raw_x: float = float(data.get("pos_x", 30.0))
	var raw_y: float = float(data.get("pos_y", 30.0))
	# Heuristik: Pixel-Koordinaten > 200 stammen aus altem Format
	if absf(raw_x) > 200.0 or absf(raw_y) > 200.0:
		raw_x = 30.0 + randf_range(-3.0, 3.0)
		raw_y = 30.0 + randf_range(-3.0, 3.0)
	f.pos = Vector2(raw_x, raw_y)
	f.target_pos = f.pos
	return f

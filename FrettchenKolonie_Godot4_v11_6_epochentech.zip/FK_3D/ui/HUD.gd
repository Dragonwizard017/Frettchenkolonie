## HUD.gd - Ressourcen, Zeit, Saison, Buttons
extends Control

# Alle Referenzen per get_node_or_null - kompatibel mit programmatischem Aufbau
var _resource_display: HBoxContainer = null
var _time_label: Label = null
var _season_label: Label = null
var _drought_label: Label = null
var _pop_label: Label = null
var _storage_bar: ProgressBar = null
var _water_bar: ProgressBar = null
var _storage_text: Label = null
var _water_text: Label = null
var _beds_text: Label = null
var _science_text: Label = null

func _ready() -> void:
	_resource_display = get_node_or_null("TopBar/ResourceDisplay")
	_time_label       = get_node_or_null("TopBar/TimeLabel")
	_season_label     = get_node_or_null("TopBar/SeasonLabel")
	_drought_label    = get_node_or_null("TopBar/DroughtLabel")
	_pop_label        = get_node_or_null("TopBar/PopLabel")
	_storage_bar      = get_node_or_null("TopBar/StorageBar")
	_water_bar        = get_node_or_null("TopBar/WaterBar")
	_storage_text     = get_node_or_null("TopBar/StorageTextLabel")
	_water_text       = get_node_or_null("TopBar/WaterTextLabel")
	_beds_text        = get_node_or_null("TopBar/BedsTextLabel")
	_science_text     = get_node_or_null("TopBar/ScienceTextLabel")
	GameState.hud_update_requested.connect(refresh)
	GameState.state_changed.connect(_on_state_changed)
	var pb: Button = get_node_or_null("SpeedButtons/PauseBtn")
	var b1: Button = get_node_or_null("SpeedButtons/Btn1")
	var b2: Button = get_node_or_null("SpeedButtons/Btn2")
	var b3: Button = get_node_or_null("SpeedButtons/Btn3")
	if pb: pb.pressed.connect(func(): GameState.toggle_pause())
	if b1: b1.pressed.connect(func(): GameState.set_game_speed(1.0))
	if b2: b2.pressed.connect(func(): GameState.set_game_speed(2.0))
	if b3: b3.pressed.connect(func(): GameState.set_game_speed(3.0))
	# Bug-Fix (v10.14): ExpeditionPanel/GraveyardPanel existierten zwar als
	# Skripte, waren aber nirgends im UI-Baum erzeugt UND es gab keinen Weg,
	# sie zu oeffnen. Beide Panels sitzen als Geschwister-Nodes direkt unter
	# UIRoot (siehe Main.gd), genau wie HUD selbst - daher "../".
	var exp_btn: Button = get_node_or_null("ExtraButtons/ExpeditionBtn")
	var grave_btn: Button = get_node_or_null("ExtraButtons/GraveyardBtn")
	var tech_btn: Button = get_node_or_null("ExtraButtons/TechTreeBtn")
	if exp_btn:
		exp_btn.pressed.connect(func():
			var p := get_node_or_null("../ExpeditionPanel")
			if p and p.has_method("open"): p.call("open")
		)
	if grave_btn:
		grave_btn.pressed.connect(func():
			var p := get_node_or_null("../GraveyardPanel")
			if p and p.has_method("open"): p.call("open")
		)
	if tech_btn:
		tech_btn.pressed.connect(func():
			var p := get_node_or_null("../TechTreePanel")
			if p and p.has_method("open"): p.call("open")
		)

func _process(_dt: float) -> void:
	if not GameState.is_playing(): return
	if _time_label:
		_time_label.text = "%s %s | Tag %d" % [DayNight.icon, DayNight.display_time, DayNight.day_count + 1]
	if _drought_label:
		if DroughtSys.phase != "WET":
			_drought_label.text = DroughtSys.display_text
			_drought_label.modulate = DroughtSys.hud_color
			_drought_label.show()
		else:
			_drought_label.hide()
	if _season_label:
		_season_label.text = SeasonSys.get_season_icon() + " " + SeasonSys.get_season_name()

func refresh() -> void:
	if not is_inside_tree(): return
	_update_resources()
	_update_bars()
	if _pop_label: _pop_label.text = "Frettchen: %d" % PopMgr.get_count()

func _update_resources() -> void:
	if _resource_display == null: return
	for c in _resource_display.get_children(): c.queue_free()
	var icons: Dictionary = BuildingData.RESOURCE_ICONS
	var order: Array = ["WOOD","STONE","BERRIES","PLANKS","TOOLS","FOOD",
		"MEAT","WHEAT","COOKED_MEAT","BREAD","STEW","IRON","IRON_BARS","MACHINES","COAL","STEEL","DYNAMITE"]
	var hide_zero: Array = ["MEAT","DYNAMITE","WHEAT","COOKED_MEAT","BREAD","STEW","IRON","IRON_BARS","MACHINES","COAL","STEEL"]
	for res in order:
		var val: float = float(ResourceSys.resources.get(res, 0.0))
		if res in hide_zero and val < 1.0: continue
		var lbl := Label.new()
		lbl.text = "%s%d" % [str(icons.get(res,"?")), int(val)]
		lbl.add_theme_font_size_override("font_size", 13)
		_resource_display.add_child(lbl)

func _update_bars() -> void:
	if _storage_bar:
		var stored: float = ResourceSys.get_total_stored()
		var cap: float = maxf(1.0, ResourceSys.storage_capacity)
		_storage_bar.value = stored / cap * 100.0
		_storage_bar.tooltip_text = "Lager: %d/%d" % [int(stored), int(cap)]
	if _storage_text:
		_storage_text.text = "📦 %d/%d" % [int(ResourceSys.get_total_stored()), int(ResourceSys.storage_capacity)]
	if _water_bar:
		var wc: float = maxf(1.0, ResourceSys.water_capacity)
		_water_bar.value = ResourceSys.water / wc * 100.0
		_water_bar.tooltip_text = "Wasser: %d/%d" % [int(ResourceSys.water), int(wc)]
	# Bug-Fix (v11.0): "Wassertand wird nicht angezeigt" - garantiert
	# sichtbares Text-Label statt sich ausschliesslich auf die schmale,
	# beschriftungslose ProgressBar zu verlassen.
	if _water_text:
		_water_text.text = "💧 %d/%d" % [int(ResourceSys.water), int(ResourceSys.water_capacity)]
	# Feature (v11.1, Betten): zeigt belegte/gesamte Schlafplaetze der Kolonie.
	# Faerbung warnt, sobald mehr Frettchen als Betten da sind (Obdachlose).
	if _beds_text:
		var total_beds: int = BuildingSys.get_total_beds()
		var occ_beds: int = BuildingSys.get_occupied_beds()
		_beds_text.text = "🛏️ %d/%d" % [occ_beds, total_beds]
		var homeless: int = PopMgr.get_count() - total_beds
		_beds_text.add_theme_color_override("font_color",
			Color(0.95, 0.35, 0.25) if homeless > 0 else Color(0.85, 0.65, 1.0))
	# Feature (Tech Tree): zeigt den aktuellen Wissenspunkte-Bestand.
	if _science_text:
		_science_text.text = "🔬 %d" % int(ResourceSys.science)

func _on_state_changed(state: GameState.State) -> void:
	visible = (state == GameState.State.PLAYING or state == GameState.State.PAUSED)

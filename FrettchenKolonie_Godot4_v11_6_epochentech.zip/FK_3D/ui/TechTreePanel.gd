## TechTreePanel.gd
## Feature (Tech Tree, Epochen-Verteilung): Panel fuer den Tech Tree, jetzt
## primaer nach EPOCHE gruppiert (4 Reiter) statt nach Themenbereich, da
## Knoten fest einer Epoche zugeordnet sind (siehe TechTree.gd). Innerhalb
## einer Epoche werden die Knoten weiterhin nach Themenbereich (mit Icon)
## als optische Unter-Gruppierung sortiert. Baut seine komplette UI dynamisch
## in _refresh() selbst auf (Muster wie ExpeditionPanel.gd/GraveyardPanel.gd).
extends PanelContainer

var _current_epoch: int = 1

func _ready() -> void:
	hide()
	GameState.tech_unlocked.connect(func(_id): if visible: _refresh())
	GameState.hud_update_requested.connect(func(): if visible: _refresh())

func open() -> void:
	# Feature: beim Oeffnen direkt den Reiter der aktuellen (hoechsten
	# freigeschalteten) Epoche zeigen - dort passiert gerade das meiste.
	_current_epoch = TechTreeSys.get_epoch()
	show(); _refresh()

func _refresh() -> void:
	for c in get_children(): c.queue_free()
	var outer := VBoxContainer.new(); outer.add_theme_constant_override("separation", 6); add_child(outer)

	# ── Kopfzeile ─────────────────────────────────────────────────────────
	var hdr := HBoxContainer.new(); outer.add_child(hdr)
	var tl := Label.new()
	tl.text = "🔬 Tech Tree – Wissenspunkte: %d" % int(ResourceSys.science)
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 16)
	tl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.75))
	hdr.add_child(tl)
	var cb := Button.new(); cb.text = "X"; cb.pressed.connect(hide); hdr.add_child(cb)
	outer.add_child(HSeparator.new())

	# ── Epochen-Fortschritt + Freischalt-Button fuer die naechste Epoche ──
	outer.add_child(_build_epoch_progress_row())
	outer.add_child(HSeparator.new())

	# ── Epochen-Reiter (1-4) ────────────────────────────────────────────
	var tabs := HBoxContainer.new(); tabs.add_theme_constant_override("separation", 4)
	outer.add_child(tabs)
	var cur_unlocked_epoch: int = TechTreeSys.get_epoch()
	for e_num in range(1, 5):
		var eid: String = "EPOCH_%d" % e_num
		var ed: Dictionary = TechTreeSys.EPOCHS.get(eid, {})
		var is_unlocked_epoch: bool = eid in TechTreeSys.unlocked_epochs
		var done: int = TechTreeSys.get_epoch_unlocked_count(e_num)
		var total: int = TechTreeSys.get_node_ids_for_epoch(e_num).size()
		var tb := Button.new()
		var lock_icon: String = "" if is_unlocked_epoch else "🔒 "
		tb.text = "%s%d. %s (%d/%d)" % [lock_icon, e_num, str(ed.get("name", eid)), done, total]
		tb.add_theme_font_size_override("font_size", 11)
		tb.toggle_mode = true
		tb.button_pressed = (e_num == _current_epoch)
		if e_num == _current_epoch:
			tb.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
		elif not is_unlocked_epoch:
			tb.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		var en: int = e_num
		tb.pressed.connect(func(): _current_epoch = en; _refresh())
		tabs.add_child(tb)

	if _current_epoch > cur_unlocked_epoch:
		var hint := Label.new()
		hint.text = "🔒 Epoche %d ist noch nicht freigeschaltet – Vorschau der kommenden Upgrades." % _current_epoch
		hint.add_theme_font_size_override("font_size", 11)
		hint.add_theme_color_override("font_color", Color(0.85, 0.5, 0.3))
		outer.add_child(hint)

	# ── Knoten-Liste der aktuell gewaehlten Epoche, gruppiert nach
	# Themenbereich (nur optisch) ─────────────────────────────────────────
	var sc := ScrollContainer.new(); sc.custom_minimum_size = Vector2(0, 300)
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(sc)
	var list := VBoxContainer.new(); list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 4); sc.add_child(list)
	for sid in TechTreeSys.SECTION_ORDER:
		var sdata: Dictionary = TechTreeSys.SECTIONS.get(sid, {})
		var section_nodes: Array = []
		for tier in range(1, 11):
			var tid: String = "%s_%d" % [sid, tier]
			if not TechTreeSys.NODES.has(tid): continue
			if int((TechTreeSys.NODES[tid] as Dictionary).get("epoch", 1)) != _current_epoch: continue
			section_nodes.append(tid)
		if section_nodes.is_empty(): continue
		var head := Label.new()
		head.text = "%s %s" % [str(sdata.get("icon","")), str(sdata.get("name", sid))]
		head.add_theme_font_size_override("font_size", 12)
		head.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
		list.add_child(head)
		for tid in section_nodes:
			list.add_child(_build_node_row(tid))

func _build_epoch_progress_row() -> Control:
	var row := VBoxContainer.new(); row.add_theme_constant_override("separation", 4)
	var cur: int = TechTreeSys.get_epoch()
	var cur_name: String = str(TechTreeSys.EPOCHS.get("EPOCH_%d" % cur, {}).get("name", ""))
	var done: int = TechTreeSys.get_epoch_unlocked_count(cur)
	var total: int = TechTreeSys.get_node_ids_for_epoch(cur).size()
	var required: int = TechTreeSys.get_epoch_unlock_requirement(cur)
	var pct: int = int(round(float(done) / maxf(1.0, float(total)) * 100.0))

	var prog_lbl := Label.new()
	prog_lbl.text = "Aktuelle Epoche: %d. %s – Fortschritt %d/%d (%d%%), benötigt %d für den nächsten Aufstieg" % [
		cur, cur_name, done, total, pct, required]
	prog_lbl.add_theme_font_size_override("font_size", 12)
	prog_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	row.add_child(prog_lbl)

	var next_id: String = TechTreeSys.get_next_epoch_id()
	if next_id != "":
		var ed2: Dictionary = TechTreeSys.EPOCHS.get(next_id, {})
		var req_met: bool = TechTreeSys.epoch_requirement_met(next_id)
		if not req_met:
			var info := Label.new()
			info.text = "Noch %d weitere Knoten in Epoche %d nötig, um „%s“ freizuschalten." % [
				maxi(0, required - done), cur, str(ed2.get("name", next_id))]
			info.add_theme_font_size_override("font_size", 11)
			info.add_theme_color_override("font_color", Color(0.85,0.5,0.3))
			row.add_child(info)
		else:
			var btn := Button.new()
			var cost: float = float(ed2.get("cost", 0.0))
			btn.text = "Epoche freischalten: %s (🔬%d)" % [str(ed2.get("name", next_id)), int(cost)]
			btn.disabled = not TechTreeSys.can_unlock_epoch(next_id)
			btn.pressed.connect(func(): TechTreeSys.unlock_epoch(next_id); _refresh())
			row.add_child(btn)
	else:
		var maxlbl := Label.new(); maxlbl.text = "Höchste Epoche erreicht."
		maxlbl.add_theme_font_size_override("font_size", 11)
		maxlbl.add_theme_color_override("font_color", Color(0.5,0.5,0.5))
		row.add_child(maxlbl)
	return row

func _build_node_row(tid: String) -> Control:
	var nd: Dictionary = TechTreeSys.NODES.get(tid, {})
	var panel := PanelContainer.new()
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 2); panel.add_child(vb)

	var top := HBoxContainer.new(); vb.add_child(top)
	var is_unlocked: bool = TechTreeSys.is_node_unlocked(tid)
	var node_epoch: int = int(nd.get("epoch", 1))
	var epoch_ok: bool = node_epoch <= TechTreeSys.get_epoch()
	var req: String = str(nd.get("requires_node",""))
	var req_ok: bool = req == "" or TechTreeSys.is_node_unlocked(req)
	var can_unlock: bool = TechTreeSys.can_unlock_node(tid)

	var name_lbl := Label.new()
	var status_icon: String = "✅" if is_unlocked else ("🔒" if (not epoch_ok or not req_ok) else "🔬")
	name_lbl.text = "%s Stufe %d: %s" % [status_icon, int(nd.get("tier",0)), str(nd.get("name", tid))]
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_lbl.add_theme_font_size_override("font_size", 13)
	if is_unlocked:
		name_lbl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.55))
	elif not epoch_ok or not req_ok:
		name_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	top.add_child(name_lbl)

	if not is_unlocked:
		var btn := Button.new()
		btn.text = "Erforschen (🔬%d)" % int(nd.get("cost", 0.0))
		btn.disabled = not can_unlock
		btn.add_theme_font_size_override("font_size", 11)
		var t: String = tid
		btn.pressed.connect(func(): TechTreeSys.unlock_node(t); _refresh())
		top.add_child(btn)

	var desc_lbl := Label.new()
	desc_lbl.text = str(nd.get("desc",""))
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.add_theme_font_size_override("font_size", 11)
	desc_lbl.add_theme_color_override("font_color", Color(0.75,0.75,0.75))
	vb.add_child(desc_lbl)

	if not is_unlocked:
		if not epoch_ok:
			var lock_lbl := Label.new()
			lock_lbl.text = "Benötigt Epoche %d." % node_epoch
			lock_lbl.add_theme_font_size_override("font_size", 10)
			lock_lbl.add_theme_color_override("font_color", Color(0.7,0.35,0.3))
			vb.add_child(lock_lbl)
		elif not req_ok:
			var req_nd: Dictionary = TechTreeSys.NODES.get(req, {})
			var lock_lbl2 := Label.new()
			lock_lbl2.text = "Benötigt zuerst: %s" % str(req_nd.get("name", req))
			lock_lbl2.add_theme_font_size_override("font_size", 10)
			lock_lbl2.add_theme_color_override("font_color", Color(0.7,0.35,0.3))
			vb.add_child(lock_lbl2)

	return panel

## PlayerController.gd
## Feature (v11.2, First-Person-Modus): steuerbares Spieler-Frettchen.
## Eigenstaendiger CharacterBody3D, KOMPLETT getrennt vom normalen
## FerretEntity/PopMgr-System - das Spieler-Frettchen ist kein Kolonie-NPC und
## wird nicht vom Beduerfnis-/Arbeits-System verwaltet. Es nutzt dasselbe
## ferret.glb-Modell wie die Kolonie-Frettchen (siehe WorldRenderer3D), damit
## es optisch dazu passt, wenn man von der Iso-Ansicht aus zusieht.
##
## Bewegung per WASD (move_up/down/left/right, bereits im InputMap fuer die
## Kamera vorhanden, hier zweitverwendet), Umsehen per Mausbewegung (Yaw am
## Body, Pitch an der Kamera). Kollidiert gegen das bestehende Terrain-Trimesh
## (Layer 1) und Gebaeude-Kollisionsformen (Layer 2) - dadurch funktioniert
## das Laufen ueber Huegel/Berge automatisch korrekt, ohne eigene
## Hoehenabfrage-Logik.
class_name PlayerController
extends CharacterBody3D

const PLAYER_SPEED: float = 6.0     # Welteinheiten/Sek (TILE_SIZE=2.0 -> ~3 Tiles/Sek)
const GRAVITY:       float = 18.0
const JUMP_VELOCITY: float = 7.5    # Feature (v11.2-Hotfix): Sprung - erlaubt
                                     # Klippen hochzusteigen die hoher als ein
                                     # Tile sind. Wert bewusst moderat - zu hoch
                                     # wuerde das Frettchen aus der Welt katapultieren.
const MOUSE_SENS:    float = 0.0028
const PITCH_MIN_DEG: float = -75.0
const PITCH_MAX_DEG: float =  75.0
const EYE_HEIGHT:    float = 0.55   # ueber dem Koerper-Ursprung - "Ferret-Cam"

const FERRET_SCENE: PackedScene = preload("res://assets/ferret.glb")
const FERRET_MODEL_SCALE: float = 2.2

var camera: Camera3D = null
var ferret_visual: Node3D = null
var _anim_player: AnimationPlayer = null
var _pitch: float = 0.0

## Wird von GameController gesteuert: nur wenn aktiv, reagiert der
## Controller ueberhaupt auf Bewegungseingaben/Schwerkraft - sonst bleibt er
## regungslos stehen (z.B. waehrend eines aktiven Minispiels).
var movement_enabled: bool = true

func _ready() -> void:
	collision_layer = 4   # eigener Layer - nichts anderes soll am Spieler kollidieren
	collision_mask  = 1 | 2  # Terrain (1) + Gebaeude (2)

	var cs := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 0.85
	cs.shape = shape
	cs.position = Vector3(0.0, 0.45, 0.0)
	add_child(cs)

	ferret_visual = FERRET_SCENE.instantiate() as Node3D
	ferret_visual.scale = Vector3.ONE * FERRET_MODEL_SCALE
	_disable_shadows_visual(ferret_visual)
	add_child(ferret_visual)
	_anim_player = ferret_visual.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if _anim_player and _anim_player.has_animation("Run"):
		_anim_player.play("Run")
		_anim_player.stop(true)

	camera = Camera3D.new()
	camera.name = "FPCamera"
	camera.position = Vector3(0.0, EYE_HEIGHT, 0.0)
	camera.fov = 80.0
	add_child(camera)

func _physics_process(delta: float) -> void:
	if not movement_enabled:
		velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0
		# Feature (v11.2-Hotfix): Sprung per Leertaste, nur wenn am Boden -
		# erlaubt das Ueberwinden von Klippen-Stufen die zu hoch zum einfachen
		# Drauflaufen waeren. move_and_slide() uebernimmt den Rest (Slope-Handling).
		if Input.is_action_just_pressed("ui_accept"):
			velocity.y = JUMP_VELOCITY

	var move := Vector3.ZERO
	if Input.is_action_pressed("move_up"):    move -= transform.basis.z
	if Input.is_action_pressed("move_down"):  move += transform.basis.z
	if Input.is_action_pressed("move_left"):  move -= transform.basis.x
	if Input.is_action_pressed("move_right"): move += transform.basis.x
	var moving: bool = move.length() > 0.01
	if moving:
		move = move.normalized()
	velocity.x = move.x * PLAYER_SPEED
	velocity.z = move.z * PLAYER_SPEED
	move_and_slide()

	if _anim_player:
		if moving and not _anim_player.is_playing():
			_anim_player.play("Run")
		elif not moving and _anim_player.is_playing():
			_anim_player.stop(true)
	# Sichtkoerper laeuft "voraus" in Bewegungsrichtung - bei reinem
	# Stillstehen behaelt er die zuletzt per Maus gesetzte Blickrichtung
	# (rotation.y des Body selbst, siehe apply_look()).

## Wird von GameController bei jeder gefangenen InputEventMouseMotion
## aufgerufen, waehrend der First-Person-Modus aktiv ist und kein Minispiel
## laeuft. Yaw dreht den ganzen Body (= auch die Laufrichtung), Pitch nur die
## Kamera - klassisches FPS-Schema.
func apply_look(rel: Vector2) -> void:
	rotation.y -= rel.x * MOUSE_SENS
	_pitch = clampf(_pitch - rel.y * MOUSE_SENS,
		deg_to_rad(PITCH_MIN_DEG), deg_to_rad(PITCH_MAX_DEG))
	camera.rotation.x = _pitch

## Setzt den Spieler an eine Tile-Position (Weltkoordinaten kommen von
## WorldRenderer3D.tile_to_world3d()). Ein kleiner Y-Versatz nach oben sorgt
## dafuer, dass der Spieler sicher AUF dem Terrain landet (faellt per
## Schwerkraft den letzten kurzen Weg), statt bei ungenauer Hoehe im Boden
## stecken zu bleiben.
func teleport_to(world_pos: Vector3, yaw: float = 0.0) -> void:
	global_position = world_pos + Vector3(0.0, 1.2, 0.0)
	velocity = Vector3.ZERO
	rotation.y = yaw
	_pitch = 0.0
	if camera: camera.rotation.x = 0.0

func _disable_shadows_visual(n: Node) -> void:
	if n is GeometryInstance3D:
		(n as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for c in n.get_children():
		_disable_shadows_visual(c)

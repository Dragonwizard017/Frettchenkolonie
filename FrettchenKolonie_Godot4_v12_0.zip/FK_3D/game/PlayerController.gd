## PlayerController.gd
## Feature (v11.2, First-Person-Modus): steuerbares Spieler-Frettchen.
## Eigenstaendiger CharacterBody3D, KOMPLETT getrennt vom normalen
## FerretEntity/PopMgr-System - das Spieler-Frettchen ist kein Kolonie-NPC und
## wird nicht vom Beduerfnis-/Arbeits-System verwaltet. Es nutzt dasselbe
## ferret.glb-Modell wie die Kolonie-Frettchen (siehe WorldRenderer3D), damit
## es optisch dazu passt, wenn man von der Iso-Ansicht aus zusieht.
##
## Bewegung per WASD (move_up/down/left/right, bereits im InputMap fuer die
## Kamera vorhanden, hier zweitverwendet), Umsehen per Mausbewegung (Yaw am
## Body, Pitch an der Kamera). Kollidiert gegen das bestehende Terrain-Trimesh
## (Layer 1) und Gebaeude-Kollisionsformen (Layer 2) - dadurch funktioniert
## das Laufen ueber Huegel/Berge automatisch korrekt, ohne eigene
## Hoehenabfrage-Logik.
class_name PlayerController
extends CharacterBody3D

const PLAYER_SPEED: float = 6.0     # Welteinheiten/Sek (TILE_SIZE=2.0 -> ~3 Tiles/Sek)
const GRAVITY:       float = 18.0
const JUMP_VELOCITY: float = 7.5    # Feature (v11.2-Hotfix): Sprung - erlaubt
                                     # Klippen hochzusteigen die hoher als ein
                                     # Tile sind. Wert bewusst moderat - zu hoch
                                     # wuerde das Frettchen aus der Welt katapultieren.
const MOUSE_SENS:    float = 0.0028
const PITCH_MIN_DEG: float = -75.0
const PITCH_MAX_DEG: float =  75.0
const EYE_HEIGHT:    float = 0.55   # ueber dem Koerper-Ursprung - "Ferret-Cam"

const FERRET_SCENE: PackedScene = preload("res://assets/ferret.glb")
const FERRET_MODEL_SCALE: float = 2.2

# Feature (v12.0, Phase 3): deutlich vom natuerlichen Fellton (warmes
# Beige/Tan, siehe ferret.glb) unterscheidbarer Tint fuers Frettchen-Ich -
# kuehles Blau, kommt in der natuerlichen Fellpalette nicht vor und ist auch
# aus der Distanz in der Iso-Ansicht gut erkennbar. Multiplikativ auf
# albedo_color angewendet (siehe _apply_player_tint()) - das erhaelt die
# Textur-Details (Schattierung/Muster), faerbt aber sichtbar um, statt das
# Modell komplett einfarbig zu machen.
const PLAYER_TINT: Color = Color(0.5, 0.72, 1.05)

var camera: Camera3D = null
var ferret_visual: Node3D = null
var _anim_player: AnimationPlayer = null
var _pitch: float = 0.0

## Wird von GameController gesteuert: nur wenn aktiv, reagiert der
## Controller ueberhaupt auf Bewegungseingaben/Schwerkraft - sonst bleibt er
## regungslos stehen (z.B. waehrend eines aktiven Minispiels).
var movement_enabled: bool = true

# Feature (v11.26, Mittelklick-Laufbefehl): unabhaengig vom First-Person-
# Modus (auch aktiv wenn movement_enabled=false, also waehrend man die
# Iso-Ansicht steuert) - laesst das Frettchen-Ich geradlinig zu einem per
# Mittelklick gewaehlten Ziel laufen, mit echter Schwerkraft/Bewegungszeit
# und Lauf-Animation, statt zu teleportieren. Bewusst dieselbe simple
# "geradlinig zum Ziel"-Logik wie FerretEntity._move_toward() bei den
# NPC-Frettchen (kein A*/Hindernisumgehung) - siehe Nutzer-Bestaetigung.
var _external_walk_active: bool = false
var _external_walk_target: Vector3 = Vector3.ZERO

func _ready() -> void:
	collision_layer = 4   # eigener Layer - nichts anderes soll am Spieler kollidieren
	collision_mask  = 1 | 2  # Terrain (1) + Gebaeude (2)

	var cs := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 0.85
	cs.shape = shape
	cs.position = Vector3(0.0, 0.45, 0.0)
	add_child(cs)

	ferret_visual = FERRET_SCENE.instantiate() as Node3D
	ferret_visual.scale = Vector3.ONE * FERRET_MODEL_SCALE
	_disable_shadows_visual(ferret_visual)
	_apply_player_tint(ferret_visual)
	add_child(ferret_visual)
	_anim_player = ferret_visual.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if _anim_player and _anim_player.has_animation("Run"):
		_anim_player.play("Run")
		_anim_player.stop(true)

	camera = Camera3D.new()
	camera.name = "FPCamera"
	camera.position = Vector3(0.0, EYE_HEIGHT, 0.0)
	camera.fov = 80.0
	add_child(camera)

func _physics_process(delta: float) -> void:
	# Feature (v11.26): Laufbefehl hat Vorrang und laeuft UNABHAENGIG von
	# movement_enabled (der ja normalerweise FP-Steuerung sperrt, waehrend
	# man in der Iso-Ansicht ist - genau DANN soll der Laufbefehl aber
	# funktionieren).
	if _external_walk_active:
		_process_external_walk(delta)
		return
	if not movement_enabled:
		velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0
		# Bug-Fix (v11.2b): Sprung nutzt jetzt die eigene "fp_jump"-Action
		# (Leertaste) statt "ui_accept". "ui_accept" wurde intern auch vom
		# Godot-UI-System verarbeitet (fokussierter Button = Space = Klick),
		# was zum ungewollten Oeffnen des Pause-Menues fuehrte. "fp_jump" ist
		# exklusiv, wird nicht vom UI-System abgefangen.
		if Input.is_action_just_pressed("fp_jump"):
			velocity.y = JUMP_VELOCITY
			# set_input_as_handled() damit das Space-Event NICHT zum
			# _unhandled_input des GameControllers durchsickert.
			get_viewport().set_input_as_handled()

	var move := Vector3.ZERO
	if Input.is_action_pressed("move_up"):    move -= transform.basis.z
	if Input.is_action_pressed("move_down"):  move += transform.basis.z
	if Input.is_action_pressed("move_left"):  move -= transform.basis.x
	if Input.is_action_pressed("move_right"): move += transform.basis.x
	var moving: bool = move.length() > 0.01
	if moving:
		move = move.normalized()
	velocity.x = move.x * PLAYER_SPEED
	velocity.z = move.z * PLAYER_SPEED
	move_and_slide()

	if _anim_player:
		if moving and not _anim_player.is_playing():
			_anim_player.play("Run")
		elif not moving and _anim_player.is_playing():
			_anim_player.stop(true)
	# Sichtkoerper laeuft "voraus" in Bewegungsrichtung - bei reinem
	# Stillstehen behaelt er die zuletzt per Maus gesetzte Blickrichtung
	# (rotation.y des Body selbst, siehe apply_look()).

## Wird von GameController bei jeder gefangenen InputEventMouseMotion
## aufgerufen, waehrend der First-Person-Modus aktiv ist und kein Minispiel
## laeuft. Yaw dreht den ganzen Body (= auch die Laufrichtung), Pitch nur die
## Kamera - klassisches FPS-Schema.
func apply_look(rel: Vector2) -> void:
	rotation.y -= rel.x * MOUSE_SENS
	_pitch = clampf(_pitch - rel.y * MOUSE_SENS,
		deg_to_rad(PITCH_MIN_DEG), deg_to_rad(PITCH_MAX_DEG))
	camera.rotation.x = _pitch

## Setzt den Spieler an eine Tile-Position (Weltkoordinaten kommen von
## WorldRenderer3D.tile_to_world3d()). Ein kleiner Y-Versatz nach oben sorgt
## dafuer, dass der Spieler sicher AUF dem Terrain landet (faellt per
## Schwerkraft den letzten kurzen Weg), statt bei ungenauer Hoehe im Boden
## stecken zu bleiben.
func teleport_to(world_pos: Vector3, yaw: float = 0.0) -> void:
	global_position = world_pos + Vector3(0.0, 1.2, 0.0)
	velocity = Vector3.ZERO
	rotation.y = yaw
	_pitch = 0.0
	_external_walk_active = false  # Bug-Vorbeugung: ein Teleport ueberschreibt einen laufenden Laufbefehl
	if camera: camera.rotation.x = 0.0

## Feature (v11.26, Mittelklick-Laufbefehl): startet eine geradlinige
## Laufbewegung zum Ziel (XZ-Ebene, Hoehe folgt der normalen Schwerkraft/
## Terrain-Kollision in _process_external_walk()). Ein bereits laufender
## Befehl wird SOFORT durch den neuen ersetzt (Nutzer-Bestaetigung: "dann
## umlenken" statt den Klick zu ignorieren).
func start_walk_to(world_pos: Vector3) -> void:
	_external_walk_target = world_pos
	_external_walk_active = true

## Feature (v11.26): wird von GameController._toggle_fp_mode() beim
## Betreten des First-Person-Modus aufgerufen - ein evtl. noch laufender
## Mittelklick-Laufbefehl darf die WASD-Steuerung NICHT weiter ueberstimmen
## (siehe _physics_process(): _external_walk_active hat sonst Vorrang vor
## movement_enabled).
func cancel_walk() -> void:
	_external_walk_active = false

## Wird jeden Physik-Frame aufgerufen, waehrend ein Laufbefehl aktiv ist -
## bewegt den Spieler geradlinig (XZ) zum Ziel, mit Schwerkraft/Kollision
## (move_and_slide(), exakt wie bei der normalen FP-Bewegung) und dreht das
## Modell in die Laufrichtung. Stoppt automatisch, sobald das Ziel (grob)
## erreicht ist.
func _process_external_walk(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0
	var to_target: Vector3 = _external_walk_target - global_position
	to_target.y = 0.0
	var dist: float = to_target.length()
	if dist < 0.2:
		_external_walk_active = false
		velocity.x = 0.0; velocity.z = 0.0
		move_and_slide()
		if _anim_player and _anim_player.is_playing(): _anim_player.stop(true)
		return
	var dir: Vector3 = to_target / dist  # normalisiert (dist > 0.2, keine Div/0-Gefahr)
	velocity.x = dir.x * PLAYER_SPEED
	velocity.z = dir.z * PLAYER_SPEED
	# Gleiche Yaw-Konvention wie bei den NPC-Frettchen (WorldRenderer3D:
	# "fn.rotation.y = atan2(dir.x, dir.y) + FERRET_ROT_OFFSET", wobei deren
	# 2D dir.x/dir.y exakt den 3D-Weltachsen X/Z entsprechen, siehe
	# WorldRenderer3D.tile_to_world3d()) - dasselbe ferret.glb-Modell, daher
	# dieselbe Formel fuer korrekte Blickrichtung.
	rotation.y = atan2(dir.x, dir.z)
	var was_on_floor: bool = is_on_floor()
	move_and_slide()
	# Bug-Fix (v12.0): der Laufbefehl blieb an Gelaende-Hoehenstufen haengen
	# (Terrain-Kollision ist blockweise/senkrecht, siehe
	# WorldRenderer3D._col_body, HEIGHT_SCALE=1.2 pro Stufe) - im
	# First-Person-Modus konnte man das bisher nur per manuellem Sprung
	# (JUMP_VELOCITY=7.5, erreicht rechnerisch max. 1.56 Einheiten Hoehe,
	# siehe Kommentar oben bei JUMP_VELOCITY) ueberwinden, aber ein
	# Laufbefehl kann nicht "Leertaste druecken". Step-Up-Assist: wird die
	# Horizontalbewegung durch eine eher senkrechte Flaeche blockiert (kein
	# Boden/keine Rampe, sondern eine "Wand"-artige Stufenkante) UND stand
	# der Spieler VOR der Kollisionsaufloesung auf dem Boden, wird automatisch
	# derselbe Sprungimpuls wie bei der manuellen Leertaste ausgeloest -
	# reicht rechnerisch fuer genau 1 Hoehenstufe, nicht fuer mehrstufige
	# Klippen (bewusst so, konsistent mit dem manuellen Sprungverhalten).
	if was_on_floor and _is_blocked_by_wall():
		velocity.y = JUMP_VELOCITY
	if _anim_player and not _anim_player.is_playing():
		_anim_player.play("Run")

## Hilfsfunktion fuer den Step-Up-Assist (v12.0): prueft die Kollisionen des
## letzten move_and_slide()-Aufrufs auf eine eher senkrechte Flaeche (Wand
## bzw. Stufenkante) statt einer begehbaren Rampe/Boden. normal.y nahe 0 =
## senkrecht, normal.y nahe 1 = flacher Boden.
func _is_blocked_by_wall() -> bool:
	for i in get_slide_collision_count():
		var col := get_slide_collision(i)
		if absf(col.get_normal().y) < 0.5:
			return true
	return false

func _disable_shadows_visual(n: Node) -> void:
	if n is GeometryInstance3D:
		(n as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for c in n.get_children():
		_disable_shadows_visual(c)

## Feature (v12.0, Phase 3): faerbt alle MeshInstance3D-Oberflaechen unter
## "n" per Multiplikation mit PLAYER_TINT ein. WICHTIG: nutzt
## set_surface_override_material() mit einer DUPLIZIERTEN Material-Resource
## statt die material-Resource direkt zu veraendern - Godot cached
## importierte glTF-Materialien u.U. resourcenuebergreifend, ein direktes
## Veraendern koennte sonst versehentlich auch die NPC-Frettchen (die
## dasselbe ferret.glb benutzen) mitfaerben. Wird nur einmal in _ready()
## aufgerufen, BEVOR spaeter (Phase 4) Accessoires als Kind-Nodes angehaengt
## werden - faerbt dadurch bewusst nur das Basis-Fell-Modell, nicht
## Accessoires.
func _apply_player_tint(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		if mi.mesh:
			for i in mi.mesh.get_surface_count():
				var src_mat: Material = mi.get_active_material(i)
				var new_mat: Material = (src_mat.duplicate() as Material) if src_mat else StandardMaterial3D.new()
				if new_mat is BaseMaterial3D:
					var bm := new_mat as BaseMaterial3D
					bm.albedo_color = bm.albedo_color * PLAYER_TINT
				mi.set_surface_override_material(i, new_mat)
	for c in n.get_children():
		_apply_player_tint(c)

## FerretAccessories.gd
## Feature (v11.9, Legendäre Frettchen - Accessoires). Reine Datenquelle nach
## demselben Muster wie FerretTraits.gd: const-Dictionary + statische
## Hilfsfunktionen, kein Autoload noetig (kein Laufzeit-Zustand).
##
## 10 Accessoires (siehe assets/accessories/*.glb, generiert per trimesh -
## Details siehe General.md) verteilt auf 4 Slots (HEAD/NECK/FACE/BACK).
## "Kombinierbar" heisst hier: pro Slot maximal EIN Accessoire (sonst wuerden
## sich z.B. zwei Kopfbedeckungen visuell ueberlagern), aber die Slots werden
## unabhaengig voneinander gewuerfelt - ein legendaeres Frettchen kann also
## z.B. gleichzeitig Krone (HEAD) + Schal (NECK) + Monokel (FACE) + Umhang
## (BACK) tragen. Siehe pick_random_set() fuer die Zusammenstellung.
extends RefCounted
class_name FerretAccessories

const SLOTS: Array = ["HEAD", "NECK", "FACE", "BACK"]

## "offset"/"rot_y" sind lokale Transform-Werte relativ zum Frettchen-Root
## selbst (siehe WorldRenderer3D._attach_ferret_accessories() - Accessoires
## haengen DIREKT am Frettchen, OHNE Gegen-Skalierung, und erben dadurch
## ganz normal dieselbe FERRET_MODEL_SCALE-Vergroesserung wie jeder andere
## Teil des Frettchen-Meshes auch). Diese Werte gelten deshalb in denselben
## UNSKALIERTEN Einheiten wie ferret.glb selbst - tatsaechlich vermessen
## (trimesh, ausserhalb von Godot, siehe General.md fuer die Rohdaten):
## Fuesse bei Y=0, Ruecken/Schultern bei Y≈0.27, Kopfmitte Y≈0.24 Z≈0.27,
## Ohren-Oberkante Y≈0.30-0.33, Nasenspitze Z≈0.34, Augen bei X≈±0.034
## Y≈0.25 Z≈0.30.
const ACCESSORIES: Dictionary = {
	"CROWN":     {"name": "Krone",         "slot": "HEAD", "glb": "res://assets/accessories/crown.glb",      "offset": Vector3(0.0, 0.33, 0.24), "rot_y": 0.0},
	"TOP_HAT":   {"name": "Zylinder",      "slot": "HEAD", "glb": "res://assets/accessories/top_hat.glb",    "offset": Vector3(0.0, 0.33, 0.24), "rot_y": 0.0},
	"WIZARD_HAT":{"name": "Zauberhut",     "slot": "HEAD", "glb": "res://assets/accessories/wizard_hat.glb", "offset": Vector3(0.0, 0.31, 0.24), "rot_y": 0.0},
	"BANDANA":   {"name": "Bandana",       "slot": "HEAD", "glb": "res://assets/accessories/bandana.glb",    "offset": Vector3(0.0, 0.29, 0.26), "rot_y": 0.0},
	"BOWTIE":    {"name": "Fliege",        "slot": "NECK", "glb": "res://assets/accessories/bowtie.glb",     "offset": Vector3(0.0, 0.21, 0.19), "rot_y": 0.0},
	"SCARF":     {"name": "Schal",         "slot": "NECK", "glb": "res://assets/accessories/scarf.glb",      "offset": Vector3(0.0, 0.20, 0.18), "rot_y": 0.0},
	"MEDAL":     {"name": "Medaille",      "slot": "NECK", "glb": "res://assets/accessories/medal.glb",      "offset": Vector3(0.0, 0.18, 0.19), "rot_y": 0.0},
	"MONOCLE":   {"name": "Monokel",       "slot": "FACE", "glb": "res://assets/accessories/monocle.glb",    "offset": Vector3(0.045, 0.25, 0.30), "rot_y": 0.0},
	"EYEPATCH":  {"name": "Augenklappe",   "slot": "FACE", "glb": "res://assets/accessories/eyepatch.glb",   "offset": Vector3(-0.045, 0.25, 0.30), "rot_y": 0.0},
	"CAPE":      {"name": "Umhang",        "slot": "BACK", "glb": "res://assets/accessories/cape.glb",       "offset": Vector3(0.0, 0.26, 0.05), "rot_y": PI},
}

## Wuerfelt pro Slot unabhaengig (70% Chance auf ein Accessoire in diesem
## Slot, davon gleichverteilt eines der Slot-Optionen) - liefert ein
## individuelles Set (Array von Accessoire-IDs) fuer ein neu legendaer
## gewordenes Frettchen. Mindestens 1 Accessoire garantiert, damit kein
## legendaeres Frettchen komplett "leer" bleibt.
static func pick_random_set() -> Array:
	var by_slot: Dictionary = {}
	for aid in ACCESSORIES:
		var slot: String = str((ACCESSORIES[aid] as Dictionary).get("slot", ""))
		if not by_slot.has(slot): by_slot[slot] = []
		(by_slot[slot] as Array).append(aid)

	var result: Array = []
	for slot in SLOTS:
		if randf() < 0.7:
			var options: Array = by_slot.get(slot, [])
			if not options.is_empty():
				result.append(options[randi() % options.size()])

	if result.is_empty():
		var all_slots: Array = SLOTS.duplicate()
		all_slots.shuffle()
		var fallback: Array = by_slot.get(all_slots[0], [])
		if not fallback.is_empty(): result.append(fallback[randi() % fallback.size()])
	return result

static func get_accessory(aid: String) -> Dictionary:
	return ACCESSORIES.get(aid, {})

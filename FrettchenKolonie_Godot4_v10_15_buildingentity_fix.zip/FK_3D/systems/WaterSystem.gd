## WaterSystem.gd
## Timberborn-artige Wasserphysik fuer FrettchenKolonie.
## Simuliert pro Tile eine tatsaechliche Wassertiefe ("water_level"), die
## additiv zur Terrain-"height" steht (Tile-Wasseroberflaeche = height +
## water_level). Jeden Simulationsschritt:
##  1) Wasserquellen (von WorldGenerator markiert) speisen neues Wasser ein
##     - das simuliert Fluss-Zustrom von ausserhalb der Karte.
##  2) Wasser fliesst zu Nachbar-Tiles mit niedrigerer Oberflaeche (einfacher
##     zellulaerer Automat, vier Nachbarn) - genau wie in Timberborn breitet
##     sich Wasser ueber die Landschaft aus und sammelt sich in Senken.
##  3) Verdunstung reduziert den Pegel kontinuierlich, waehrend einer Duerre
##     (DroughtSys.is_drought) stark verstaerkt UND mit reduziertem
##     Quellzufluss - Fluesse/Seen trocknen waehrend einer Duerre sichtbar aus
##     und fuellen sich in der nassen Phase wieder auf.
## Gebaeude vom Typ "DAM" (Damm) reduzieren den Ausgehenden Fluss eines Tiles,
## sodass Spieler aktiv Wasser aufstauen koennen, um Duerreperioden besser zu
## ueberstehen - das zentrale strategische Element aus Timberborn.
extends Node

# ── Konstanten ────────────────────────────────────────────────────────────────
const FLOW_RATE:          float = 0.9    # Anteil des Hoehenunterschieds, der pro Sek. ausgeglichen wird
const MIN_FLOW:           float = 0.0008 # unterhalb dieser Menge wird nicht mehr geflossen (Stabilitaet)
const EVAP_RATE_WET:      float = 0.004  # Verdunstung/Sek. in der nassen Phase
const EVAP_RATE_DROUGHT:  float = 0.05   # Verdunstung/Sek. waehrend einer Duerre
const SOURCE_RATE_WET:    float = 0.6    # Zufluss/Sek. je Quell-Tile in der nassen Phase
const SOURCE_RATE_DROUGHT: float = 0.05  # Zufluss/Sek. je Quell-Tile waehrend einer Duerre
const MAX_DEPTH:          float = 4.0    # Kappung, damit Quellen nicht endlos aufstauen
const DAM_RETENTION:      float = 0.85   # Daemme reduzieren ausgehenden Fluss um diesen Faktor
const STEP:               float = 0.15   # feste Simulationsschrittweite (Stabilitaet, unabhaengig von Framerate)
const NEIGHBORS: Array = [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]

# ── State ─────────────────────────────────────────────────────────────────────
var world_ref: Array = []
var w: int = 60
var h: int = 60
var _accum: float = 0.0
var _delta: PackedFloat32Array = PackedFloat32Array()

func init(world: Array, world_w: int, world_h: int) -> void:
	world_ref = world
	w = world_w
	h = world_h
	_accum = 0.0
	_delta.resize(w * h)
	_delta.fill(0.0)

## Wird jeden Frame von GameController._process() aufgerufen. dt ist bereits
## mit game_speed/Jahreszeit skaliert (gleiches Muster wie andere Systeme).
## Die Simulation selbst laeuft intern in festen STEP-Schritten, damit sie bei
## hoher Spielgeschwindigkeit (mehrere Schritte pro Frame) stabil bleibt.
func update(dt: float, world: Array) -> void:
	world_ref = world
	if _delta.size() != w * h:
		_delta.resize(w * h); _delta.fill(0.0)
	_accum += dt
	var safety: int = 0
	while _accum >= STEP and safety < 10:
		_accum -= STEP
		_simulate_step(STEP)
		safety += 1
	if safety >= 10:
		_accum = 0.0 # extreme Nachholbedarf (z.B. nach Laden) abbrechen statt einfrieren

func _simulate_step(step: float) -> void:
	var drought: bool = DroughtSys.is_drought
	var evap: float = EVAP_RATE_DROUGHT if drought else EVAP_RATE_WET
	var source_rate: float = SOURCE_RATE_DROUGHT if drought else SOURCE_RATE_WET

	_delta.fill(0.0)

	# 1) Quellen speisen ein
	for x in w:
		var col: Array = world_ref[x]
		for y in h:
			var tile: Dictionary = col[y]
			if bool(tile.get("is_water_source", false)):
				_delta[x * h + y] += source_rate * step

	# 2) Fluss zu Nachbarn mit niedrigerer Oberflaeche
	for x in w:
		var col: Array = world_ref[x]
		for y in h:
			var tile: Dictionary = col[y]
			var lvl: float = float(tile.get("water_level", 0.0))
			if lvl <= MIN_FLOW: continue
			var bed: float = float(tile.get("height", 0.0))
			var surface: float = bed + lvl
			var retention: float = DAM_RETENTION if _has_dam(tile) else 1.0
			var idx: int = x * h + y
			for d in NEIGHBORS:
				_flow_to(x, y, x + d.x, y + d.y, lvl, surface, retention, step, idx)

	# 3) Delta anwenden + Verdunstung
	for x in w:
		var col: Array = world_ref[x]
		for y in h:
			var tile: Dictionary = col[y]
			var idx: int = x * h + y
			var lvl: float = float(tile.get("water_level", 0.0)) + _delta[idx]
			lvl = clampf(lvl, 0.0, MAX_DEPTH)
			if lvl > 0.0:
				lvl = maxf(0.0, lvl - evap * step)
			tile["water_level"] = lvl

func _flow_to(x: int, y: int, nx: int, ny: int, lvl: float, surface: float, retention: float, step: float, idx: int) -> void:
	if nx < 0 or ny < 0 or nx >= w or ny >= h:
		# Kartenrand = Senke/Abfluss, simuliert Fluss ins Meer/aus der Karte heraus.
		var edge_amt: float = minf(lvl * 0.25, surface * 0.5 * FLOW_RATE * step) * retention
		if edge_amt > MIN_FLOW:
			_delta[idx] -= edge_amt
		return
	var ntile: Dictionary = (world_ref[nx] as Array)[ny]
	var nlvl:  float = float(ntile.get("water_level", 0.0))
	var nbed:  float = float(ntile.get("height", 0.0))
	var nsurface: float = nbed + nlvl
	var diff: float = surface - nsurface
	if diff <= MIN_FLOW: return
	var amt: float = minf(lvl * 0.25, diff * 0.5 * FLOW_RATE * step) * retention
	if amt <= MIN_FLOW: return
	_delta[idx] -= amt
	_delta[nx * h + ny] += amt

func _has_dam(tile: Dictionary) -> bool:
	var b = tile.get("building")
	if b == null: return false
	return str((b as BuildingEntity).id) == "DAM"

## Liefert den durchschnittlichen, TATSAECHLICHEN Wasserstand in einem Radius
## um eine Tile-Position. Wird von Sammelgebaeuden (Brunnen, Wasserturm,
## Aquaedukt, ...) genutzt, damit ihre Produktion von der simulierten
## Wassermenge abhaengt statt nur von der statischen Biom-Zugehoerigkeit -
## trocknet der Fluss in einer Duerre aus, sinkt auch ihre Foerderleistung.
func get_avg_level_near(tx: int, ty: int, radius: int) -> float:
	if world_ref.is_empty(): return 0.0
	var total: float = 0.0
	var count: int = 0
	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			var wx: int = tx + dx
			var wy: int = ty + dy
			if wx < 0 or wy < 0 or wx >= w: continue
			var col: Array = world_ref[wx]
			if wy >= col.size(): continue
			total += float((col[wy] as Dictionary).get("water_level", 0.0))
			count += 1
	return total / float(maxi(1, count))

## Wasserstand wird direkt in den Tile-Daten von "world" gehalten (siehe
## GameController.serialize_world/deserialize_world) - dieses System selbst
## braucht keinen eigenen Speicherstand.
func serialize() -> Dictionary:
	return {}

func deserialize(_data: Dictionary) -> void:
	pass

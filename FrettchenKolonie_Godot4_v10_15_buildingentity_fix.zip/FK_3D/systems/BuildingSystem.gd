## BuildingSystem.gd
extends Node

var buildings: Array = []
var _warn_full: bool = false
var _warn_timer: float = 0.0

func init() -> void:
	buildings = []
	_warn_full = false
	_warn_timer = 0.0

func update(dt: float, is_day: bool, world: Array) -> void:
	ResourceSys.update_capacity(buildings)
	ResourceSys.update_water_capacity(buildings)

	# Wasserrad-Boosts zurücksetzen
	for b in buildings:
		var be: BuildingEntity = b
		be.waterwheel_boost = 0.0

	# Wasserrad-Boosts berechnen
	for b in buildings:
		var ww: BuildingEntity = b
		if ww.btype != "WATERWHEEL" or ww.is_under_construction or ww.assigned_workers.is_empty():
			continue
		var has_water_near: bool = false
		for dx in range(-3, 4):
			for dy in range(-3, 4):
				var wx: int = ww.tile_x + dx
				var wy: int = ww.tile_y + dy
				if wx < 0 or wy < 0 or wx >= world.size(): continue
				var col: Array = world[wx]
				if wy >= col.size(): continue
				var tile: Dictionary = col[wy]
				# Feature (Wasserphysik): Wasserrad braucht jetzt TATSAECHLICH
				# fliessendes/stehendes Wasser (water_level), nicht nur die
				# statische WATER-Biom-Zugehoerigkeit - trocknet der Fluss in
				# einer Duerre komplett aus, steht das Wasserrad still, genau
				# wie eine Wassermuehle in Timberborn ohne Wasserzufluss.
				if float(tile.get("water_level", 0.0)) > 0.15:
					has_water_near = true; break
			if has_water_near: break
		if not has_water_near: continue
		for other in buildings:
			var ob: BuildingEntity = other
			if ob.is_under_construction: continue
			var dist: int = abs(ob.tile_x - ww.tile_x) + abs(ob.tile_y - ww.tile_y)
			if dist <= int(ww.boost_radius):
				ob.waterwheel_boost += ww.boost_factor

	for b in buildings:
		var be: BuildingEntity = b
		be.update(dt, is_day, world)

	_warn_timer += dt
	if _warn_timer > 10.0:
		_warn_timer = 0.0
		var pct: float = ResourceSys.get_total_stored() / maxf(1.0, ResourceSys.storage_capacity)
		if pct > 0.95 and not _warn_full:
			_warn_full = true
			GameState.notify("Lager voll! Ressourcen gehen verloren. Baue mehr Lager!", Color(0.8, 0.3, 0.1))
		elif pct < 0.8:
			_warn_full = false

func build(building_id: String, tx: int, ty: int, world: Array, free: bool = false) -> BuildingEntity:
	var all_buildings: Dictionary = BuildingData.BUILDINGS
	if not all_buildings.has(building_id): return null
	var data: Dictionary = all_buildings[building_id]
	if not free:
		var costs: Dictionary = data.get("costs", {}) as Dictionary
		if not ResourceSys.can_afford(costs): return null
		ResourceSys.spend(costs)
	var b: BuildingEntity = BuildingEntity.from_type(building_id, tx, ty)
	if b == null: return null
	if tx < world.size():
		var col: Array = world[tx]
		if ty < col.size():
			col[ty]["building"] = b
	buildings.append(b)
	GameState.building_placed.emit(b)
	GameState.hud_update_requested.emit()
	GameState.build_menu_update_requested.emit()
	return b

func build_free(building_id: String, tx: int, ty: int, world: Array) -> BuildingEntity:
	var b: BuildingEntity = build(building_id, tx, ty, world, true)
	if b != null:
		b.is_under_construction = false
		b.construction_progress = b.construction_work_needed
	return b

func sell(b: BuildingEntity, world: Array) -> void:
	if b == null: return
	b.remove_all_workers()
	# Crash-Fix: assigned_builder ist eine BuildingEntity (RefCounted) und hat
	# kein current_construction_site-Feld (das gibt es nur auf FerretEntity).
	# Schreiben auf eine nicht deklarierte Property eines RefCounted-Objekts
	# wirft in GDScript 4 einen Laufzeitfehler -> Absturz, sobald dieses Feld
	# jemals belegt wird. Einfach zuruecksetzen reicht hier aus.
	b.assigned_builder = null
	for r in b.residents.duplicate():
		var ferret = r
		ferret.home = null
	b.residents = []
	for res in b.costs:
		ResourceSys.force_add(res, floorf(float(b.costs[res]) * 0.7))
	if b.tile_x < world.size():
		var col: Array = world[b.tile_x]
		if b.tile_y < col.size():
			col[b.tile_y]["building"] = null
	buildings.erase(b)
	GameState.building_sold.emit(b)
	GameState.hud_update_requested.emit()
	GameState.build_menu_update_requested.emit()

func can_build(building_id: String) -> bool:
	var all_buildings: Dictionary = BuildingData.BUILDINGS
	if not all_buildings.has(building_id): return false
	var data: Dictionary = all_buildings[building_id]
	return ResourceSys.can_afford(data.get("costs", {}) as Dictionary)

func get_construction_sites() -> Array:
	var result: Array = []
	for b in buildings:
		var be: BuildingEntity = b
		if be.is_under_construction: result.append(be)
	return result

func get_buildings_of_type(btype: String) -> Array:
	var result: Array = []
	for b in buildings:
		var be: BuildingEntity = b
		if be.btype == btype and not be.is_under_construction: result.append(be)
	return result

func get_builders() -> Array:
	var result: Array = []
	for b in buildings:
		var be: BuildingEntity = b
		if be.btype in ["BUILDER", "ENGINEERS_GUILD", "CONSTRUCTION_OFFICE"] and \
		   not be.is_under_construction and not be.assigned_workers.is_empty():
			result.append(be)
	return result

func get_total_beds() -> int:
	var total: int = 0
	for b in buildings:
		var be: BuildingEntity = b
		if be.btype == "HOUSING" and not be.is_under_construction:
			total += be.max_residents
	return total

func get_occupied_beds() -> int:
	var total: int = 0
	for b in buildings:
		var be: BuildingEntity = b
		if be.btype == "HOUSING" and not be.is_under_construction:
			total += be.residents.size()
	return total

func serialize() -> Array:
	var result: Array = []
	for b in buildings:
		var be: BuildingEntity = b
		result.append(be.serialize())
	return result

func deserialize(data: Array, world: Array) -> void:
	buildings = []
	for bd in data:
		var b: BuildingEntity = BuildingEntity.deserialize(bd as Dictionary)
		if b == null: continue
		if b.tile_x < world.size():
			var col: Array = world[b.tile_x]
			if b.tile_y < col.size():
				col[b.tile_y]["building"] = b
		buildings.append(b)

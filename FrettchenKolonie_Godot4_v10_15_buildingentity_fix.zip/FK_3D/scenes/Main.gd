## Main.gd  –  baut die gesamte Szene zur Laufzeit auf.
## Kein .tscn-Layout, daher keine Anker-Bugs.
extends Node

var _main_menu:     Control
var _world_creation: Control
var _game_screen:   Node3D
var _game_ctrl:     Node = null
var _game_over_screen: Control = null
var _go_cause_label:    Label   = null

func _ready() -> void:
	_build_main_menu()
	_build_world_creation()
	_build_game_screen()
	GameState.state_changed.connect(_on_state_changed)
	# Crash-Fix (UI verschwindet + "Absturz" ins Hauptmenue): Game Over hatte
	# bisher KEINE eigene Anzeige - der Bildschirm fror fuer 5 Sekunden ein
	# (HUD/Bau-Menue blenden sich bei jedem Nicht-PLAYING-Zustand automatisch
	# aus) und sprang danach kommentarlos ins Hauptmenue. Das sah fuer
	# Spieler genau wie ein Absturz aus. Jetzt zeigt ein richtiger
	# Game-Over-Bildschirm den Grund an und der Spieler kehrt per Klick
	# bewusst ins Hauptmenue zurueck.
	GameState.game_over_triggered.connect(_on_game_over_triggered)
	GameState.set_state(GameState.State.MAIN_MENU)

func _on_game_over_triggered(cause: String) -> void:
	if _go_cause_label: _go_cause_label.text = cause

# ── Utility ───────────────────────────────────────────────────────────────────
func _full_rect(node: Control) -> Control:
	node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return node

func _lbl(text: String, size: int = 13, col: Color = Color.WHITE) -> Label:
	var l := Label.new(); l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l

func _spacer(h: int) -> Control:
	var c := Control.new(); c.custom_minimum_size = Vector2(0, h); return c

func _btn(text: String, size: int = 14, min_h: int = 44) -> Button:
	var b := Button.new(); b.text = text
	b.custom_minimum_size = Vector2(280, min_h)
	b.add_theme_font_size_override("font_size", size)
	return b

# ══════════════════════════════════════════════════════════════════════════════
# MAIN MENU
# ══════════════════════════════════════════════════════════════════════════════
func _build_main_menu() -> void:
	_main_menu = Control.new(); _main_menu.name = "MainMenu"
	_full_rect(_main_menu)
	add_child(_main_menu)

	var bg := ColorRect.new(); bg.color = Color(0.05,0.07,0.12)
	_full_rect(bg); _main_menu.add_child(bg)

	var cc := CenterContainer.new()
	_full_rect(cc); _main_menu.add_child(cc)

	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 14)
	cc.add_child(vbox)

	var title_lbl := _lbl("FrettchenKolonie", 38, Color(0.96,0.69,0.1))
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_lbl)
	var sub_lbl := _lbl("v10.0 – 3D Edition", 14, Color(0.5,0.5,0.5))
	sub_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(sub_lbl)
	vbox.add_child(_spacer(20))

	var nb := _btn("Neue Welt starten", 18, 52); nb.pressed.connect(_show_world_creation); vbox.add_child(nb)
	var lb := _btn("Laden (Quicksave)",  16, 48); lb.pressed.connect(_try_load);           vbox.add_child(lb)

# ══════════════════════════════════════════════════════════════════════════════
# WORLD CREATION
# ══════════════════════════════════════════════════════════════════════════════
var _name_input:    LineEdit
var _seed_input:    LineEdit
var _size_option:   OptionButton
var _seed_preview:  Label

func _build_world_creation() -> void:
	_world_creation = Control.new(); _world_creation.name = "WorldCreation"
	_full_rect(_world_creation); _world_creation.visible = false
	add_child(_world_creation)

	var bg := ColorRect.new(); bg.color = Color(0.05,0.07,0.12)
	_full_rect(bg); _world_creation.add_child(bg)

	var cc := CenterContainer.new(); _full_rect(cc); _world_creation.add_child(cc)
	var panel := PanelContainer.new(); panel.custom_minimum_size = Vector2(440,0); cc.add_child(panel)
	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",11); panel.add_child(vbox)

	vbox.add_child(_lbl("Neue Welt erstellen", 22, Color(0.96,0.69,0.1)))
	vbox.add_child(_lbl("Kolonienname:", 13))
	_name_input = LineEdit.new(); _name_input.text = "Meine Kolonie"
	_name_input.custom_minimum_size = Vector2(0,38); vbox.add_child(_name_input)

	vbox.add_child(_lbl("Seed (leer = zufaellig):", 13))
	_seed_input = LineEdit.new(); _seed_input.placeholder_text = "Leer = Zufaellig"
	_seed_input.custom_minimum_size = Vector2(0,38); vbox.add_child(_seed_input)
	_seed_preview = _lbl("Seed: Zufaellig", 12, Color(0.5,0.5,0.5)); vbox.add_child(_seed_preview)
	_seed_input.text_changed.connect(func(t: String):
		_seed_preview.text = "Seed-Hash: %d" % t.hash() if t.strip_edges()!="" else "Seed: Zufaellig")

	vbox.add_child(_lbl("Weltgroesse:", 13))
	_size_option = OptionButton.new(); _size_option.custom_minimum_size = Vector2(0,38)
	for s in ["Klein (40x40)","Mittel (60x60)","Gross (80x80)"]: _size_option.add_item(s)
	_size_option.selected = 1; vbox.add_child(_size_option)
	vbox.add_child(_spacer(6))

	var sb := _btn("Kolonie gruenden!", 16, 50)
	sb.add_theme_color_override("font_color", Color(0.3,1.0,0.4)); sb.pressed.connect(_on_start_game); vbox.add_child(sb)
	var bb := _btn("Zurueck", 14, 44); bb.pressed.connect(_show_main_menu); vbox.add_child(bb)

# ══════════════════════════════════════════════════════════════════════════════
# GAME SCREEN
# ══════════════════════════════════════════════════════════════════════════════
func _build_game_screen() -> void:
	_game_screen = Node3D.new(); _game_screen.name = "GameScreen"; _game_screen.visible = false

	# Camera3D – isometrisch, orthographisch
	var cam := Camera3D.new(); cam.name = "Camera3D"
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = 28.0
	_game_screen.add_child(cam)

	# 3D-Renderer
	var rend := WorldRenderer3D.new(); rend.name = "WorldRenderer3D"
	_game_screen.add_child(rend)

	# Beleuchtung
	var dir_light := DirectionalLight3D.new(); dir_light.name = "Sun"
	dir_light.rotation_degrees = Vector3(-55.0, 45.0, 0.0)
	dir_light.light_energy = 1.15
	dir_light.shadow_enabled = true
	_game_screen.add_child(dir_light)

	var fill_light := DirectionalLight3D.new(); fill_light.name = "Fill"
	fill_light.rotation_degrees = Vector3(-30.0, -135.0, 0.0)
	fill_light.light_energy = 0.35
	fill_light.shadow_enabled = false
	_game_screen.add_child(fill_light)

	var world_env := WorldEnvironment.new(); world_env.name = "WorldEnv"
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color  = Color(0.30, 0.34, 0.44)
	env.ambient_light_energy = 0.55
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.52, 0.65, 0.78)
	world_env.environment = env
	_game_screen.add_child(world_env)

	# CanvasLayer hält alle UI-Elemente
	var canvas := CanvasLayer.new(); canvas.name = "GameUI"
	_game_screen.add_child(canvas)

	# UIRoot: ein Control das den ganzen Viewport füllt, Eltern aller HUD-Nodes
	# Muss NACH add_child zu _game_screen sitzen, damit Viewport-Größe bekannt ist.
	# Wir erzwingen die Größe über _notification(NOTIFICATION_WM_SIZE_CHANGED).
	var ui_root := _make_ui_root(); canvas.add_child(ui_root)

	_build_hud(ui_root)
	_build_build_menu(ui_root)
	_build_building_info(ui_root)
	_build_placement_hint(ui_root)
	_build_pause_menu(ui_root)
	_build_notifications(ui_root)
	_build_game_over_screen(ui_root)
	_build_tutorial(ui_root)
	_build_expedition_panel(ui_root)
	_build_graveyard_panel(ui_root)

	# Script setzen NACHDEM alle Kinder vorhanden sind, DANN in Baum hängen
	_game_screen.set_script(load("res://game/GameController.gd") as GDScript)
	add_child(_game_screen)
	_game_ctrl = _game_screen

func _make_ui_root() -> Control:
	var r := Control.new(); r.name = "UIRoot"
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r

func _build_hud(root: Control) -> void:
	var hud := Control.new(); hud.name = "HUD"
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.anchor_right=1.0; hud.anchor_bottom=1.0
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.set_script(load("res://ui/HUD.gd") as GDScript)
	root.add_child(hud)

	# TopBar – bleibt oben über die ganze Breite
	var topbar := HBoxContainer.new(); topbar.name = "TopBar"
	topbar.set_anchors_preset(Control.PRESET_TOP_WIDE)
	topbar.anchor_right = 1.0; topbar.offset_bottom = 38
	topbar.add_theme_constant_override("separation", 8)
	hud.add_child(topbar)

	var bg := ColorRect.new(); bg.name = "BgRect"
	bg.color = Color(0.05,0.07,0.12,0.88); bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.anchor_right=1.0; bg.anchor_bottom=1.0
	topbar.add_child(bg)

	var rd := HBoxContainer.new(); rd.name = "ResourceDisplay"
	rd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rd.add_theme_constant_override("separation", 8); topbar.add_child(rd)

	for pair in [["TimeLabel","06:00"],["SeasonLabel","Fruehling"],
						["DroughtLabel",""],["PopLabel","F 5"]]:
		var l := Label.new(); l.name = pair[0]; l.text = pair[1]
		l.add_theme_font_size_override("font_size", 13)
		if pair[0] == "DroughtLabel":
			l.visible = false; l.add_theme_color_override("font_color",Color(0.85,0.2,0.1))
		topbar.add_child(l)

	for pair2 in [["StorageBar",60],["WaterBar",50]]:
		var pb := ProgressBar.new(); pb.name = pair2[0]
		pb.custom_minimum_size = Vector2(pair2[1], 18); topbar.add_child(pb)

	# Speedbuttons – rechts oben
	var srow := HBoxContainer.new(); srow.name = "SpeedButtons"
	srow.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	srow.anchor_left=1.0; srow.anchor_right=1.0
	srow.offset_left=-168; srow.offset_top=42; srow.offset_right=-4; srow.offset_bottom=70
	srow.add_theme_constant_override("separation",4); hud.add_child(srow)
	for pair3 in [["PauseBtn","||"],["Btn1","1x"],["Btn2","2x"],["Btn3","3x"]]:
		var b := Button.new(); b.name = pair3[0]; b.text = pair3[1]
		b.custom_minimum_size = Vector2(36,28); srow.add_child(b)

	# Bug-Fix (v10.14): "Expeditionen sind implementiert, aber nicht
	# erreichbar" - ExpeditionPanel.gd/GraveyardPanel.gd existierten bereits
	# vollstaendig, wurden aber nie irgendwo im UI-Baum erzeugt UND es gab
	# keinen Button, um sie zu oeffnen. Zwei zusaetzliche Buttons unterhalb
	# der Geschwindigkeits-Buttons; die eigentliche Verdrahtung (Panels
	# oeffnen) passiert in HUD.gd._ready().
	var srow2 := HBoxContainer.new(); srow2.name = "ExtraButtons"
	srow2.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	srow2.anchor_left=1.0; srow2.anchor_right=1.0
	srow2.offset_left=-168; srow2.offset_top=74; srow2.offset_right=-4; srow2.offset_bottom=102
	srow2.add_theme_constant_override("separation",4); hud.add_child(srow2)
	for pair4 in [["ExpeditionBtn","🗺️"],["GraveyardBtn","🪦"]]:
		var b4 := Button.new(); b4.name = pair4[0]; b4.text = pair4[1]
		b4.custom_minimum_size = Vector2(36,28); srow2.add_child(b4)

func _build_build_menu(root: Control) -> void:
	var bm := PanelContainer.new(); bm.name = "BuildMenu"
	bm.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	bm.anchor_bottom = 1.0; bm.offset_right = 224
	# Bug-Fix (UI-Überlappung: Ressourcenanzeige lag unter dem Bau-Menü):
	# Die TopBar (HUD) ist 38px hoch und geht über die volle Breite, das
	# Bau-Menü begann aber bei y=0 (volle Höhe) und wurde NACH dem HUD
	# hinzugefügt -> es lag über der TopBar in der oberen linken Ecke und
	# verdeckte Zeit/Jahreszeit/Ressourcen-Anzeige. Jetzt beginnt es erst
	# unterhalb der TopBar.
	bm.offset_top = 38
	bm.set_script(load("res://ui/BuildMenu.gd") as GDScript)
	root.add_child(bm)

	var outer := VBoxContainer.new(); outer.name="Outer"; outer.size_flags_vertical=Control.SIZE_EXPAND_FILL; bm.add_child(outer)
	var hdr := HBoxContainer.new(); hdr.name="Header"; outer.add_child(hdr)
	# Bug-Fix (fehlender Epochen-Button): vorher nur ein Label ohne Funktion.
	# Jetzt ein klickbarer Button, der die naechste Epoche samt Kosten zeigt
	# und per Klick freischaltet, sobald genug Ressourcen vorhanden sind.
	var el := Button.new(); el.name="EpochBtn"; el.text="Epoche 1"
	el.add_theme_font_size_override("font_size", 11)
	el.size_flags_horizontal=Control.SIZE_EXPAND_FILL; hdr.add_child(el)
	var tb := Button.new(); tb.name="ToggleBtn"; tb.text="<<"; hdr.add_child(tb)
	var sc := ScrollContainer.new(); sc.name="ScrollContainer"
	sc.size_flags_vertical=Control.SIZE_EXPAND_FILL; outer.add_child(sc)
	var vb := VBoxContainer.new(); vb.name="VBoxContainer"
	vb.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation",3); sc.add_child(vb)

func _build_building_info(root: Control) -> void:
	var bi := PanelContainer.new(); bi.name="BuildingInfo"
	bi.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	bi.anchor_top=1.0; bi.anchor_bottom=1.0
	bi.offset_left=230; bi.offset_top=-312; bi.offset_right=534; bi.offset_bottom=-4
	bi.visible=false
	bi.set_script(load("res://ui/BuildingInfo.gd") as GDScript)
	root.add_child(bi)

	var vb := VBoxContainer.new(); vb.name="VBox"; vb.add_theme_constant_override("separation",8); bi.add_child(vb)
	var trow := HBoxContainer.new(); trow.name="TitleRow"; vb.add_child(trow)
	var tl := Label.new(); tl.name="TitleLabel"; tl.text="Gebaeude"
	tl.size_flags_horizontal=Control.SIZE_EXPAND_FILL; tl.add_theme_font_size_override("font_size",14); trow.add_child(tl)
	var cl := Button.new(); cl.name="CloseBtn"; cl.text="X"; trow.add_child(cl)
	var sl:=Label.new(); sl.name="StatusLabel"; sl.text=""; vb.add_child(sl)
	# Bug-Fix/Feature (Arbeiter-Zuweisung manuell steuern): vorher nur ein
	# reines Anzeige-Label ("Arbeiter: 2/3") ohne Funktion. Jetzt mit "-"/"+"
	# Buttons, um direkt zu steuern, wie viele Frettchen hier arbeiten.
	var wrow:=HBoxContainer.new(); wrow.name="WorkerRow"; wrow.add_theme_constant_override("separation",6); vb.add_child(wrow)
	var wl:=Label.new(); wl.name="WorkersLabel"; wl.text=""; wl.size_flags_horizontal=Control.SIZE_EXPAND_FILL; wrow.add_child(wl)
	var wm:=Button.new(); wm.name="WorkerMinusBtn"; wm.text="-"; wm.custom_minimum_size=Vector2(30,0); wrow.add_child(wm)
	var wp:=Button.new(); wp.name="WorkerPlusBtn";  wp.text="+"; wp.custom_minimum_size=Vector2(30,0); wrow.add_child(wp)
	var dl:=Label.new(); dl.name="DescLabel"; dl.text=""
	dl.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; dl.add_theme_font_size_override("font_size",12)
	vb.add_child(dl)
	var pb:=ProgressBar.new(); pb.name="ProgressBar"; pb.custom_minimum_size=Vector2(0,14); vb.add_child(pb)
	var pr:=HBoxContainer.new(); pr.name="PriorityRow"; vb.add_child(pr)
	var pl:=Label.new(); pl.name="PriorityLabel"; pl.text="Prioritaet: 3"; pr.add_child(pl)
	var ps:=HSlider.new(); ps.name="PrioritySlider"; ps.min_value=1; ps.max_value=5; ps.step=1; ps.value=3
	ps.size_flags_horizontal=Control.SIZE_EXPAND_FILL; pr.add_child(ps)
	var brow:=HBoxContainer.new(); brow.name="Buttons"; vb.add_child(brow)
	for p2 in [["UpgradeBtn","Upgrade"],["SellBtn","Verkaufen"]]:
		var b:=Button.new(); b.name=p2[0]; b.text=p2[1]; b.size_flags_horizontal=Control.SIZE_EXPAND_FILL; brow.add_child(b)

## Bug-Fix (v10.14): ExpeditionPanel.gd baut seine UI komplett selbst dynamisch
## in _refresh() (siehe dort) - hier muss nur der PanelContainer mit Skript
## existieren und zentriert auf dem Bildschirm sitzen, standardmaessig
## versteckt (das macht das Panel selbst in _ready() via hide()).
func _build_expedition_panel(root: Control) -> void:
	var ep := PanelContainer.new(); ep.name = "ExpeditionPanel"
	ep.set_anchors_preset(Control.PRESET_CENTER)
	ep.offset_left = -170; ep.offset_top = -150; ep.offset_right = 170; ep.offset_bottom = 150
	ep.set_script(load("res://ui/ExpeditionPanel.gd") as GDScript)
	root.add_child(ep)

func _build_graveyard_panel(root: Control) -> void:
	var gp := PanelContainer.new(); gp.name = "GraveyardPanel"
	gp.set_anchors_preset(Control.PRESET_CENTER)
	gp.offset_left = -180; gp.offset_top = -160; gp.offset_right = 180; gp.offset_bottom = 160
	gp.set_script(load("res://ui/GraveyardPanel.gd") as GDScript)
	root.add_child(gp)

func _build_placement_hint(root: Control) -> void:
	var h := Label.new(); h.name="PlacementHint"
	h.set_anchors_preset(Control.PRESET_CENTER_TOP)
	h.anchor_left=0.5; h.anchor_right=0.5
	h.offset_left=-240; h.offset_top=44; h.offset_right=240; h.offset_bottom=70
	h.text="Klicken zum Platzieren  |  ESC = Abbrechen"
	h.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; h.visible=false
	h.add_theme_font_size_override("font_size",13)
	h.add_theme_color_override("font_color",Color(0.96,0.69,0.1))
	root.add_child(h)

func _build_pause_menu(root: Control) -> void:
	var cc := CenterContainer.new(); cc.name="PauseMenu"
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.anchor_right=1.0; cc.anchor_bottom=1.0; cc.visible=false
	cc.set_script(load("res://ui/PauseMenu.gd") as GDScript)
	root.add_child(cc)

	var panel:=PanelContainer.new(); panel.name="Panel"; panel.custom_minimum_size=Vector2(320,0); cc.add_child(panel)
	var vb:=VBoxContainer.new(); vb.name="VBox"; vb.add_theme_constant_override("separation",10); panel.add_child(vb)
	var tl:=Label.new(); tl.text="Pause"; tl.horizontal_alignment=1
	tl.add_theme_font_size_override("font_size",20); tl.add_theme_color_override("font_color",Color(0.96,0.69,0.1)); vb.add_child(tl)
	var rb:=Button.new(); rb.name="ResumeBtn"; rb.text="Weiterspielen"; rb.custom_minimum_size=Vector2(0,44); vb.add_child(rb)
	var ab:=VBoxContainer.new(); ab.name="Audio"; ab.add_theme_constant_override("separation",4); vb.add_child(ab)
	for p in [["MasterLabel","Master"],["MasterSlider",80.0],
					  ["MusicLabel","Musik"],["MusicSlider",60.0],
					  ["SfxLabel","Effekte"],["SfxSlider",70.0]]:
		if p[1] is String:
			ab.add_child(_lbl(p[1] as String, 12))
		else:
			var sl:=HSlider.new(); sl.name=p[0] as String; sl.min_value=0; sl.max_value=100; sl.value=p[1] as float; ab.add_child(sl)
	var sr:=HBoxContainer.new(); sr.name="Speed"; vb.add_child(sr)
	sr.add_child(_lbl("Geschwindigkeit:  ",13))
	for p2 in [["Btn1","1x"],["Btn2","2x"],["Btn3","3x"]]:
		var b:=Button.new(); b.name=p2[0]; b.text=p2[1]; sr.add_child(b)
	var svb:=Button.new(); svb.name="SaveBtn"; svb.text="Quicksave"; svb.custom_minimum_size=Vector2(0,44); vb.add_child(svb)
	var mb:=Button.new(); mb.name="MenuBtn"; mb.text="Hauptmenue"; mb.custom_minimum_size=Vector2(0,44); vb.add_child(mb)

func _build_notifications(root: Control) -> void:
	var nl:=Control.new(); nl.name="Notifications"
	nl.set_anchors_preset(Control.PRESET_FULL_RECT)
	nl.anchor_right=1.0; nl.anchor_bottom=1.0
	nl.mouse_filter=Control.MOUSE_FILTER_IGNORE
	nl.set_script(load("res://ui/NotificationLayer.gd") as GDScript)
	root.add_child(nl)

## Crash-Fix: richtiger Game-Over-Bildschirm statt stillem 5-Sekunden-Einfrieren.
func _build_game_over_screen(root: Control) -> void:
	_game_over_screen = Control.new(); _game_over_screen.name = "GameOverScreen"
	_game_over_screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	_game_over_screen.anchor_right = 1.0; _game_over_screen.anchor_bottom = 1.0
	_game_over_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	_game_over_screen.visible = false
	root.add_child(_game_over_screen)

	var bg := ColorRect.new(); bg.color = Color(0.04, 0.04, 0.06, 0.88)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.anchor_right = 1.0; bg.anchor_bottom = 1.0
	_game_over_screen.add_child(bg)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.anchor_right = 1.0; cc.anchor_bottom = 1.0
	_game_over_screen.add_child(cc)

	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)

	var title := _lbl("Deine Kolonie ist ausgestorben...", 22, Color(0.95, 0.35, 0.30))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	_go_cause_label = _lbl("", 14, Color(0.85, 0.85, 0.85))
	_go_cause_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_go_cause_label)

	vb.add_child(_spacer(10))
	var btn := _btn("Zum Hauptmenue")
	btn.pressed.connect(func(): GameState.set_state(GameState.State.MAIN_MENU))
	vb.add_child(btn)

## Tutorial wieder hinzugefuegt: Freddy Frettchen fuehrt neue Spieler durch
## die Grundlagen. Gestartet wird es in _on_start_game() (nur bei neuer
## Kolonie, nicht beim Laden eines Spielstands).
func _build_tutorial(root: Control) -> void:
	var tut := Control.new(); tut.name = "Tutorial"
	tut.set_script(load("res://ui/TutorialManager.gd") as GDScript)
	root.add_child(tut)


# ══════════════════════════════════════════════════════════════════════════════
# NAVIGATION
# ══════════════════════════════════════════════════════════════════════════════
func _show_main_menu() -> void:   GameState.set_state(GameState.State.MAIN_MENU)
func _show_world_creation() -> void: GameState.set_state(GameState.State.WORLD_CREATION)

func _try_load() -> void:
	if SaveSys.get_save_names().is_empty():
		GameState.notify("Keine Speicherstaende gefunden!", Color(0.8,0.2,0.1)); return
	if not SaveSys.get_save_names().has("quicksave"):
		GameState.notify("Kein Schnellspeicherstand (quicksave) gefunden!", Color(0.8,0.2,0.1)); return
	# Bug-Fix (v10.14): der Zustand wurde bisher VOR dem eigentlichen
	# load_game()-Aufruf auf PLAYING gesetzt. Gab es zwar irgendeinen Save,
	# aber keinen "quicksave", oder war die Datei defekt, lief das Spiel
	# trotzdem sichtbar im Spielmodus weiter - mit einer leeren/kaputten
	# Szene, da nie wirklich eine Welt geladen wurde (moegliche
	# Folgefehler bei Input/Renderer, die auf eine vorhandene Welt
	# erwarten). Jetzt wird der Zustand nur bei Erfolg umgeschaltet.
	var ok: bool = SaveSys.load_game("quicksave", _game_ctrl)
	if not ok:
		GameState.notify("Laden fehlgeschlagen - Speicherstand defekt oder unlesbar.", Color(0.8,0.2,0.1))
		return
	GameState.set_state(GameState.State.PLAYING)
	_game_screen.visible = true; _main_menu.visible = false

func _on_start_game() -> void:
	var wname: String = _name_input.text.strip_edges()
	if wname == "": wname = "Meine Kolonie"
	var seed_str: String = _seed_input.text.strip_edges()
	const SIZES: Array = ["SMALL","MEDIUM","LARGE"]
	var sz: String = str(SIZES[_size_option.selected])
	_game_ctrl.call("start_new_game", sz, seed_str, wname)
	var tut := get_node_or_null("GameScreen/GameUI/UIRoot/Tutorial")
	if tut and tut.has_method("start"): tut.call("start")

func _on_state_changed(state: GameState.State) -> void:
	_main_menu.visible     = (state == GameState.State.MAIN_MENU)
	_world_creation.visible = (state == GameState.State.WORLD_CREATION)
	_game_screen.visible   = state in [GameState.State.PLAYING, GameState.State.PAUSED, GameState.State.GAME_OVER]
	if _game_over_screen: _game_over_screen.visible = (state == GameState.State.GAME_OVER)

## PauseMenu.gd
extends CenterContainer

var _vol_master: HSlider = null
var _vol_music: HSlider  = null
var _vol_sfx: HSlider    = null

func _ready() -> void:
	hide()
	GameState.state_changed.connect(_on_state_changed)
	_vol_master = get_node_or_null("Panel/VBox/Audio/MasterSlider")
	_vol_music  = get_node_or_null("Panel/VBox/Audio/MusicSlider")
	_vol_sfx    = get_node_or_null("Panel/VBox/Audio/SfxSlider")
	_connect_btn("Panel/VBox/ResumeBtn", func(): _on_resume())
	_connect_btn("Panel/VBox/SaveBtn",   func(): _on_save())
	_connect_btn("Panel/VBox/MenuBtn",   func(): _on_main_menu())
	_connect_btn("Panel/VBox/Speed/Btn1", func(): GameState.set_game_speed(1.0))
	_connect_btn("Panel/VBox/Speed/Btn2", func(): GameState.set_game_speed(2.0))
	_connect_btn("Panel/VBox/Speed/Btn3", func(): GameState.set_game_speed(3.0))
	if _vol_master: _vol_master.value_changed.connect(func(_v): _update_volumes())
	if _vol_music:  _vol_music.value_changed.connect(func(_v): _update_volumes())
	if _vol_sfx:    _vol_sfx.value_changed.connect(func(_v): _update_volumes())

func _connect_btn(path: String, cb: Callable) -> void:
	var btn: Button = get_node_or_null(path)
	if btn: btn.pressed.connect(cb)

func _on_resume() -> void:
	GameState.set_state(GameState.State.PLAYING)
	GameState.game_speed = 1.0

func _on_save() -> void:
	var gc: Node = get_node_or_null("/root/Main/GameScreen")
	if gc: SaveSys.save("quicksave", gc)

func _on_main_menu() -> void:
	SoundSys.stop_music()
	GameState.set_state(GameState.State.MAIN_MENU)

func _update_volumes() -> void:
	SoundSys.set_volumes(
		_vol_master.value if _vol_master else 80.0,
		_vol_music.value  if _vol_music  else 60.0,
		_vol_sfx.value    if _vol_sfx    else 70.0
	)

func _on_state_changed(state: GameState.State) -> void:
	visible = (state == GameState.State.PAUSED)

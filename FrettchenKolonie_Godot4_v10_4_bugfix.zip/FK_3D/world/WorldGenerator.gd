## WorldGenerator.gd
class_name WorldGenerator
extends RefCounted

# ── Perlin Noise (innere Klasse) ──────────────────────────────────────────────
class PerlinNoise:
	var _perm: Array = []

	func _init(seed_val: int = 0) -> void:
		_perm.resize(512)
		var p: Array = []
		p.resize(256)
		for i in 256:
			p[i] = i
		var rng := RandomNumberGenerator.new()
		rng.seed = seed_val
		for i in range(255, 0, -1):
			var j: int = rng.randi_range(0, i)
			var tmp: int = p[i]
			p[i] = p[j]
			p[j] = tmp
		for i in 256:
			_perm[i] = p[i]
			_perm[i + 256] = p[i]

	func _fade(t: float) -> float:
		return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)

	func _lerpf(a: float, b: float, t: float) -> float:
		return a + t * (b - a)

	func _grad(h: int, x: float, y: float) -> float:
		match (h & 3):
			0: return  x + y
			1: return -x + y
			2: return  x - y
			3: return -x - y
		return 0.0

	# Renamed from get() to sample() to avoid conflict with Object.get()
	func sample(x: float, y: float) -> float:
		var xi: int = int(floor(x)) & 255
		var yi: int = int(floor(y)) & 255
		var xf: float = x - floor(x)
		var yf: float = y - floor(y)
		var u: float = _fade(xf)
		var v: float = _fade(yf)
		var aa: int = _perm[_perm[xi] + yi]
		var ab: int = _perm[_perm[xi] + yi + 1]
		var ba: int = _perm[_perm[xi + 1] + yi]
		var bb: int = _perm[_perm[xi + 1] + yi + 1]
		return _lerpf(
			_lerpf(_grad(aa, xf, yf),       _grad(ba, xf - 1.0, yf),       u),
			_lerpf(_grad(ab, xf, yf - 1.0), _grad(bb, xf - 1.0, yf - 1.0), u),
			v
		)

# ── Welt ──────────────────────────────────────────────────────────────────────
var w: int = 60
var h: int = 60
var seed_val: int = 0

func generate(world_size: String, seed_str: String) -> Array:
	match world_size:
		"SMALL":  w = 40; h = 40
		"MEDIUM": w = 60; h = 60
		"LARGE":  w = 80; h = 80

	seed_val = seed_str.strip_edges().hash() if seed_str.strip_edges() != "" else randi()

	var noise := PerlinNoise.new(seed_val)
	var world: Array = []

	for x in w:
		var col: Array = []
		for y in h:
			var nx: float = float(x) / float(w) * 4.0
			var ny: float = float(y) / float(h) * 4.0
			var n: float = (noise.sample(nx, ny) * 0.6
				+ noise.sample(nx * 2.0, ny * 2.0) * 0.3
				+ noise.sample(nx * 4.0, ny * 4.0) * 0.1)
			n = (n + 1.0) / 2.0

			var biome: String
			var height_val: float
			if n < 0.25:
				biome = "WATER";    height_val = 0.0
			elif n < 0.38:
				biome = "BEACH";    height_val = n * 5.0
			elif n < 0.6:
				biome = "PLAINS";   height_val = n * 8.0
			elif n < 0.72:
				biome = "FOREST";   height_val = n * 10.0
			elif n < 0.82:
				biome = "HILLS";    height_val = n * 12.0
			else:
				biome = "MOUNTAIN"; height_val = n * 16.0

			col.append({
				"biome": biome, "height": height_val,
				"building": null, "path": null,
				"resource_node": null, "dynamite": false
			})
		world.append(col)

	_place_resource_nodes(world, noise)
	_place_ruins(world)
	return world

func _place_resource_nodes(world: Array, _noise: PerlinNoise) -> void:
	var res_map: Dictionary = {
		"FOREST": "WOOD", "HILLS": "STONE",
		"PLAINS": "BERRIES", "MOUNTAIN": "IRON"
	}
	for x in w:
		for y in h:
			var tile: Dictionary = world[x][y]
			if tile["building"] != null: continue
			var biome: String = tile["biome"]
			if biome == "WATER" or biome == "BEACH": continue
			var res_type: String = res_map.get(biome, "")
			if res_type == "": continue
			if randf() < 0.35:
				tile["resource_node"] = {"type": res_type, "amount": randf_range(50.0, 200.0)}

func _place_ruins(world: Array) -> void:
	var count: int = randi_range(4, 8)
	for _i in count:
		for _attempt in 20:
			var rx: int = randi_range(5, w - 5)
			var ry: int = randi_range(5, h - 5)
			var tile: Dictionary = world[rx][ry]
			if tile["biome"] != "WATER" and tile["building"] == null:
				tile["ruin"] = true
				break

# ── Terrain-Editing (statische Hilfsmethoden) ─────────────────────────────────
static func raise_terrain(world: Array, tx: int, ty: int) -> bool:
	if tx < 0 or ty < 0 or tx >= world.size(): return false
	var col: Array = world[tx]
	if ty >= col.size(): return false
	var tile: Dictionary = col[ty]
	if tile["biome"] == "WATER" or tile["building"] != null:
		return false
	if not ResourceSys.has("STONE", 2):
		GameState.notify("Nicht genug Stein! (2 pro Tile)", Color(0.8, 0.2, 0.1))
		return false
	ResourceSys.remove("STONE", 2)
	tile["height"] = minf(20.0, float(tile["height"]) + 1.0)
	if float(tile["height"]) >= 14.0:
		tile["biome"] = "MOUNTAIN"
	elif float(tile["height"]) >= 5.0 and tile["biome"] == "WATER":
		tile["biome"] = "PLAINS"
	return true

static func place_dynamite(world: Array, tx: int, ty: int, explosions: Array) -> bool:
	if tx < 0 or ty < 0 or tx >= world.size(): return false
	var col: Array = world[tx]
	if ty >= col.size(): return false
	var tile: Dictionary = col[ty]
	if tile["building"] != null:
		GameState.notify("Sprengstoff nicht auf Gebaeude!", Color(0.8, 0.2, 0.1))
		return false
	if not bool(tile.get("dynamite", false)):
		if not ResourceSys.has("DYNAMITE", 1):
			GameState.notify("Kein Sprengstoff vorhanden!", Color(0.8, 0.2, 0.1))
			return false
		ResourceSys.remove("DYNAMITE", 1)
		tile["dynamite"] = true
		GameState.notify("Sprengstoff gelegt - nochmal klicken zum Zuenden!")
	else:
		tile["dynamite"] = false
		for dx in range(-1, 2):
			for dy in range(-1, 2):
				var nx: int = tx + dx
				var ny: int = ty + dy
				if nx < 0 or ny < 0 or nx >= world.size(): continue
				var ncol: Array = world[nx]
				if ny >= ncol.size(): continue
				var t: Dictionary = ncol[ny]
				if t["building"] != null: continue
				t["height"] = maxf(0.0, float(t["height"]) - 3.0)
				if float(t["height"]) <= 2.0:
					t["biome"] = "WATER"; t["height"] = 0.0
				elif float(t["height"]) < 5.0:
					t["biome"] = "PLAINS"
				t["resource_node"] = null
		explosions.append({"wx": tx, "wy": ty, "t": 0.0, "max_t": 1.2})
		SoundSys.play_explosion()
		GameState.notify("BOOM! Terrain geformt!", Color(1.0, 0.4, 0.1))
	return true

## WorldRenderer3D.gd
## Rendert die Spielwelt vollständig in 3D.
## Terrain = ein zusammengesetztes ArrayMesh mit Vertex-Farben.
## Gebäude = individuelle StaticBody3D + BoxMesh + Label3D.
## Frettchen = SphereMesh die sich auf ihren Tile-Koordinaten bewegen.
class_name WorldRenderer3D
extends Node3D

# ── Konstanten ────────────────────────────────────────────────────────────────
const TILE_SIZE:    float = 2.0   # Welteinheiten pro Tile
const HEIGHT_SCALE: float = 1.2   # Tile-Höhe in Welteinheiten
const FERRET_Y:     float = 0.35  # Frettchen-Offset über Boden

# Baum-Modell: ersetzt die reine Forest-Einfärbung des Terrains durch echte
# 3D-Bäume auf jedem Tile mit einem Holz-Resource-Node.
const PINE_TREE_SCENE: PackedScene = preload("res://assets/pine_tree.glb")
const TREE_BASE_SCALE: float = 0.6  # Modell ist ~4.7 Welteinheiten hoch (roh)
var _trees_node: Node3D = null

# ── Biom-Farben ───────────────────────────────────────────────────────────────
const BIOME_TOP: Dictionary = {
	"WATER":    Color(0.20, 0.48, 0.82),
	"BEACH":    Color(0.91, 0.86, 0.64),
	"PLAINS":   Color(0.42, 0.72, 0.32),
	"FOREST":   Color(0.24, 0.54, 0.22),
	"HILLS":    Color(0.58, 0.54, 0.40),
	"MOUNTAIN": Color(0.68, 0.65, 0.62),
}
const BIOME_SIDE: Dictionary = {
	"WATER":    Color(0.14, 0.35, 0.65),
	"BEACH":    Color(0.76, 0.72, 0.50),
	"PLAINS":   Color(0.30, 0.56, 0.22),
	"FOREST":   Color(0.16, 0.40, 0.14),
	"HILLS":    Color(0.44, 0.42, 0.30),
	"MOUNTAIN": Color(0.50, 0.48, 0.46),
}

# ── Gebäude-Visuals (Farbe + Höhe in Welteinheiten) ──────────────────────────
const BUILDING_VISUALS: Dictionary = {
	"CONSTRUCTION_YARD_1": {"color": Color(0.85,0.72,0.20), "h": 2.2},
	"CONSTRUCTION_YARD_2": {"color": Color(0.85,0.72,0.20), "h": 2.6},
	"ENGINEERS_GUILD":     {"color": Color(0.80,0.65,0.15), "h": 3.0},
	"CONSTRUCTION_OFFICE": {"color": Color(0.80,0.65,0.15), "h": 3.2},
	"LUMBERJACK":          {"color": Color(0.50,0.30,0.12), "h": 1.8},
	"QUARRY":              {"color": Color(0.62,0.60,0.55), "h": 1.2},
	"BERRY_GATHERER":      {"color": Color(0.65,0.25,0.45), "h": 1.5},
	"WELL":                {"color": Color(0.40,0.62,0.88), "h": 1.6},
	"WATER_TOWER":         {"color": Color(0.50,0.65,0.78), "h": 3.8},
	"WATER_PUMP":          {"color": Color(0.45,0.60,0.75), "h": 2.2},
	"AQUEDUCT":            {"color": Color(0.70,0.82,0.90), "h": 1.5},
	"RESERVOIR":           {"color": Color(0.30,0.55,0.80), "h": 1.2},
	"IRRIGATION":          {"color": Color(0.40,0.62,0.88), "h": 0.5},
	"STORAGE":             {"color": Color(0.88,0.68,0.32), "h": 2.2},
	"LARGE_STORAGE":       {"color": Color(0.82,0.60,0.28), "h": 2.8},
	"FOOD_STORE":          {"color": Color(0.75,0.88,0.50), "h": 2.4},
	"WAREHOUSE":           {"color": Color(0.80,0.65,0.30), "h": 3.0},
	"HOUSE":               {"color": Color(0.88,0.48,0.28), "h": 2.5},
	"GATHERING_PLACE":     {"color": Color(0.92,0.78,0.40), "h": 1.5},
	"TAVERN":              {"color": Color(0.80,0.35,0.18), "h": 2.8},
	"BATHHOUSE":           {"color": Color(0.62,0.72,0.88), "h": 2.6},
	"THEATER":             {"color": Color(0.72,0.30,0.62), "h": 3.5},
	"GARDEN":              {"color": Color(0.35,0.78,0.35), "h": 0.6},
	"CROP_FIELD":          {"color": Color(0.88,0.82,0.30), "h": 0.4},
	"WHEAT_FARM":          {"color": Color(0.85,0.80,0.25), "h": 0.5},
	"FORESTER":            {"color": Color(0.20,0.55,0.20), "h": 1.8},
	"SAWMILL":             {"color": Color(0.55,0.35,0.15), "h": 2.0},
	"WORKSHOP":            {"color": Color(0.70,0.55,0.35), "h": 2.2},
	"COOKHOUSE":           {"color": Color(0.75,0.40,0.20), "h": 2.0},
	"HUNTER_HUT":          {"color": Color(0.45,0.30,0.18), "h": 1.8},
	"EXPEDITION_CAMP":     {"color": Color(0.60,0.55,0.38), "h": 1.5},
	"GRAVEYARD":           {"color": Color(0.40,0.42,0.42), "h": 0.8},
	"IRON_MINE":           {"color": Color(0.50,0.48,0.45), "h": 2.0},
	"COAL_MINE":           {"color": Color(0.25,0.25,0.28), "h": 1.8},
	"SMELTER":             {"color": Color(0.80,0.35,0.10), "h": 3.0},
	"BLAST_FURNACE":       {"color": Color(0.85,0.30,0.08), "h": 3.5},
	"MACHINE_FACTORY":     {"color": Color(0.40,0.40,0.50), "h": 3.8},
	"WATERWHEEL":          {"color": Color(0.55,0.42,0.22), "h": 2.5},
	"STATUE":              {"color": Color(0.85,0.82,0.72), "h": 4.0},
	"DYNAMITE_WORKSHOP":   {"color": Color(0.75,0.15,0.15), "h": 2.0},
	"DECO_FLOWERS":        {"color": Color(0.95,0.55,0.70), "h": 0.4},
	"DECO_MUSHROOM":       {"color": Color(0.85,0.30,0.20), "h": 0.6},
	"DECO_LANTERN":        {"color": Color(0.95,0.90,0.40), "h": 0.8},
	"DECO_STONES":         {"color": Color(0.60,0.58,0.55), "h": 0.5},
	"DECO_BUSH":           {"color": Color(0.30,0.65,0.25), "h": 0.7},
}

const BUILDING_EMOJIS: Dictionary = {
	"CONSTRUCTION_YARD_1":"🏗","CONSTRUCTION_YARD_2":"🏗",
	"ENGINEERS_GUILD":"🏗","CONSTRUCTION_OFFICE":"🏗",
	"LUMBERJACK":"🪓","QUARRY":"⛏","BERRY_GATHERER":"🫐",
	"WELL":"🪣","WATER_TOWER":"⛲","WATER_PUMP":"🚿",
	"AQUEDUCT":"🌊","IRRIGATION":"💧","RESERVOIR":"🏗",
	"STORAGE":"📦","LARGE_STORAGE":"📦","FOOD_STORE":"🍱",
	"WAREHOUSE":"📦","HOUSE":"🏠","GATHERING_PLACE":"🎪",
	"TAVERN":"🍺","BATHHOUSE":"🛁","THEATER":"🎭",
	"GARDEN":"🌻","CROP_FIELD":"🌾","WHEAT_FARM":"🌾",
	"FORESTER":"🌲","SAWMILL":"🪚","WORKSHOP":"🔨",
	"COOKHOUSE":"🍲","HUNTER_HUT":"🏹","EXPEDITION_CAMP":"🗺",
	"GRAVEYARD":"🪦","IRON_MINE":"⛏","COAL_MINE":"⚫",
	"SMELTER":"🔥","BLAST_FURNACE":"🔥","MACHINE_FACTORY":"🤖",
	"WATERWHEEL":"⚙","STATUE":"🗿","DYNAMITE_WORKSHOP":"🧨",
	"DECO_FLOWERS":"🌸","DECO_MUSHROOM":"🍄","DECO_LANTERN":"🪔",
	"DECO_STONES":"🪨","DECO_BUSH":"🌿",
}

# ── State ─────────────────────────────────────────────────────────────────────
var world:    Array = []
var world_w:  int   = 60
var world_h:  int   = 60
var is_drought: bool = false

# Selektion / Ghost
var selected_tile:     Vector2i = Vector2i(-1, -1)
var selected_building: BuildingEntity = null

# ── Interne Nodes ─────────────────────────────────────────────────────────────
var _terrain_node:    MeshInstance3D = null
var _col_body:        StaticBody3D   = null
var _building_root:   Node3D         = null
var _building_nodes:  Dictionary     = {}   # "tx,ty" → StaticBody3D
var _ferret_root:     Node3D         = null
var _ferret_nodes:    Array          = []
var _highlight_node:  MeshInstance3D = null
var _ghost_node:      MeshInstance3D = null

# ── Materialien ───────────────────────────────────────────────────────────────
var _sel_mat:   StandardMaterial3D = null
var _ghost_mat: StandardMaterial3D = null

# ══════════════════════════════════════════════════════════════════════════════
func _ready() -> void:
	_building_root = Node3D.new(); _building_root.name = "Buildings"
	add_child(_building_root)
	_ferret_root = Node3D.new(); _ferret_root.name = "Ferrets"
	add_child(_ferret_root)
	_create_highlight()
	_create_ghost()

# ── Koordinaten ───────────────────────────────────────────────────────────────
func tile_to_world3d(tx: int, ty: int) -> Vector3:
	if world.is_empty():
		return Vector3(float(tx) * TILE_SIZE + TILE_SIZE * 0.5, 0.0,
					   float(ty) * TILE_SIZE + TILE_SIZE * 0.5)
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h:
		return Vector3(float(tx) * TILE_SIZE + TILE_SIZE * 0.5, 0.0,
					   float(ty) * TILE_SIZE + TILE_SIZE * 0.5)
	var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
	var h: float = float(tile.get("height", 0.0)) * HEIGHT_SCALE
	return Vector3(
		float(tx) * TILE_SIZE + TILE_SIZE * 0.5,
		h,
		float(ty) * TILE_SIZE + TILE_SIZE * 0.5
	)

func world3d_to_tile(pos: Vector3) -> Vector2i:
	return Vector2i(
		int(pos.x / TILE_SIZE),
		int(pos.z / TILE_SIZE)
	)

func map_center_3d() -> Vector3:
	@warning_ignore("integer_division")
	return tile_to_world3d(world_w / 2, world_h / 2)

# ══════════════════════════════════════════════════════════════════════════════
# WELT BAUEN
# ══════════════════════════════════════════════════════════════════════════════
func build_world() -> void:
	_clear_all()
	_build_terrain_mesh()
	_build_collision()
	_rebuild_all_buildings()
	_place_trees()

func _clear_all() -> void:
	if _terrain_node: _terrain_node.queue_free(); _terrain_node = null
	if _col_body:     _col_body.queue_free();     _col_body = null
	if _trees_node:   _trees_node.queue_free();   _trees_node = null
	for key in _building_nodes:
		(_building_nodes[key] as Node).queue_free()
	_building_nodes.clear()
	_clear_ferrets()

## Stellt echte 3D-Bäume (Kiefer, GLB-Modell) auf jedes Tile, das einen
## Holz-Resource-Node trägt (gesetzt vom WorldGenerator auf ~35% der
## FOREST-Tiles). Ersetzt die bisherige rein farbliche "Wald"-Darstellung.
func _place_trees() -> void:
	if _trees_node:
		_trees_node.queue_free()
		_trees_node = null
	_trees_node = Node3D.new()
	_trees_node.name = "Trees"
	add_child(_trees_node)
	for x in world_w:
		var col: Array = world[x] as Array
		for y in world_h:
			var tile: Dictionary = col[y] as Dictionary
			if tile.get("building") != null: continue
			var node_data = tile.get("resource_node")
			if node_data == null or not (node_data is Dictionary): continue
			if str((node_data as Dictionary).get("type","")) != "WOOD": continue
			var tree := PINE_TREE_SCENE.instantiate() as Node3D
			var base_pos: Vector3 = tile_to_world3d(x, y)
			# leichter Zufalls-Versatz innerhalb des Tiles, sonst wirkt es zu gitterartig
			base_pos.x += randf_range(-TILE_SIZE*0.28, TILE_SIZE*0.28)
			base_pos.z += randf_range(-TILE_SIZE*0.28, TILE_SIZE*0.28)
			tree.position = base_pos
			tree.rotation.y = randf_range(0.0, TAU)
			var s: float = TREE_BASE_SCALE * randf_range(0.85, 1.15)
			tree.scale = Vector3(s, s, s)
			_trees_node.add_child(tree)

# ── Terrain-Mesh ──────────────────────────────────────────────────────────────
func _build_terrain_mesh() -> void:
	if _terrain_node:
		_terrain_node.queue_free()
		_terrain_node = null

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.88
	mat.metallic  = 0.0
	st.set_material(mat)

	for x in world_w:
		for z in world_h:
			var tile: Dictionary = (world[x] as Array)[z] as Dictionary
			var biome: String    = str(tile.get("biome", "PLAINS"))
			var h: float         = float(tile.get("height", 0.0)) * HEIGHT_SCALE

			var top_c:  Color = BIOME_TOP.get(biome,  BIOME_TOP["PLAINS"])  as Color
			var side_c: Color = BIOME_SIDE.get(biome, BIOME_SIDE["PLAINS"]) as Color

			# Dürre-Tinting
			if is_drought and biome in ["PLAINS", "FOREST", "BEACH"]:
				top_c  = top_c.lerp(Color(0.72, 0.60, 0.28), 0.42)
				side_c = side_c.lerp(Color(0.60, 0.48, 0.20), 0.42)

			# Weg-Tinting
			if tile.get("path") != null:
				top_c = top_c.lerp(Color(0.55, 0.50, 0.40), 0.50)

			_add_top_quad(st, x, z, h, top_c)
			if h > 0.05:
				_add_side_quads(st, x, z, h, side_c)

	st.generate_normals()
	_terrain_node = MeshInstance3D.new()
	_terrain_node.name = "Terrain"
	_terrain_node.mesh = st.commit()
	_terrain_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_terrain_node)

func _add_top_quad(st: SurfaceTool, tx: int, tz: int, h: float, color: Color) -> void:
	var x0: float = float(tx) * TILE_SIZE
	var x1: float = x0 + TILE_SIZE
	var z0: float = float(tz) * TILE_SIZE
	var z1: float = z0 + TILE_SIZE
	st.set_color(color)
	st.set_normal(Vector3.UP)
	st.add_vertex(Vector3(x0, h, z0)); st.add_vertex(Vector3(x1, h, z0)); st.add_vertex(Vector3(x1, h, z1))
	st.add_vertex(Vector3(x0, h, z0)); st.add_vertex(Vector3(x1, h, z1)); st.add_vertex(Vector3(x0, h, z1))

func _add_side_quads(st: SurfaceTool, tx: int, tz: int, h: float, color: Color) -> void:
	var x0: float = float(tx) * TILE_SIZE
	var x1: float = x0 + TILE_SIZE
	var z0: float = float(tz) * TILE_SIZE
	var z1: float = z0 + TILE_SIZE
	var dark: Color = color.darkened(0.25)
	# Seite Z-  (Vorderseite vom Spieler aus)
	st.set_color(dark); st.set_normal(Vector3(0, 0, -1))
	st.add_vertex(Vector3(x0, h, z0)); st.add_vertex(Vector3(x1, h, z0)); st.add_vertex(Vector3(x1, 0, z0))
	st.add_vertex(Vector3(x0, h, z0)); st.add_vertex(Vector3(x1, 0, z0)); st.add_vertex(Vector3(x0, 0, z0))
	# Seite X-
	st.set_color(dark.darkened(0.1)); st.set_normal(Vector3(-1, 0, 0))
	st.add_vertex(Vector3(x0, h, z1)); st.add_vertex(Vector3(x0, h, z0)); st.add_vertex(Vector3(x0, 0, z0))
	st.add_vertex(Vector3(x0, h, z1)); st.add_vertex(Vector3(x0, 0, z0)); st.add_vertex(Vector3(x0, 0, z1))

# ── Terrain-Kollision (für Raycast) ──────────────────────────────────────────
## Bug-Fix (Klick-Versatz): Die Kollision wurde bisher als FLACHE Box bei y=0
## gebaut, unabhaengig von der tatsaechlichen (variierenden) Tile-Hoehe. Der
## Raycast traf also bei jedem nicht-flachen Tile (Huegel/Berge - praktisch
## ueberall, da WorldGenerator fast immer eine Hoehe > 0 erzeugt) eine falsche
## Ebene, wodurch der getroffene Weltpunkt und damit das ausgewaehlte Tile
## gegenueber der echten Mausposition versetzt war. Fix: Kollisionsform wird
## jetzt direkt aus dem sichtbaren Terrain-Mesh erzeugt (Trimesh), sodass der
## Raycast exakt die gerenderte Oberflaeche trifft.
func _build_collision() -> void:
	if _col_body:
		_col_body.queue_free()
		_col_body = null
	if _terrain_node == null or _terrain_node.mesh == null:
		return
	_col_body = StaticBody3D.new()
	_col_body.name = "TerrainCollider"
	_col_body.collision_layer = 1
	_col_body.collision_mask  = 0
	var cs := CollisionShape3D.new()
	cs.shape = _terrain_node.mesh.create_trimesh_shape()
	# Mesh-Vertices liegen bereits in absoluten Weltkoordinaten -> kein Offset.
	cs.position = Vector3.ZERO
	_col_body.add_child(cs)
	_col_body.position = Vector3.ZERO
	add_child(_col_body)

# ── Drought-Update ────────────────────────────────────────────────────────────
## Öffentliche API für Terrain-Neubau (Wege, Höhenänderungen).
## Baut auch die Kollision neu, da sich bei Hoehenaenderungen (z.B. Erde
## aufschuetten) sonst die Klickerkennung von der sichtbaren Oberflaeche
## entkoppeln wuerde (Klick-Versatz-Bug).
func refresh_terrain() -> void:
	_build_terrain_mesh()
	_build_collision()

func apply_drought(drought: bool) -> void:
	if drought == is_drought: return
	is_drought = drought
	_build_terrain_mesh()   # Farben neu backen

# ══════════════════════════════════════════════════════════════════════════════
# GEBÄUDE
# ══════════════════════════════════════════════════════════════════════════════
func _rebuild_all_buildings() -> void:
	for key in _building_nodes:
		(_building_nodes[key] as Node).queue_free()
	_building_nodes.clear()
	for x in world_w:
		for y in world_h:
			var tile: Dictionary = (world[x] as Array)[y] as Dictionary
			var bld = tile.get("building")
			if bld != null:
				_spawn_building(bld as BuildingEntity)

func refresh_buildings() -> void:
	_rebuild_all_buildings()

func add_building(b: BuildingEntity) -> void:
	var key: String = "%d,%d" % [b.tile_x, b.tile_y]
	if _building_nodes.has(key):
		(_building_nodes[key] as Node).queue_free()
		_building_nodes.erase(key)
	_spawn_building(b)

func remove_building(tx: int, ty: int) -> void:
	var key: String = "%d,%d" % [tx, ty]
	if _building_nodes.has(key):
		(_building_nodes[key] as Node).queue_free()
		_building_nodes.erase(key)

func _spawn_building(b: BuildingEntity) -> void:
	var key: String = "%d,%d" % [b.tile_x, b.tile_y]
	var wp:  Vector3 = tile_to_world3d(b.tile_x, b.tile_y)
	var vis: Dictionary = BUILDING_VISUALS.get(
		b.id, {"color": Color(0.65, 0.65, 0.65), "h": 2.0}
	) as Dictionary
	var bh:  float = float(vis.get("h",  2.0)) * (1.0 + float(b.level - 1) * 0.18)
	var col: Color = vis.get("color", Color(0.65, 0.65, 0.65)) as Color

	# ── Root ──
	var root := StaticBody3D.new()
	root.name = "Bld_%s" % key
	root.collision_layer = 2
	root.collision_mask  = 0
	root.set_meta("tile_x", b.tile_x)
	root.set_meta("tile_y", b.tile_y)

	# Kollision
	var cs    := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size   = Vector3(TILE_SIZE * 0.86, bh, TILE_SIZE * 0.86)
	cs.shape     = shape
	cs.position  = Vector3(0.0, bh * 0.5, 0.0)
	root.add_child(cs)

	# ── Hauptkörper ──
	var body_mi   := MeshInstance3D.new()
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(TILE_SIZE * 0.82, bh, TILE_SIZE * 0.82)
	body_mi.mesh   = body_mesh
	body_mi.position = Vector3(0.0, bh * 0.5, 0.0)

	var body_mat := StandardMaterial3D.new()
	if b.is_under_construction:
		body_mat.albedo_color = Color(0.90, 0.82, 0.42, 0.65)
		body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	else:
		body_mat.albedo_color = col
	body_mat.roughness = 0.72
	body_mi.material_override = body_mat
	root.add_child(body_mi)

	# ── Dach ──
	var roof_mi   := MeshInstance3D.new()
	var roof_mesh := BoxMesh.new()
	roof_mesh.size = Vector3(TILE_SIZE * 0.90, 0.22, TILE_SIZE * 0.90)
	roof_mi.mesh   = roof_mesh
	roof_mi.position = Vector3(0.0, bh + 0.11, 0.0)
	var roof_mat := StandardMaterial3D.new()
	roof_mat.albedo_color = col.darkened(0.32)
	roof_mat.roughness    = 0.80
	roof_mi.material_override = roof_mat
	if not b.is_under_construction:
		root.add_child(roof_mi)

	# ── Emoji-Label ──
	var lbl := Label3D.new()
	lbl.text       = BUILDING_EMOJIS.get(b.id, "🏠")
	lbl.pixel_size = 0.008
	lbl.font_size  = 60
	lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.no_depth_test = true
	lbl.position   = Vector3(0.0, bh + 0.9, 0.0)
	root.add_child(lbl)

	# ── Baustellen-Overlay ──
	if b.is_under_construction:
		var prog_lbl := Label3D.new()
		prog_lbl.text      = "🚧"
		prog_lbl.pixel_size = 0.008
		prog_lbl.font_size  = 48
		prog_lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
		prog_lbl.no_depth_test = true
		prog_lbl.position   = Vector3(0.0, bh + 1.7, 0.0)
		root.add_child(prog_lbl)

	root.position = wp
	_building_root.add_child(root)
	_building_nodes[key] = root

# ══════════════════════════════════════════════════════════════════════════════
# SELEKTION / GHOST
# ══════════════════════════════════════════════════════════════════════════════
func _create_highlight() -> void:
	_sel_mat = StandardMaterial3D.new()
	_sel_mat.albedo_color     = Color(1.0, 0.92, 0.18, 0.70)
	_sel_mat.transparency     = BaseMaterial3D.TRANSPARENCY_ALPHA
	_sel_mat.emission_enabled = true
	_sel_mat.emission         = Color(1.0, 0.85, 0.0) * 0.4
	_sel_mat.cull_mode        = BaseMaterial3D.CULL_DISABLED

	_highlight_node = MeshInstance3D.new()
	_highlight_node.name = "SelectHighlight"
	var m := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.97, 0.06, TILE_SIZE * 0.97)
	_highlight_node.mesh              = m
	_highlight_node.material_override = _sel_mat
	_highlight_node.visible           = false
	_highlight_node.cast_shadow       = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_highlight_node)

func _create_ghost() -> void:
	_ghost_mat = StandardMaterial3D.new()
	_ghost_mat.albedo_color = Color(0.45, 0.80, 1.0, 0.42)
	_ghost_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ghost_mat.cull_mode    = BaseMaterial3D.CULL_DISABLED

	_ghost_node = MeshInstance3D.new()
	_ghost_node.name = "Ghost"
	var m := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.82, 2.0, TILE_SIZE * 0.82)
	_ghost_node.mesh              = m
	_ghost_node.material_override = _ghost_mat
	_ghost_node.visible           = false
	_ghost_node.cast_shadow       = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_ghost_node)

func set_selection(tx: int, ty: int) -> void:
	selected_tile = Vector2i(tx, ty)
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h:
		_highlight_node.visible = false
		return
	var wp := tile_to_world3d(tx, ty)
	_highlight_node.position = Vector3(wp.x, wp.y + 0.07, wp.z)
	_highlight_node.visible  = true

func clear_selection() -> void:
	selected_tile     = Vector2i(-1, -1)
	selected_building = null
	_highlight_node.visible = false

func update_ghost(tx: int, ty: int, building_id: String) -> void:
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h or building_id.is_empty():
		_ghost_node.visible = false
		return
	var wp:  Vector3 = tile_to_world3d(tx, ty)
	var vis: Dictionary = BUILDING_VISUALS.get(
		building_id, {"color": Color(0.5, 0.8, 1.0), "h": 2.0}
	) as Dictionary
	var bh: float = float(vis.get("h", 2.0))
	var m  := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.82, bh, TILE_SIZE * 0.82)
	_ghost_node.mesh     = m
	_ghost_node.position = Vector3(wp.x, wp.y + bh * 0.5, wp.z)
	_ghost_node.visible  = true

func clear_ghost() -> void:
	_ghost_node.visible = false

# ══════════════════════════════════════════════════════════════════════════════
# FRETTCHEN
# ══════════════════════════════════════════════════════════════════════════════
func update_ferrets(ferrets: Array) -> void:
	# Prüfen ob genug Nodes vorhanden, sonst neu erstellen
	while _ferret_nodes.size() < ferrets.size():
		var sph_mi := MeshInstance3D.new()
		var sph    := SphereMesh.new()
		sph.radius = 0.28; sph.height = 0.56
		sph_mi.mesh = sph
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.90, 0.76, 0.55)
		mat.roughness    = 0.85
		sph_mi.material_override = mat
		sph_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_ferret_root.add_child(sph_mi)
		_ferret_nodes.append(sph_mi)

	# Überschüssige Nodes verstecken
	for i in _ferret_nodes.size():
		var fn: MeshInstance3D = _ferret_nodes[i] as MeshInstance3D
		if i >= ferrets.size():
			fn.visible = false
			continue
		fn.visible = true
		var fe: FerretEntity = ferrets[i] as FerretEntity
		# pos ist jetzt Tile-Koordinaten (Floats)
		var ftx: int = clampi(int(fe.pos.x), 0, world_w - 1)
		var fty: int = clampi(int(fe.pos.y), 0, world_h - 1)
		var wp3: Vector3 = tile_to_world3d(ftx, fty)
		# Sub-Tile-Offset
		var sub_x: float = (fe.pos.x - float(ftx)) * TILE_SIZE
		var sub_z: float = (fe.pos.y - float(fty)) * TILE_SIZE
		fn.position = Vector3(wp3.x + sub_x, wp3.y + FERRET_Y, wp3.z + sub_z)

func _clear_ferrets() -> void:
	for n in _ferret_nodes:
		if is_instance_valid(n): (n as Node).queue_free()
	_ferret_nodes.clear()

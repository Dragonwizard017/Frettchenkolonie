## BuildingEntity.gd
class_name BuildingEntity
extends RefCounted

var id: String = ""
var name: String = ""
var btype: String = ""
var epoch: int = 1
var icon: String = ""
var tile_x: int = 0
var tile_y: int = 0
var costs: Dictionary = {}
var is_under_construction: bool = true
var construction_progress: float = 0.0
var construction_work_needed: float = 30.0
var assigned_builder = null
var placed_day: int = 0
var max_workers: int = 0
var assigned_workers: Array = []
## Feature: manuelle Arbeiter-Begrenzung über die Gebäude-UI. -1 = kein
## manuelles Limit (= max_workers gilt). Wird über set_worker_cap() gesetzt.
var worker_cap: int = -1
var work_priority: int = 3
var storage_capacity: float = 0.0
var water_capacity: float = 0.0
var max_residents: int = 0
var residents: Array = []
var production_speed: float = 1.0
var production_progress: float = 0.0
var produces: String = ""
var needs_input: bool = false
var input_resources: Array = []
var recipes: Array = []
var collects_resource: String = ""
var collection_radius: int = 6
var planting_radius: int = 8
var happiness_bonus: float = 0.0
var happiness_radius: float = 8.0
var boost_radius: float = 10.0
var boost_factor: float = 0.5
var waterwheel_boost: float = 0.0
var level: int = 1
var is_active: bool = false
var dynamite_placed: bool = false

static func from_type(building_id: String, tx: int, ty: int) -> BuildingEntity:
	var all_buildings: Dictionary = BuildingData.BUILDINGS
	if not all_buildings.has(building_id):
		return null
	var data: Dictionary = all_buildings[building_id]
	var b := BuildingEntity.new()
	b.id = building_id
	b.name = str(data.get("name", building_id))
	b.btype = str(data.get("type", ""))
	b.epoch = int(data.get("epoch", 1))
	b.icon = str(data.get("icon", "?"))
	b.tile_x = tx
	b.tile_y = ty
	b.costs = (data.get("costs", {}) as Dictionary).duplicate()
	b.max_workers = int(data.get("max_workers", 0))
	b.production_speed = float(data.get("production_speed", 1.0))
	b.produces = str(data.get("produces", ""))
	b.needs_input = bool(data.get("needs_input", false))
	var ir = data.get("input_resources", [])
	b.input_resources = (ir as Array).duplicate()
	var rec = data.get("recipes", [])
	b.recipes = (rec as Array).duplicate()
	b.collects_resource = str(data.get("collects_resource", ""))
	b.collection_radius = int(data.get("collection_radius", 6))
	b.planting_radius = int(data.get("planting_radius", 8))
	b.storage_capacity = float(data.get("storage_capacity", 0.0))
	b.water_capacity = float(data.get("water_capacity", 0.0))
	b.max_residents = int(data.get("max_residents", 0))
	b.happiness_bonus = float(data.get("happiness_bonus", 0.0))
	b.happiness_radius = float(data.get("happiness_radius", 8.0))
	b.boost_radius = float(data.get("boost_radius", 10.0))
	b.boost_factor = float(data.get("boost_factor", 0.5))
	b.construction_work_needed = float(data.get("construction_work", 30.0))
	b.is_under_construction = true
	b.construction_progress = 0.0
	return b

func get_effective_worker_cap() -> int:
	return max_workers if worker_cap < 0 else mini(worker_cap, max_workers)

## Vom Spieler über die Gebäude-UI aufgerufen (+/- Buttons), um die Anzahl
## zugewiesener Frettchen direkt zu steuern. Werden mehr Arbeiter zugewiesen
## sein als das neue Limit erlaubt, werden überzählige sofort freigesetzt.
func set_worker_cap(n: int) -> void:
	worker_cap = clampi(n, 0, max_workers)
	while assigned_workers.size() > worker_cap:
		remove_worker(assigned_workers[assigned_workers.size() - 1])

func assign_worker(ferret) -> bool:
	if assigned_workers.size() < get_effective_worker_cap():
		assigned_workers.append(ferret)
		ferret.assigned_building = self
		return true
	return false

func remove_worker(ferret) -> void:
	assigned_workers.erase(ferret)
	if ferret.assigned_building == self:
		ferret.assigned_building = null

func remove_all_workers() -> void:
	for w in assigned_workers.duplicate():
		remove_worker(w)

func update(dt: float, is_day: bool, world: Array) -> void:
	if is_under_construction:
		return
	is_active = false
	if btype == "DECO" or btype == "GRAVEYARD" or btype == "STORAGE" or btype == "DAM":
		is_active = true
		return
	if not is_day and btype != "HAPPINESS" and btype != "BUILDER" and btype != "STORAGE" and btype != "DECO":
		return
	if assigned_workers.is_empty() and max_workers > 0:
		return
	is_active = true
	match btype:
		"COLLECTOR":      _collect(dt, world)
		"PROCESSOR":      _process(dt)
		"MULTIPROCESSOR": _multi_process(dt)
		"HUNTER":         _hunt(dt)
		"FARM":           _farm(dt)

@warning_ignore("unused_parameter")
func _collect(dt: float, world: Array) -> void:
	if collects_resource == "": return
	var workers: int = assigned_workers.size()
	if workers == 0: return
	var level_bonus: float = float(level - 1) * 0.35
	var base_rate: float = production_speed * dt * float(workers) * 0.35
	if collects_resource == "WATER":
		# Bug-Fix/Feature (Wasserphysik): Foerdermenge haengt jetzt vom
		# TATSAECHLICHEN, simulierten Wasserstand in der Umgebung ab
		# (WaterSystem.gd) statt nur von der statischen Biom-Zugehoerigkeit.
		# Trocknet der nahe Fluss/See waehrend einer Duerre aus, sinkt die
		# Foerderleistung entsprechend - genau das macht Daemme strategisch
		# wertvoll, da sie den lokalen Pegel laenger hochhalten.
		var avg_level: float = WaterSys.get_avg_level_near(tile_x, tile_y, collection_radius)
		var level_factor: float = clampf(avg_level / 1.0, 0.0, 1.5)
		ResourceSys.add_water(base_rate * level_factor * (1.0 + level_bonus + waterwheel_boost))
	else:
		var rate: float = base_rate * (1.0 + waterwheel_boost + level_bonus)
		# Feature (v10.10): die Foerdermenge haengt jetzt auch davon ab, ob
		# ueberhaupt eine erntbare Quelle (WOOD/STONE/BERRIES/IRON) in
		# Reichweite liegt - sind alle Quellen gerade erschoepft (siehe
		# FerretEntity-Ernte-Logik), faellt die Ausbeute deutlich ab statt
		# unbeeindruckt weiterzulaufen.
		if collects_resource in ["WOOD", "STONE", "BERRIES", "IRON"] and not _has_nearby_node(world):
			rate *= 0.35
		ResourceSys.add(collects_resource, rate)

## Prueft, ob im Sammelradius mindestens eine aktuell erntbare Resource-Node
## des passenden Typs liegt (siehe FerretEntity._find_harvestable_node, hier
## bewusst dieselbe Logik in kompakter Form, da BuildingEntity nicht von
## FerretEntity abhaengen soll).
func _has_nearby_node(world: Array) -> bool:
	if collects_resource == "": return false
	var r: int = collection_radius
	var ww: int = world.size()
	for dx in range(-r, r + 1):
		var tx: int = tile_x + dx
		if tx < 0 or tx >= ww: continue
		var col: Array = world[tx]
		var hh: int = col.size()
		for dy in range(-r, r + 1):
			var ty: int = tile_y + dy
			if ty < 0 or ty >= hh: continue
			var node_data = (col[ty] as Dictionary).get("resource_node")
			if node_data == null or not (node_data is Dictionary): continue
			var nd: Dictionary = node_data
			if str(nd.get("type", "")) != collects_resource: continue
			if bool(nd.get("depleted", false)): continue
			if float(nd.get("amount", 0.0)) > 1.0: return true
	return false

func _process(dt: float) -> void:
	if produces == "": return
	var chains: Dictionary = BuildingData.PRODUCTION_CHAINS
	if not chains.has(produces): return
	if needs_input and not ResourceSys.can_produce(produces): return
	var bonus: float = float(assigned_workers.size()) / maxf(1.0, float(max_workers))
	production_progress += dt * production_speed * bonus * (1.0 + waterwheel_boost)
	var chain: Dictionary = chains[produces]
	var chain_time: float = float(chain.get("time", 5.0))
	if production_progress >= chain_time:
		production_progress = 0.0
		ResourceSys.produce(produces)

func _multi_process(dt: float) -> void:
	if recipes.is_empty() or assigned_workers.is_empty(): return
	var bonus: float = float(assigned_workers.size()) / maxf(1.0, float(max_workers))
	production_progress += dt * production_speed * bonus
	var priority: Array = ["STEW", "COOKED_MEAT", "BREAD", "FOOD"]
	var chosen: String = ""
	for r in priority:
		if r in recipes and ResourceSys.can_produce(r):
			chosen = r; break
	if chosen == "":
		production_progress = 0.0; return
	var chains: Dictionary = BuildingData.PRODUCTION_CHAINS
	var chain: Dictionary = chains[chosen]
	if production_progress >= float(chain.get("time", 5.0)):
		production_progress = 0.0
		ResourceSys.produce(chosen)

func _hunt(dt: float) -> void:
	var rate: float = production_speed * dt * maxf(1.0, float(assigned_workers.size())) * 0.04
	ResourceSys.add("MEAT", rate)

func _farm(dt: float) -> void:
	# Bug-Fix (v10.13): _farm() hat bisher IMMER "BERRIES" produziert, egal
	# was das jeweilige FARM-Gebaeude laut BuildingData eigentlich erzeugen
	# sollte. Beim Getreidefeld (CROP_FIELD) war das klar falsch - es heisst
	# "Getreidefeld", hat das Weizen-Icon 🌾 und sollte WHEAT produzieren,
	# erzeugte aber heimlich Beeren. Jetzt wird collects_resource genutzt
	# (mit WHEAT als sinnvollem Fallback, falls ein FARM-Gebaeude das Feld
	# nicht setzt).
	var res: String = collects_resource if collects_resource != "" else "WHEAT"
	var prod: float = 0.04 * dt * float(assigned_workers.size())
	var drought: bool = DroughtSys.is_drought
	if not drought or ResourceSys.has_water(0.1):
		ResourceSys.add(res, prod)
		if drought: ResourceSys.remove_water(prod * 0.5)

func get_upgrade_costs() -> Dictionary:
	if level >= 3: return {}
	var result: Dictionary = {}
	for res in costs:
		result[res] = int(float(costs[res]) * (1.0 + float(level) * 0.5))
	return result

func upgrade() -> bool:
	if level >= 3: return false
	var up_costs: Dictionary = get_upgrade_costs()
	if not ResourceSys.can_afford(up_costs): return false
	ResourceSys.spend(up_costs)
	level += 1
	production_speed *= 1.35
	if max_workers > 0: max_workers += 1
	return true

func serialize() -> Dictionary:
	return {
		"id": id, "tile_x": tile_x, "tile_y": tile_y,
		"is_under_construction": is_under_construction,
		"construction_progress": construction_progress,
		"level": level, "production_progress": production_progress,
		"work_priority": work_priority, "placed_day": placed_day,
		"worker_cap": worker_cap
	}

static func deserialize(data: Dictionary) -> BuildingEntity:
	var b: BuildingEntity = BuildingEntity.from_type(
		str(data.get("id", "")), int(data.get("tile_x", 0)), int(data.get("tile_y", 0)))
	if b == null: return null
	b.is_under_construction = bool(data.get("is_under_construction", false))
	b.construction_progress = float(data.get("construction_progress", b.construction_work_needed))
	b.level = int(data.get("level", 1))
	b.production_progress = float(data.get("production_progress", 0.0))
	b.work_priority = int(data.get("work_priority", 3))
	b.placed_day = int(data.get("placed_day", 0))
	b.worker_cap = int(data.get("worker_cap", -1))
	return b

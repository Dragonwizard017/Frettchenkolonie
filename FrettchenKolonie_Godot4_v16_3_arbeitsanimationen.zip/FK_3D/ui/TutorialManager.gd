## TutorialManager.gd (v13.1+ - Bugfix für Tutorial-UI-Blockade)
## - Umlaute statt ä/ö/ü
## - Zeit pausiert während Tutorial
## - UI ist nicht blockierbar wenn hidden
extends Control

const STEPS: Array = [
	{"title": "Willkommen!",
	 "text": "Hallo, ich bin Freddy Frettchen! Ich zeige dir Schritt für Schritt, wie deine Kolonie funktioniert. Das dauert nur ein paar Minuten."},
	{"title": "Kamera bewegen",
	 "text": "Bewege die Kamera mit WASD oder den Pfeiltasten. Mit dem Mausrad zoomst du, mit gedrückter rechter Maustaste ziehst du die Ansicht."},
	{"title": "Dein Bauhof",
	 "text": "Das ist dein Bauhof - hier arbeiten Frettchen-Baumeister an deinen Baustellen. Ohne freie Bauhof-Arbeiter geht keine Baustelle voran."},
	{"title": "Bau-Menü",
	 "text": "Links siehst du das Bau-Menü mit allen verfügbaren Gebäuden, sortiert nach Kategorie.",
	 "highlight_path": "../BuildMenu"},
	{"title": "Dein erstes Gebäude",
	 "text": "Am Boden siehst du eine grün markierte Kachel. Öffne das Bau-Menü, wähle den Holzfäller (🪓) und platziere ihn auf der markierten Kachel.",
	 "wait_for": "building_placed_at_marker", "marker": true},
	{"title": "Gut gemacht!",
	 "text": "Super! Der Holzfäller sammelt jetzt automatisch Holz von nahen Bäumen. So arbeiten fast alle Sammel-Gebäude: Sie brauchen die passende Ressource in ihrem Radius."},
	{"title": "Ressourcen im Blick",
	 "text": "Oben siehst du deine Rohstoffe (Holz, Stein, Beeren, Wasser) und wie viele Frettchen deine Kolonie hat."},
	{"title": "Das Wichtigste: Essen & Trinken",
	 "text": "Deine Frettchen brauchen Essen und Wasser - das ist die oberste Priorität! Baue schnell einen Brunnen und eine Nahrungsülle wie einen Beerensammler."},
	{"title": "Ein Zuhause bauen",
	 "text": "Ein Wohnhaus gibt deinen Frettchen Schlafplätze. Ohne freie Betten gibt es keinen Nachwuchs - die Kolonie wächst nur bei guter Versorgung und Stimmung."},
	{"title": "Stimmung heben",
	 "text": "Gebäude wie der Versammlungsplatz heben die Laune aller Frettchen in der Nähe. Glückliche Frettchen arbeiten schneller und bekommen mehr Nachwuchs."},
	{"title": "Gelände formen",
	 "text": "Im Bau-Menü unter 'Gelände' kannst du Erde aufschütten oder mit Sprengstoff Hügel abtragen."},
	{"title": "Forschung & Tech-Baum",
	 "text": "Die Forschungsstube produziert Wissenspunkte. Damit schaltest du im Tech-Baum (hier markiert) Verbesserungen für deine Gebäude frei.",
	 "highlight_path": "../HUD/RightColumn/ExtraPanel/ExtraButtons/TechTreeBtn"},
	{"title": "Epochen-Fortschritt",
	 "text": "Oben im Bau-Menü zeigt der Epochen-Button, was du brauchst um in die nächste Epoche zu gehen. Jede neue Epoche schaltet viele neue Gebäude frei."},
	{"title": "Der Frettchenmodus",
	 "text": "Drücke [F], um die Perspektive eines einzelnen Frettchens zu sehen! Du kannst dort herumlaufen und mit [E] Ressourcen in Minispielen sammeln. Probier's jetzt!",
	 "wait_for": "fp_mode_entered"},
	{"title": "Willkommen zurück!",
	 "text": "Mit [ESC] oder erneut [F] kommst du zurück zur Kolonie-Ansicht. Dein Frettchen merkt sich seine Position."},
	{"title": "Dein Frettchen personalisieren",
	 "text": "Im Pause-Menü siehst du dein Frettchen-Ich. Accessoires, die du durch Erfolge freischaltest, geben eigene kleine Boni."},
	{"title": "Erfolge sammeln",
	 "text": "Für Meilensteine (viele Frettchen, große Lager, überstandene Dürren) schaltest du Erfolge frei - hier markiert.",
	 "highlight_path": "../HUD/RightColumn/ExtraPanel/ExtraButtons/AchievementBtn"},
	{"title": "Spielgeschwindigkeit",
	 "text": "Die Zeit läuft automatisch. Mit diesen Buttons (hier markiert) oder [Leertaste] kannst du beschleunigen oder pausieren.",
	 "highlight_path": "../HUD/RightColumn/SpeedPanel"},
	{"title": "Speichern",
	 "text": "Über das Pause-Menü ([Leertaste]) kannst du jederzeit speichern - dein Fortschritt, dein Frettchen-Ich und deine Ausrüstung bleiben erhalten."},
	{"title": "Viel Erfolg!",
	 "text": "Das war's! Neue Systeme wie Distrikte, Expeditionen und Wasser-Management erkläre ich dir automatisch, wenn du sie erreichst. Viel Erfolg beim Aufbau!"},
]

var _step: int = 0
var _waiting_for: String = ""
var _marker_tile: Vector2i = Vector2i(-1, -1)
var _highlight_target: Control = null
var _box: PanelContainer
var _title_lbl: Label
var _text_lbl: Label
var _next_btn: Button
var _skip_btn: Button
var _step_lbl: Label
var _game_ctrl: Node = null

func _ready() -> void:
	# Feature (v13.1, Bugfix): MOUSE_FILTER_STOP statt IGNORE, damit das Tutorial
	# nicht die ganze UI dahinter blockt wenn es versteckt ist
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hide()
	_build_ui()
	GameState.building_placed.connect(_on_building_placed)
	GameState.fp_mode_changed.connect(_on_fp_mode_changed)
	_game_ctrl = get_node_or_null("../../..")

func _build_ui() -> void:
	_box = PanelContainer.new(); _box.name = "TutorialBox"
	_box.mouse_filter = Control.MOUSE_FILTER_STOP
	_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_box.anchor_left = 0.16; _box.anchor_right = 0.84
	_box.offset_top = -192; _box.offset_bottom = -24
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.09, 0.13, 0.95)
	sb.set_corner_radius_all(10)
	sb.content_margin_left = 18; sb.content_margin_right = 18
	sb.content_margin_top = 14;  sb.content_margin_bottom = 14
	sb.border_width_top = 2; sb.border_color = Color(0.96, 0.69, 0.1)
	_box.add_theme_stylebox_override("panel", sb)
	add_child(_box)

	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8)
	_box.add_child(vb)

	var hdr := HBoxContainer.new(); hdr.add_theme_constant_override("separation", 10)
	vb.add_child(hdr)

	var icon := Label.new(); icon.text = "🦡"
	icon.add_theme_font_size_override("font_size", 30)
	hdr.add_child(icon)

	var hdr_vb := VBoxContainer.new(); hdr_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(hdr_vb)
	_title_lbl = Label.new()
	_title_lbl.add_theme_font_size_override("font_size", 16)
	_title_lbl.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
	hdr_vb.add_child(_title_lbl)
	_step_lbl = Label.new()
	_step_lbl.add_theme_font_size_override("font_size", 11)
	_step_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	hdr_vb.add_child(_step_lbl)

	_text_lbl = Label.new()
	_text_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	_text_lbl.add_theme_font_size_override("font_size", 14)
	_text_lbl.custom_minimum_size = Vector2(0, 64)
	vb.add_child(_text_lbl)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	_skip_btn = Button.new(); _skip_btn.text = "Tutorial überspringen"
	_skip_btn.pressed.connect(_on_skip)
	row.add_child(_skip_btn)
	_next_btn = Button.new(); _next_btn.text = "Weiter"
	_next_btn.pressed.connect(_on_next)
	row.add_child(_next_btn)

func start() -> void:
	_step = 0
	show()
	_pause_game()
	_show_step()

func _pause_game() -> void:
	GameState.tutorial_active = true
	if _game_ctrl != null:
		_game_ctrl.call_deferred("set_simulation_paused", true)

func _unpause_game() -> void:
	GameState.tutorial_active = false
	if _game_ctrl != null:
		_game_ctrl.call_deferred("set_simulation_paused", false)

func _show_step() -> void:
	_clear_marker()
	if _step >= STEPS.size():
		_finish()
		return
	var s: Dictionary = STEPS[_step]
	_title_lbl.text = str(s.get("title",""))
	_text_lbl.text = str(s.get("text",""))
	_step_lbl.text = "Schritt %d/%d" % [_step + 1, STEPS.size()]
	_waiting_for = str(s.get("wait_for",""))
	_next_btn.visible = _waiting_for.is_empty()
	if bool(s.get("marker", false)):
		_place_marker()
	var hp: String = str(s.get("highlight_path", ""))
	_highlight_target = (get_node_or_null(hp) as Control) if hp != "" else null

func _place_marker() -> void:
	if _game_ctrl == null: return
	var renderer = _game_ctrl.get("renderer")
	if renderer == null: return
	var start_tile: Vector2i = renderer.call("world3d_to_tile", _game_ctrl.get("_cam_target"))
	_marker_tile = _game_ctrl.call("find_nearby_buildable_tile", start_tile.x, start_tile.y)
	if _marker_tile.x >= 0:
		renderer.call("show_tutorial_marker", _marker_tile.x, _marker_tile.y)

func _clear_marker() -> void:
	if _marker_tile.x < 0: return
	_marker_tile = Vector2i(-1, -1)
	if _game_ctrl == null: return
	var renderer = _game_ctrl.get("renderer")
	if renderer: renderer.call("hide_tutorial_marker")

func _process(_delta: float) -> void:
	if _highlight_target != null:
		queue_redraw()

func _draw() -> void:
	if _highlight_target == null or not is_instance_valid(_highlight_target): return
	if not _highlight_target.is_visible_in_tree(): return
	var r: Rect2 = _highlight_target.get_global_rect()
	r.position -= global_position
	var pulse: float = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 1000.0 * 4.0)
	var col := Color(1.0, 0.85, 0.15, 0.55 + 0.35 * pulse)
	draw_rect(r.grow(5.0 + pulse * 2.0), col, false, 3.5)

func _on_next() -> void:
	_step += 1
	_show_step()

func _on_skip() -> void:
	_finish()

func _on_building_placed(b) -> void:
	if not visible or _waiting_for != "building_placed_at_marker": return
	if _marker_tile.x >= 0 and b != null:
		var btx: int = int(b.tile_x)
		var bty: int = int(b.tile_y)
		if absi(btx - _marker_tile.x) > 1 or absi(bty - _marker_tile.y) > 1:
			return
	_waiting_for = ""
	_step += 1
	_show_step()

func _on_fp_mode_changed(active: bool) -> void:
	if not visible or _waiting_for != "fp_mode_entered": return
	if not active: return
	_waiting_for = ""
	_step += 1
	_show_step()

func _finish() -> void:
	_clear_marker()
	_highlight_target = null
	_unpause_game()
	# Feature (v13.1, Bugfix): Zuerst komplett verbergen und UI-Events
	# freigeben, DANN unpause
	hide()
	mouse_filter = Control.MOUSE_FILTER_IGNORE

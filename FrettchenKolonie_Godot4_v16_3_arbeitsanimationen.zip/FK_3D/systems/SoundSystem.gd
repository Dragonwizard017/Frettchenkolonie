## SoundSystem.gd
## Soundeffekte: prozedurales Audio via AudioStreamGeneratorPlayback
## (verhindert den FMallocBinned2 Crash, siehe Changes-Historie).
## Musik (v12.6): echte Audiodateien statt prozeduraler Töne. Die
## Musikzone (Hauptmenü / Spiel) wird automatisch aus GameState.state_changed
## abgeleitet - kein manuelles Steuern an den einzelnen Aufrufstellen nötig.
extends Node

var master_vol: float = 0.8
var sfx_vol: float    = 0.7
var music_vol: float  = 0.6

const POOL_SIZE := 8
const MIX_RATE  := 22050
const BUF_SIZE  := 1024  # Samples per generator buffer chunk

var _sfx_pool:   Array = []  # Array[AudioStreamPlayer]  – Generator-basiert
var _sfx_idx:    int   = 0

# Wir speichern pro Player eine laufende Sinus-Phase und den Rest-Samplelcount
var _sfx_state:   Array = []  # [{freq, phase, vol, remaining}]

# ── Musik (echte Audiodateien, v12.6) ────────────────────────────────────────
# Hauptmenü: die beiden "New Dawn Frontier"-Titel.
const MENU_TRACKS: Array[AudioStream] = [
	preload("res://assets/music/menu_new_dawn_frontier_1.mp3"),
	preload("res://assets/music/menu_new_dawn_frontier_2.mp3"),
]
# Im Spiel: die beiden "Cozy Block Building"-Titel, zufällig variierend.
const GAME_TRACKS: Array[AudioStream] = [
	preload("res://assets/music/game_cozy_block_building_1.mp3"),
	preload("res://assets/music/game_cozy_block_building_2.mp3"),
]
# Zufällige Pause zwischen zwei Musikstücken IM SPIEL (Nutzerwunsch: 10-60s).
const GAME_TRACK_GAP_MIN := 10.0
const GAME_TRACK_GAP_MAX := 60.0
# Feature (v14.4, Nutzerwunsch "Fretchenmodus mehr zu einem Cosy-Game
# machen"): eigene, ruhigere Musik-Variante fürs Frettchen-Ich - es gibt
# keine eigenen Tracks dafür, darum werden dieselben "Cozy Block Building"-
# Stücke wiederverwendet, aber spürbar gedrosselt (leiser, minimal tiefere
# Tonhöhe = gemächlicher) und mit längeren Pausen dazwischen - fühlt sich
# dadurch bewusst ruhiger/entspannter an als die normale Kolonie-Ansicht.
const FP_TRACK_GAP_MIN := 25.0
const FP_TRACK_GAP_MAX := 75.0
const FP_MUSIC_PITCH   := 0.94
const FP_MUSIC_VOL_MULT := 0.75

enum MusicZone { NONE, MENU, GAME }

var _music_player: AudioStreamPlayer = null
var _music_gap_timer: Timer = null
var _music_zone: MusicZone = MusicZone.NONE
var _last_track: AudioStream = null
var _fp_mode_active: bool = false

func _ready() -> void:
	for i in POOL_SIZE:
		var p := _make_gen_player()
		_sfx_pool.append(p)
		_sfx_state.append({"freq": 0.0, "phase": 0.0, "vol": 0.0, "rem": 0})

	# Musik-Player: spielt die echten mp3-Dateien (kein Generator nötig).
	_music_player = AudioStreamPlayer.new()
	_music_player.name = "MusicPlayer"
	add_child(_music_player)
	_music_player.finished.connect(_on_music_track_finished)

	# Pause-Timer zwischen zwei Spiel-Musikstücken. Bewusst als Kind-Node
	# statt get_tree().create_timer() - siehe Changes-Historie (Lambda-Capture-
	# Crash in NotificationLayer, gleiche Fehlerklasse wird hier vermieden).
	_music_gap_timer = Timer.new()
	_music_gap_timer.name = "MusicGapTimer"
	_music_gap_timer.one_shot = true
	add_child(_music_gap_timer)
	_music_gap_timer.timeout.connect(_play_next_track)

	_apply_music_player_volume()
	GameState.state_changed.connect(_on_game_state_changed)
	_on_game_state_changed(GameState.current_state)

func _make_gen_player() -> AudioStreamPlayer:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = float(MIX_RATE)
	gen.buffer_length = 0.10
	var p := AudioStreamPlayer.new()
	p.stream = gen
	p.volume_db = -6.0
	add_child(p)
	p.play()
	return p

func _process(dt: float) -> void:
	# SFX-Pool befüllen
	for i in POOL_SIZE:
		var st: Dictionary = _sfx_state[i]
		if int(st["rem"]) <= 0: continue
		var p: AudioStreamPlayer = _sfx_pool[i]
		var pb = p.get_stream_playback()
		if pb == null: continue
		var to_fill: int = mini(pb.get_frames_available(), mini(int(st["rem"]), BUF_SIZE))
		var frame := Vector2.ZERO
		for _s in to_fill:
			var t: float = float(st["phase"]) / float(MIX_RATE)
			var env: float = clampf(float(st["rem"]) / float(MIX_RATE) * 6.0, 0.0, 1.0)
			var s: float = sin(TAU * float(st["freq"]) * t) * float(st["vol"]) * env
			frame = Vector2(s, s)
			pb.push_frame(frame)
			st["phase"] = int(st["phase"]) + 1
			st["rem"] = int(st["rem"]) - 1

func _tone(freq: float, duration: float, vol: float) -> void:
	var actual: float = vol * master_vol * sfx_vol
	if actual < 0.001: return
	var idx: int = _sfx_idx % POOL_SIZE
	_sfx_idx += 1
	_sfx_state[idx]["freq"] = freq
	_sfx_state[idx]["phase"] = 0
	_sfx_state[idx]["vol"] = actual
	_sfx_state[idx]["rem"] = int(duration * MIX_RATE)

# ── Musik-Steuerung ───────────────────────────────────────────────────────────
## Legacy-Einstiegspunkte: werden weiterhin von GameController.gd (Spielstart)
## und PauseMenu.gd (zurück ins Hauptmenü) aufgerufen, sind aber seit v12.6
## No-Ops - die Musikzone wird automatisch aus GameState.state_changed
## abgeleitet (siehe _on_game_state_changed). So bleiben bestehende Aufrufe
## gefahrlos bestehen, ohne die Musik doppelt zu steuern.
func start_music() -> void: pass
func stop_music()  -> void: pass

## v15.9: Intro-Steuerung - pausiert die Menü-Musik, solange ein Video-Intro
## mit eingebackener Musik läuft (sonst Doppel-Audio, betrifft nur noch das
## Story-Intro - das Menü-Intro v13 hat keine Audiospur). Spielt nichts um,
## nur stream_paused an/aus - danach läuft der aktuelle Titel nahtlos weiter.
func pause_music() -> void:
	if _music_player != null and _music_player.playing:
		_music_player.stream_paused = true

func resume_music() -> void:
	if _music_player != null:
		_music_player.stream_paused = false

func _zone_for_state(s: GameState.State) -> MusicZone:
	match s:
		GameState.State.PLAYING, GameState.State.PAUSED:
			return MusicZone.GAME
		GameState.State.INTRO:
			# v15.13: INTRO ist transparent - die aktuelle Musik läuft durch
			# (Nutzerwunsch: epische Menü-Musik startet mit dem Spiel und geht
			# nahtlos durchs Menü-Intro bis ins Hauptmenü, ohne Cut/Neustart).
			# Das Menü-Intro v13 hat keine eigene Audiospur; das Story-Intro
			# schon, wird aber separat per pause_music()/resume_music()
			# stummgeschaltet (siehe Main._on_start_game).
			return MusicZone.NONE
		_:
			# MAIN_MENU, WORLD_CREATION, LOAD_SCREEN, GAME_OVER -> Menü-Musik
			return MusicZone.MENU

func _on_game_state_changed(s: GameState.State) -> void:
	var new_zone: MusicZone = _zone_for_state(s)
	if new_zone == MusicZone.NONE:
		# v15.13: INTRO ändert nichts - laufender Titel spielt weiter.
		return
	if new_zone == _music_zone:
		return
	_music_zone = new_zone
	_music_gap_timer.stop()
	_last_track = null
	_play_next_track()

func _current_pool() -> Array:
	return MENU_TRACKS if _music_zone == MusicZone.MENU else GAME_TRACKS

func _pick_random_track(pool: Array) -> AudioStream:
	if pool.is_empty():
		return null
	if pool.size() == 1:
		return pool[0]
	var choice: AudioStream = pool[randi() % pool.size()]
	var guard: int = 0
	# Nicht zweimal hintereinander denselben Titel spielen, solange Alternativen da sind.
	while choice == _last_track and guard < 8:
		choice = pool[randi() % pool.size()]
		guard += 1
	return choice

func _play_next_track() -> void:
	var pool: Array = _current_pool()
	var track: AudioStream = _pick_random_track(pool)
	if track == null:
		return
	_last_track = track
	_music_player.stream = track
	_music_player.pitch_scale = FP_MUSIC_PITCH if (_music_zone == MusicZone.GAME and _fp_mode_active) else 1.0
	_music_player.play()

func _on_music_track_finished() -> void:
	if _music_zone == MusicZone.GAME:
		# Nutzerwunsch: kleine Pause zwischen den Musikstücken im Spiel - im
		# Frettchenmodus länger, damit es ruhiger/weniger "vollgepackt" wirkt.
		if _fp_mode_active:
			_music_gap_timer.wait_time = randf_range(FP_TRACK_GAP_MIN, FP_TRACK_GAP_MAX)
		else:
			_music_gap_timer.wait_time = randf_range(GAME_TRACK_GAP_MIN, GAME_TRACK_GAP_MAX)
		_music_gap_timer.start()
	else:
		# Hauptmenü: die beiden Titel wechseln nahtlos, ohne Pause.
		_play_next_track()

## Feature (v14.4): wird von GameController._toggle_fp_mode() aufgerufen.
## Ändert NICHT die Musik-Zone selbst (das Frettchen-Ich läuft ja immer noch
## während GameState.State.PLAYING) - senkt nur Lautstärke/Tonhöhe des
## aktuell laufenden Stücks und sorgt dafür, dass das NÄCHSTE Stück ebenfalls
## gedrosselt startet.
func set_fp_mode(active: bool) -> void:
	if _fp_mode_active == active: return
	_fp_mode_active = active
	_apply_music_player_volume()
	if _music_player.playing:
		_music_player.pitch_scale = FP_MUSIC_PITCH if (active and _music_zone == MusicZone.GAME) else 1.0

func _apply_music_player_volume() -> void:
	if _music_player == null:
		return
	var lin: float = clampf(master_vol * music_vol, 0.0, 1.0)
	if _fp_mode_active and _music_zone == MusicZone.GAME:
		lin *= FP_MUSIC_VOL_MULT
	_music_player.volume_db = linear_to_db(lin) if lin > 0.0001 else -80.0

# ── Soundeffekte ──────────────────────────────────────────────────────────────
func play_build() -> void:
	_tone(440.0, 0.14, sfx_vol * 0.15)
	_tone(554.0, 0.18, sfx_vol * 0.12)
	_tone(659.0, 0.24, sfx_vol * 0.10)

func play_explosion() -> void:
	# Weißes Rauschen via mehrere verstimmte Sinusse
	for i in 6:
		_tone(randf_range(80.0, 320.0), 0.55, sfx_vol * 0.18)

func play_notify() -> void:
	_tone(880.0,  0.10, sfx_vol * 0.18)
	_tone(1108.0, 0.14, sfx_vol * 0.14)

func play_born() -> void:
	for pair in [[523.0,0.14],[659.0,0.14],[784.0,0.14],[1046.0,0.18]]:
		_tone(float((pair as Array)[0]), float((pair as Array)[1]), sfx_vol * 0.18)

func play_death() -> void:
	for pair in [[440.0,0.20],[370.0,0.22],[311.0,0.24],[262.0,0.28]]:
		_tone(float((pair as Array)[0]), float((pair as Array)[1]), sfx_vol * 0.14)

func play_day()   -> void:
	for freq in [523.0, 659.0, 784.0]: _tone(float(freq), 0.30, sfx_vol * 0.11)

func play_night() -> void:
	for freq in [392.0, 330.0, 262.0]: _tone(float(freq), 0.38, sfx_vol * 0.09)

func set_volumes(master: float, music: float, sfx: float) -> void:
	master_vol = clampf(master / 100.0, 0.0, 1.0)
	music_vol  = clampf(music  / 100.0, 0.0, 1.0)
	sfx_vol    = clampf(sfx   / 100.0, 0.0, 1.0)
	_apply_music_player_volume()

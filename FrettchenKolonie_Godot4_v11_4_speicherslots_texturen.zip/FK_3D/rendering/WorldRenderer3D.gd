## WorldRenderer3D.gd
## Rendert die Spielwelt vollständig in 3D.
## Terrain = ein zusammengesetztes ArrayMesh, pro Biom eine Oberseiten-
## Textur (copyright-freies isometrisches Tileset) + Vertex-Farbe als
## multiplikativer Tönungs-Layer (Dürre/Weg/austrocknendes Flussbett).
## Gebäude = individuelle StaticBody3D + BoxMesh + Label3D.
## Frettchen = SphereMesh die sich auf ihren Tile-Koordinaten bewegen.
class_name WorldRenderer3D
extends Node3D

# ── Konstanten ────────────────────────────────────────────────────────────────
const TILE_SIZE:    float = 2.0   # Welteinheiten pro Tile
const HEIGHT_SCALE: float = 1.2   # Tile-Höhe in Welteinheiten
const FERRET_Y:     float = 0.35  # Frettchen-Offset über Boden

# Baum-Modell: ersetzt die reine Forest-Einfärbung des Terrains durch echte
# 3D-Bäume auf jedem Tile mit einem Holz-Resource-Node.
const PINE_TREE_SCENE: PackedScene = preload("res://assets/pine_tree.glb")
const TREE_BASE_SCALE: float = 0.6  # Modell ist ~4.7 Welteinheiten hoch (roh)
# Beerenbusch-Modell: auf jedem Tile mit einem Beeren-Resource-Node.
const BUSH_SCENE: PackedScene = preload("res://assets/bush.glb")
const BUSH_BASE_SCALE: float = 0.46  # Modell ist ~1.27 Welteinheiten hoch (roh)
var _bushes_node: Node3D = null
# Gebaeude-Modell (v10.19): nutzt das "Building"-Asset (assets/building.glb)
# fuer ALLE fertig gebauten Gebaeudetypen statt des in v10.16-v10.18
# verwendeten house.glb. Grund (Nutzer-Feedback): house.glb sollte nicht mehr
# als Gebaeude-Darstellung dienen.
# v10.20: das Modell wurde durch eine Version mit 7 getrennten Material-
# Flaechen ersetzt ("Dach", "Pfeiler_Holzbalken", "Wand", "Gras_Busch",
# "Fenster_Dunkel", "Schornstein", "Sockel_Stein" - gleiche Geometrie/
# Bounding-Box wie zuvor, nur die Zuordnung der Dreiecke zu Materialien ist
# neu). Dadurch faerbt _tint_building_wall() jetzt gezielt NUR die
# "Wand"-Flaeche in der jeweiligen BUILDING_VISUALS-Gebaeudefarbe ein - Dach,
# Fensterrahmen, Schornstein, Sockel etc. behalten ihr Original-Material/
# -Aussehen bei, statt wie bisher (material_override auf der ganzen
# MeshInstance3D) komplett uebermalt zu werden.
# Skalierung weiterhin pro Gebaeude aus der individuellen Ziel-Hoehe "bh"
# berechnet statt eines festen Werts (siehe BUILDING_MODEL_RAW_HEIGHT unten).
const BUILDING_SCENE: PackedScene = preload("res://assets/building.glb")
## Rohmodell-Bounding-Box (per Skript aus den Vertex-Positionen ermittelt):
## Y reicht von ca. -1.00 bis +0.995, d.h. roh ca. 1.995 hoch, mit dem
## Mesh-Ursprung in der MITTE des Modells (nicht am Boden!). Wird benutzt, um
## die Modell-Skalierung passend zur jeweiligen Gebaeude-Zielhoehe "bh" zu
## berechnen (scale = bh / RAW_HEIGHT).
const BUILDING_MODEL_RAW_HEIGHT: float = 1.995
## Bug-Fix (v10.19, "Haeuser stehen im Boden"): der Modell-Ursprung liegt in
## der Mitte statt am Boden des Mesh - ohne Korrektur ragt die untere Haelfte
## des Modells unter die Tile-Oberflaeche. Dieser Wert ist der Abstand
## (in rohen, unskalierten Modell-Einheiten) vom Ursprung zur Unterkante des
## Mesh und wird nach dem Skalieren als Y-Offset auf das Modell angewendet,
## damit sein Boden exakt auf der Tile-Oberflaeche (y=0 relativ zum
## Gebaeude-Root) aufsteht statt zur Haelfte im Boden zu versinken.
const BUILDING_MODEL_BOTTOM_OFFSET: float = 1.0
## Globaler Korrekturfaktor zusaetzlich zur Hoehen-Skalierung, falls das
## Modell auf allen Gebaeuden insgesamt zu klein/gross wirkt: hier anpassen.
const BUILDING_MODEL_SCALE_FACTOR: float = 1.15
## Falls das Modell nach dem Import seitlich verdreht steht: hier in
## 90°-Schritten (PI/2) anpassen (gleiches Muster wie FERRET_ROT_OFFSET).
const BUILDING_ROT_OFFSET: float = 0.0
# Frettchen-Modell: ersetzt die bisherige reine Platzhalter-Kugel.
const FERRET_SCENE: PackedScene = preload("res://assets/ferret.glb")
const FERRET_MODEL_SCALE: float = 2.2
## Falls das Modell nach dem Import in die falsche Richtung schaut: hier in
## 90°-Schritten (PI/2) anpassen, z.B. PI für "schaut nach hinten".
const FERRET_ROT_OFFSET: float = 0.0
var _trees_node: Node3D = null
# Feature (v10.10): merkt sich Baum-/Busch-Node + urspruengliche Skalierung
# pro Tile, damit refresh_vegetation() sie je nach Rest-Ressourcenmenge
# (resource_node.amount / max_amount) dynamisch verkleinern/vergroessern kann
# - sichtbares Abholzen/Abpfluecken + Nachwachsen, ohne das Mesh neu bauen
# zu muessen.
var _tree_nodes: Dictionary = {}   # "tx,ty" -> {"node": Node3D, "base_scale": float}
var _bush_nodes: Dictionary = {}   # "tx,ty" -> {"node": Node3D, "base_scale": float}

# ── Terrain-Texturen (Tileset-Grafiktausch) ──────────────────────────────────
# Copyright-freies isometrisches Tileset (32x32 Pixelart, ein Tile pro Biom).
# Jede Biom-Oberseite bekommt ihre eigene Textur + eigenes Material/Surface;
# die Vertex-Farbe ist standardmaessig WEISS (Textur unveraendert sichtbar)
# und wird nur in Sonderfaellen (Dürre/Weg/austrocknendes Flussbett) als
# multiplikativer Tönungs-Layer Richtung einer Zielfarbe gelerpt
# (siehe _build_terrain_mesh).
const TILE_TEXTURES: Dictionary = {
	"PLAINS":   preload("res://assets/tiles/plains.png"),
	"FOREST":   preload("res://assets/tiles/forest.png"),
	"BEACH":    preload("res://assets/tiles/beach.png"),
	"HILLS":    preload("res://assets/tiles/hills.png"),
	"MOUNTAIN": preload("res://assets/tiles/mountain.png"),
	"WATER":    preload("res://assets/tiles/water.png"),
}
# Feature (v11.2-Hotfix, Seiten-Texturen): eigene prozedurale Seiten-Texturen
# pro Biom (erzeugt via Python/Pillow in assets/tiles/*_side.png). Timberborn-
# Style: PLAINS/FOREST zeigen Grasboden-Erde-Schichten, BEACH hellen Sand,
# HILLS trockenen Lehm, MOUNTAIN Steinmauerwerk, WATER nasse dunkle Erde.
const TILE_SIDE_TEXTURES: Dictionary = {
	"PLAINS":   preload("res://assets/tiles/plains_side.png"),
	"FOREST":   preload("res://assets/tiles/forest_side.png"),
	"BEACH":    preload("res://assets/tiles/beach_side.png"),
	"HILLS":    preload("res://assets/tiles/hills_side.png"),
	"MOUNTAIN": preload("res://assets/tiles/mountain_side.png"),
	"WATER":    preload("res://assets/tiles/water_side.png"),
}
var _top_materials:  Dictionary = {} # Biom-Name -> StandardMaterial3D (Cache)
var _side_materials: Dictionary = {} # Biom-Name -> StandardMaterial3D (Cache)

# ── Biom-Farben ───────────────────────────────────────────────────────────────
# Seit dem Tileset-Grafiktausch liefert die Textur die Grundfarbe der
# Oberseite; BIOME_TOP wird daher nicht mehr aktiv genutzt (nur als
# Referenz/Fallback erhalten). BIOME_SIDE faerbt weiterhin die meist
# verdeckten Seitenflaechen der Klippen (keine Textur dort).
const BIOME_TOP: Dictionary = {
	"WATER":    Color(0.20, 0.48, 0.82),
	"BEACH":    Color(0.91, 0.86, 0.64),
	"PLAINS":   Color(0.42, 0.72, 0.32),
	"FOREST":   Color(0.24, 0.54, 0.22),
	"HILLS":    Color(0.58, 0.54, 0.40),
	"MOUNTAIN": Color(0.68, 0.65, 0.62),
}
const BIOME_SIDE: Dictionary = {
	"WATER":    Color(0.14, 0.35, 0.65),
	"BEACH":    Color(0.76, 0.72, 0.50),
	"PLAINS":   Color(0.30, 0.56, 0.22),
	"FOREST":   Color(0.16, 0.40, 0.14),
	"HILLS":    Color(0.44, 0.42, 0.30),
	"MOUNTAIN": Color(0.50, 0.48, 0.46),
}

# ── Gebäude-Visuals (Farbe + Höhe in Welteinheiten) ──────────────────────────
const BUILDING_VISUALS: Dictionary = {
	"CONSTRUCTION_YARD_1": {"color": Color(0.85,0.72,0.20), "h": 2.2},
	"CONSTRUCTION_YARD_2": {"color": Color(0.85,0.72,0.20), "h": 2.6},
	"ENGINEERS_GUILD":     {"color": Color(0.80,0.65,0.15), "h": 3.0},
	"CONSTRUCTION_OFFICE": {"color": Color(0.80,0.65,0.15), "h": 3.2},
	"LUMBERJACK":          {"color": Color(0.50,0.30,0.12), "h": 1.8},
	"QUARRY":              {"color": Color(0.62,0.60,0.55), "h": 1.2},
	"BERRY_GATHERER":      {"color": Color(0.65,0.25,0.45), "h": 1.5},
	"WELL":                {"color": Color(0.40,0.62,0.88), "h": 1.6},
	"WATER_TOWER":         {"color": Color(0.50,0.65,0.78), "h": 3.8},
	"WATER_PUMP":          {"color": Color(0.45,0.60,0.75), "h": 2.2},
	"AQUEDUCT":            {"color": Color(0.70,0.82,0.90), "h": 1.5},
	"RESERVOIR":           {"color": Color(0.30,0.55,0.80), "h": 1.2},
	"IRRIGATION":          {"color": Color(0.40,0.62,0.88), "h": 0.5},
	"STORAGE":             {"color": Color(0.88,0.68,0.32), "h": 2.2},
	"LARGE_STORAGE":       {"color": Color(0.82,0.60,0.28), "h": 2.8},
	"FOOD_STORE":          {"color": Color(0.75,0.88,0.50), "h": 2.4},
	"WAREHOUSE":           {"color": Color(0.80,0.65,0.30), "h": 3.0},
	"HOUSE":               {"color": Color(0.88,0.48,0.28), "h": 2.5},
	"GATHERING_PLACE":     {"color": Color(0.92,0.78,0.40), "h": 1.5},
	"TAVERN":              {"color": Color(0.80,0.35,0.18), "h": 2.8},
	"BATHHOUSE":           {"color": Color(0.62,0.72,0.88), "h": 2.6},
	"THEATER":             {"color": Color(0.72,0.30,0.62), "h": 3.5},
	"GARDEN":              {"color": Color(0.35,0.78,0.35), "h": 0.6},
	"CROP_FIELD":          {"color": Color(0.88,0.82,0.30), "h": 0.4},
	"WHEAT_FARM":          {"color": Color(0.85,0.80,0.25), "h": 0.5},
	"FORESTER":            {"color": Color(0.20,0.55,0.20), "h": 1.8},
	"SAWMILL":             {"color": Color(0.55,0.35,0.15), "h": 2.0},
	"WORKSHOP":            {"color": Color(0.70,0.55,0.35), "h": 2.2},
	"COOKHOUSE":           {"color": Color(0.75,0.40,0.20), "h": 2.0},
	"HUNTER_HUT":          {"color": Color(0.45,0.30,0.18), "h": 1.8},
	"EXPEDITION_CAMP":     {"color": Color(0.60,0.55,0.38), "h": 1.5},
	"GRAVEYARD":           {"color": Color(0.40,0.42,0.42), "h": 0.8},
	"IRON_MINE":           {"color": Color(0.50,0.48,0.45), "h": 2.0},
	"COAL_MINE":           {"color": Color(0.25,0.25,0.28), "h": 1.8},
	"SMELTER":             {"color": Color(0.80,0.35,0.10), "h": 3.0},
	"BLAST_FURNACE":       {"color": Color(0.85,0.30,0.08), "h": 3.5},
	"MACHINE_FACTORY":     {"color": Color(0.40,0.40,0.50), "h": 3.8},
	"WATERWHEEL":          {"color": Color(0.55,0.42,0.22), "h": 2.5},
	"DAM":                 {"color": Color(0.52,0.48,0.42), "h": 1.6},
	"STATUE":              {"color": Color(0.85,0.82,0.72), "h": 4.0},
	"DYNAMITE_WORKSHOP":   {"color": Color(0.75,0.15,0.15), "h": 2.0},
	"DECO_FLOWERS":        {"color": Color(0.95,0.55,0.70), "h": 0.4},
	"DECO_MUSHROOM":       {"color": Color(0.85,0.30,0.20), "h": 0.6},
	"DECO_LANTERN":        {"color": Color(0.95,0.90,0.40), "h": 0.8},
	"DECO_STONES":         {"color": Color(0.60,0.58,0.55), "h": 0.5},
	"DECO_BUSH":           {"color": Color(0.30,0.65,0.25), "h": 0.7},
}

const BUILDING_EMOJIS: Dictionary = {
	"CONSTRUCTION_YARD_1":"🏗","CONSTRUCTION_YARD_2":"🏗",
	"ENGINEERS_GUILD":"🏗","CONSTRUCTION_OFFICE":"🏗",
	"LUMBERJACK":"🪓","QUARRY":"⛏","BERRY_GATHERER":"🫐",
	"WELL":"🪣","WATER_TOWER":"⛲","WATER_PUMP":"🚿",
	"AQUEDUCT":"🌊","IRRIGATION":"💧","RESERVOIR":"🏗",
	"STORAGE":"📦","LARGE_STORAGE":"📦","FOOD_STORE":"🍱",
	"WAREHOUSE":"📦","HOUSE":"🏠","GATHERING_PLACE":"🎪",
	"TAVERN":"🍺","BATHHOUSE":"🛁","THEATER":"🎭",
	"GARDEN":"🌻","CROP_FIELD":"🌾","WHEAT_FARM":"🌾",
	"FORESTER":"🌲","SAWMILL":"🪚","WORKSHOP":"🔨",
	"COOKHOUSE":"🍲","HUNTER_HUT":"🏹","EXPEDITION_CAMP":"🗺",
	"GRAVEYARD":"🪦","IRON_MINE":"⛏","COAL_MINE":"⚫",
	"SMELTER":"🔥","BLAST_FURNACE":"🔥","MACHINE_FACTORY":"🤖",
	"WATERWHEEL":"⚙","STATUE":"🗿","DYNAMITE_WORKSHOP":"🧨",
	"DAM":"🧱",
	"DECO_FLOWERS":"🌸","DECO_MUSHROOM":"🍄","DECO_LANTERN":"🪔",
	"DECO_STONES":"🪨","DECO_BUSH":"🌿",
}

# ── State ─────────────────────────────────────────────────────────────────────
var world:    Array = []
var world_w:  int   = 60
var world_h:  int   = 60
var is_drought: bool = false

# Selektion / Ghost
var selected_tile:     Vector2i = Vector2i(-1, -1)
var selected_building: BuildingEntity = null

# ── Interne Nodes ─────────────────────────────────────────────────────────────
var _terrain_node:    MeshInstance3D = null
var _water_node:      MeshInstance3D = null
var _col_body:        StaticBody3D   = null
var _building_root:   Node3D         = null
var _building_nodes:  Dictionary     = {}   # "tx,ty" → StaticBody3D
# Feature (v11.0, Lagersystem): "tx,ty" → Label3D mit dem Fuellstand des
# lokalen Lagers eines Produktionsgebaeudes - separat von _building_nodes,
# damit refresh_storage_labels() den Text aktualisieren kann, ohne jedesmal
# das komplette Gebaeude neu aufzubauen.
var _storage_labels:  Dictionary     = {}
# Feature (v11.1, Logistik-Feinschliff): ein einzelner ImmediateMesh-Node fuer
# alle aktuell aktiven Hauler-Linien (Pfeile/Linien zwischen Start und Ziel
# eines Transports) - wird periodisch komplett neu gezeichnet statt pro
# Linie einen eigenen Node zu verwalten, da sich die Anzahl aktiver Hauls
# staendig aendert.
var _haul_line_node:  MeshInstance3D  = null
var _haul_line_mesh:  ImmediateMesh   = null
# Feature (v11.1, Logistik-Feinschliff): zweites Overlay, gezeichnet nur beim
# Anklicken eines Gebaeudes - zeigt die POTENZIELLE Lieferkette (Produktions-
# gebaeude → Lagerhaus → Baustelle), nicht nur aktiv laufende Transporte.
var _chain_line_node: MeshInstance3D  = null
var _chain_line_mesh: ImmediateMesh   = null
var _ferret_root:     Node3D         = null
var _ferret_nodes:    Array          = []
var _highlight_node:  MeshInstance3D = null
var _ghost_node:      MeshInstance3D = null

# ── Materialien ───────────────────────────────────────────────────────────────
var _sel_mat:   StandardMaterial3D = null
var _ghost_mat: StandardMaterial3D = null

# ══════════════════════════════════════════════════════════════════════════════
func _ready() -> void:
	_building_root = Node3D.new(); _building_root.name = "Buildings"
	add_child(_building_root)
	_ferret_root = Node3D.new(); _ferret_root.name = "Ferrets"
	add_child(_ferret_root)
	_create_highlight()
	_create_ghost()
	_create_haul_lines()
	_create_chain_lines()

# ── Koordinaten ───────────────────────────────────────────────────────────────
func tile_to_world3d(tx: int, ty: int) -> Vector3:
	if world.is_empty():
		return Vector3(float(tx) * TILE_SIZE + TILE_SIZE * 0.5, 0.0,
					   float(ty) * TILE_SIZE + TILE_SIZE * 0.5)
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h:
		return Vector3(float(tx) * TILE_SIZE + TILE_SIZE * 0.5, 0.0,
					   float(ty) * TILE_SIZE + TILE_SIZE * 0.5)
	var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
	var h: float = float(tile.get("height", 0.0)) * HEIGHT_SCALE
	return Vector3(
		float(tx) * TILE_SIZE + TILE_SIZE * 0.5,
		h,
		float(ty) * TILE_SIZE + TILE_SIZE * 0.5
	)

func world3d_to_tile(pos: Vector3) -> Vector2i:
	return Vector2i(
		int(pos.x / TILE_SIZE),
		int(pos.z / TILE_SIZE)
	)

func map_center_3d() -> Vector3:
	@warning_ignore("integer_division")
	return tile_to_world3d(world_w / 2, world_h / 2)

# ══════════════════════════════════════════════════════════════════════════════
# WELT BAUEN
# ══════════════════════════════════════════════════════════════════════════════
func build_world() -> void:
	_clear_all()
	_build_terrain_mesh()
	_build_collision()
	_build_water_mesh(world)
	_rebuild_all_buildings()
	_place_trees()
	_place_bushes()

func _clear_all() -> void:
	if _terrain_node: _terrain_node.queue_free(); _terrain_node = null
	if _water_node:   _water_node.queue_free();   _water_node   = null
	if _col_body:     _col_body.queue_free();     _col_body = null
	if _trees_node:   _trees_node.queue_free();   _trees_node = null
	for key in _building_nodes:
		(_building_nodes[key] as Node).queue_free()
	_building_nodes.clear()
	_storage_labels.clear()
	_clear_ferrets()

## Stellt echte 3D-Bäume (Kiefer, GLB-Modell) auf jedes Tile, das einen
## Holz-Resource-Node trägt (gesetzt vom WorldGenerator auf ~35% der
## FOREST-Tiles). Ersetzt die bisherige rein farbliche "Wald"-Darstellung.
func _place_trees() -> void:
	if _trees_node:
		_trees_node.queue_free()
		_trees_node = null
	_tree_nodes.clear()
	_trees_node = Node3D.new()
	_trees_node.name = "Trees"
	add_child(_trees_node)
	for x in world_w:
		var col: Array = world[x] as Array
		for y in world_h:
			var tile: Dictionary = col[y] as Dictionary
			if tile.get("building") != null: continue
			var node_data = tile.get("resource_node")
			if node_data == null or not (node_data is Dictionary): continue
			if str((node_data as Dictionary).get("type","")) != "WOOD": continue
			var tree := PINE_TREE_SCENE.instantiate() as Node3D
			var base_pos: Vector3 = tile_to_world3d(x, y)
			# leichter Zufalls-Versatz innerhalb des Tiles, sonst wirkt es zu gitterartig
			base_pos.x += randf_range(-TILE_SIZE*0.28, TILE_SIZE*0.28)
			base_pos.z += randf_range(-TILE_SIZE*0.28, TILE_SIZE*0.28)
			tree.position = base_pos
			tree.rotation.y = randf_range(0.0, TAU)
			# Deutlich sichtbare Groessen-/Hoehenvarianz (vorher nur ±15%,
			# wirkte zu gleichfoermig) - von kleinen Jungbaeumen bis zu
			# grossen, alten Baeumen in derselben Waldflaeche.
			var s: float = TREE_BASE_SCALE * randf_range(0.65, 1.45)
			tree.scale = Vector3(s, s, s)
			_trees_node.add_child(tree)
			_tree_nodes["%d,%d" % [x, y]] = {"node": tree, "base_scale": s}

func _place_bushes() -> void:
	if _bushes_node:
		_bushes_node.queue_free()
		_bushes_node = null
	_bush_nodes.clear()
	_bushes_node = Node3D.new()
	_bushes_node.name = "Bushes"
	add_child(_bushes_node)
	for x in world_w:
		var col: Array = world[x] as Array
		for y in world_h:
			var tile: Dictionary = col[y] as Dictionary
			if tile.get("building") != null: continue
			var node_data = tile.get("resource_node")
			if node_data == null or not (node_data is Dictionary): continue
			if str((node_data as Dictionary).get("type","")) != "BERRIES": continue
			var bush := BUSH_SCENE.instantiate() as Node3D
			var base_pos: Vector3 = tile_to_world3d(x, y)
			base_pos.x += randf_range(-TILE_SIZE*0.22, TILE_SIZE*0.22)
			base_pos.z += randf_range(-TILE_SIZE*0.22, TILE_SIZE*0.22)
			bush.position = base_pos
			bush.rotation.y = randf_range(0.0, TAU)
			var s: float = BUSH_BASE_SCALE * randf_range(0.75, 1.3)
			bush.scale = Vector3(s, s, s)
			_bushes_node.add_child(bush)
			_bush_nodes["%d,%d" % [x, y]] = {"node": bush, "base_scale": s}

## Feature (v10.10): wird periodisch (gedrosselt, siehe GameController) auf-
## gerufen, solange das Spiel laeuft, und skaliert Baeume/Buesche je nach
## Rest-Ressourcenmenge der zugehoerigen Tile (resource_node.amount /
## max_amount) - so sieht man Baeume beim Abholzen schrumpfen und Buesche
## "kahl" werden, und beide wachsen sichtbar wieder, sobald die Quelle
## regeneriert. Eine voellig erschoepfte Quelle bleibt als kleiner, fast
## verschwindender Rest (Stumpf/kahler Strauch) sichtbar statt komplett zu
## verschwinden.
const _MIN_VEGETATION_SCALE: float = 0.22

func refresh_vegetation() -> void:
	_refresh_vegetation_dict(_tree_nodes)
	_refresh_vegetation_dict(_bush_nodes)
	_spawn_missing_vegetation()

## Bug-Fix (v10.14): Baum-/Busch-Modelle entstehen normalerweise nur EINMAL
## beim initialen Terrain-Aufbau (_place_trees()/_place_bushes()). Neue
## Resource-Nodes, die erst WAEHREND des Spiels entstehen (z.B. von der
## Försterei gepflanzt, siehe BuildingEntity._plant_trees()), hätten ohne
## diese Funktion KEIN sichtbares Modell - Holzfäller würden "unsichtbare"
## Bäume abholzen. Erkennt solche Faelle und spawnt nachtraeglich das
## passende Modell (klein startend, waechst dann ueber die normale
## amount/max_amount-Skalierung in _refresh_vegetation_dict() nach).
func _spawn_missing_vegetation() -> void:
	for x in world_w:
		var col: Array = world[x] as Array
		for y in world_h:
			var tile: Dictionary = col[y] as Dictionary
			if tile.get("building") != null: continue
			var node_data = tile.get("resource_node")
			if node_data == null or not (node_data is Dictionary): continue
			var nd: Dictionary = node_data
			var key: String = "%d,%d" % [x, y]
			var rtype: String = str(nd.get("type", ""))
			if rtype == "WOOD" and not _tree_nodes.has(key):
				var tree := PINE_TREE_SCENE.instantiate() as Node3D
				var base_pos: Vector3 = tile_to_world3d(x, y)
				base_pos.x += randf_range(-TILE_SIZE * 0.28, TILE_SIZE * 0.28)
				base_pos.z += randf_range(-TILE_SIZE * 0.28, TILE_SIZE * 0.28)
				tree.position = base_pos
				tree.rotation.y = randf_range(0.0, TAU)
				var s: float = TREE_BASE_SCALE * randf_range(0.65, 1.45)
				tree.scale = Vector3.ONE * s * _MIN_VEGETATION_SCALE
				_trees_node.add_child(tree)
				_tree_nodes[key] = {"node": tree, "base_scale": s}
			elif rtype == "BERRIES" and not _bush_nodes.has(key):
				var bush := BUSH_SCENE.instantiate() as Node3D
				var base_pos2: Vector3 = tile_to_world3d(x, y)
				base_pos2.x += randf_range(-TILE_SIZE * 0.22, TILE_SIZE * 0.22)
				base_pos2.z += randf_range(-TILE_SIZE * 0.22, TILE_SIZE * 0.22)
				bush.position = base_pos2
				bush.rotation.y = randf_range(0.0, TAU)
				var s2: float = BUSH_BASE_SCALE * randf_range(0.75, 1.3)
				bush.scale = Vector3.ONE * s2 * _MIN_VEGETATION_SCALE
				_bushes_node.add_child(bush)
				_bush_nodes[key] = {"node": bush, "base_scale": s2}

func _refresh_vegetation_dict(nodes: Dictionary) -> void:
	for key in nodes.keys():
		var entry: Dictionary = nodes[key] as Dictionary
		var node: Node3D = entry.get("node") as Node3D
		if node == null or not is_instance_valid(node): continue
		var coords: PackedStringArray = (key as String).split(",")
		var tx: int = int(coords[0])
		var ty: int = int(coords[1])
		if tx < 0 or tx >= world_w or ty < 0 or ty >= world_h: continue
		var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
		var node_data = tile.get("resource_node")
		if node_data == null or not (node_data is Dictionary): continue
		var nd: Dictionary = node_data
		var max_amount: float = maxf(1.0, float(nd.get("max_amount", 100.0)))
		var frac: float = clampf(float(nd.get("amount", max_amount)) / max_amount, 0.0, 1.0)
		var base_scale: float = float(entry.get("base_scale", 1.0))
		var scale_mult: float = lerpf(_MIN_VEGETATION_SCALE, 1.0, frac)
		var s: float = base_scale * scale_mult
		node.scale = Vector3(s, s, s)

# ── Terrain-Mesh ──────────────────────────────────────────────────────────────
## Liefert (gecacht) das Textur-Material fuer ein Biom. Nearest-Filter haelt
## den Pixelart-Look des Tilesets scharf statt ihn weichzuzeichnen.
func _get_top_material(biome: String) -> StandardMaterial3D:
	if _top_materials.has(biome):
		return _top_materials[biome]
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = TILE_TEXTURES.get(biome, TILE_TEXTURES["PLAINS"]) as Texture2D
	mat.vertex_color_use_as_albedo = true
	mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mat.roughness = 0.88
	mat.metallic  = 0.0
	_top_materials[biome] = mat
	return mat

func _get_side_material(biome: String) -> StandardMaterial3D:
	if _side_materials.has(biome):
		return _side_materials[biome]
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = TILE_SIDE_TEXTURES.get(biome, TILE_SIDE_TEXTURES["PLAINS"]) as Texture2D
	mat.vertex_color_use_as_albedo = true
	mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mat.roughness = 0.92
	mat.metallic  = 0.0
	# Bug-Fix (v11.3): CULL_DISABLED macht BEIDE Seiten jedes Quads sichtbar,
	# unabhaengig von Winding-Order. Damit ist die "zur Kamera zeigende Seite
	# transparent"-Problem garantiert geloest, auch wenn generate_normals()
	# die Normalen fuer Backface-Culling-Berechnung durch Averaging verfaelscht
	# haette.
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_side_materials[biome] = mat
	return mat

func _build_terrain_mesh() -> void:
	if _terrain_node:
		_terrain_node.queue_free()
		_terrain_node = null

	# Pro Biom je ein SurfaceTool fuer Oberseiten UND Seitenflaechen -
	# dadurch bekommt jede Seitenflaeche das richtige Seiten-Material (z.B.
	# MOUNTAIN bekommt Steinmauerwerk-Seiten, PLAINS bekommt Erde-Seiten)
	# anstatt einer einzigen globalen Flat-Color-Seite wie bisher.
	var top_tools:  Dictionary = {}
	var side_tools: Dictionary = {}
	var top_counts:  Dictionary = {}
	var side_counts: Dictionary = {}
	for biome in TILE_TEXTURES.keys():
		var st_t := SurfaceTool.new()
		st_t.begin(Mesh.PRIMITIVE_TRIANGLES)
		st_t.set_material(_get_top_material(biome))
		top_tools[biome] = st_t
		var st_s := SurfaceTool.new()
		st_s.begin(Mesh.PRIMITIVE_TRIANGLES)
		st_s.set_material(_get_side_material(biome))
		side_tools[biome] = st_s
		top_counts[biome]  = 0
		side_counts[biome] = 0

	for x in world_w:
		for z in world_h:
			var tile: Dictionary = (world[x] as Array)[z] as Dictionary
			var biome: String    = str(tile.get("biome", "PLAINS"))
			if not top_tools.has(biome): biome = "PLAINS"
			var h: float         = float(tile.get("height", 0.0)) * HEIGHT_SCALE

			var top_c:  Color = Color.WHITE
			var side_c: Color = Color.WHITE

			if biome == "WATER":
				var wlvl: float = float(tile.get("water_level", 1.0))
				if wlvl < 0.4:
					var mud: Color = Color(0.42, 0.36, 0.24)
					var dry_t: float = 1.0 - clampf(wlvl / 0.4, 0.0, 1.0)
					top_c  = top_c.lerp(mud, dry_t)
					side_c = side_c.lerp(mud.darkened(0.18), dry_t)

			if is_drought and biome in ["PLAINS", "FOREST", "BEACH"]:
				top_c  = top_c.lerp(Color(0.72, 0.60, 0.28), 0.35)
				side_c = side_c.lerp(Color(0.60, 0.48, 0.20), 0.30)

			if tile.get("path") != null:
				top_c = top_c.lerp(Color(0.55, 0.50, 0.40), 0.45)

			_add_top_quad(top_tools[biome] as SurfaceTool, x, z, h, top_c)
			top_counts[biome] = int(top_counts[biome]) + 1
			if h > 0.05:
				_add_side_quads(side_tools[biome] as SurfaceTool, x, z, h, side_c)
				side_counts[biome] = int(side_counts[biome]) + 1

	var mesh := ArrayMesh.new()
	for biome in top_tools.keys():
		if int(top_counts[biome]) == 0: continue
		var st_t: SurfaceTool = top_tools[biome]
		st_t.generate_normals()
		mesh = st_t.commit(mesh)
	# Bug-Fix (v11.3): Side-SurfaceTools bekommen KEIN generate_normals() mehr.
	# generate_normals() wuerde die manuell gesetzten Normals (set_normal())
	# durch gemittelte Smooth-Normals ersetzen - bei geteilten Eckpunkten
	# zwischen verschiedenen Seiten-Quads koennte das eine komplett falsche
	# Normale ergeben. Da wir CULL_DISABLED nutzen, spielen Normals fuer das
	# Culling ohnehin keine Rolle mehr (nur noch fuer Beleuchtung).
	# Ausserdem: Surfaces mit 0 Vertices ueberspringen - ein leerer
	# SurfaceTool-Commit koennte den ArrayMesh beschaedigen und damit
	# auch create_trimesh_shape() fuer die Kollision kaputt machen.
	for biome in side_tools.keys():
		if int(side_counts[biome]) == 0: continue
		var st_s: SurfaceTool = side_tools[biome]
		mesh = st_s.commit(mesh)

	_terrain_node = MeshInstance3D.new()
	_terrain_node.name = "Terrain"
	_terrain_node.mesh = mesh
	_terrain_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_terrain_node)

func _add_top_quad(st: SurfaceTool, tx: int, tz: int, h: float, color: Color) -> void:
	var x0: float = float(tx) * TILE_SIZE
	var x1: float = x0 + TILE_SIZE
	var z0: float = float(tz) * TILE_SIZE
	var z1: float = z0 + TILE_SIZE
	st.set_color(color)
	st.set_normal(Vector3.UP)
	# Deterministische Pseudo-Zufallsspiegelung der Textur pro Tile (U/V),
	# damit sich die Wiederholung der einzelnen Tile-Grafik nicht als
	# sichtbares Gitter-Muster abzeichnet. Haengt nur von der Tile-Position
	# ab, bleibt also bei jedem Mesh-Rebuild stabil (kein Flackern).
	var seed_val: int = (tx * 92821) ^ (tz * 689287)
	var flip_u: bool = (seed_val & 1) == 1
	var flip_v: bool = (seed_val & 2) == 2
	var u0: float = 1.0 if flip_u else 0.0
	var u1: float = 0.0 if flip_u else 1.0
	var v0: float = 1.0 if flip_v else 0.0
	var v1: float = 0.0 if flip_v else 1.0
	st.set_uv(Vector2(u0, v0)); st.add_vertex(Vector3(x0, h, z0))
	st.set_uv(Vector2(u1, v0)); st.add_vertex(Vector3(x1, h, z0))
	st.set_uv(Vector2(u1, v1)); st.add_vertex(Vector3(x1, h, z1))
	st.set_uv(Vector2(u0, v0)); st.add_vertex(Vector3(x0, h, z0))
	st.set_uv(Vector2(u1, v1)); st.add_vertex(Vector3(x1, h, z1))
	st.set_uv(Vector2(u0, v1)); st.add_vertex(Vector3(x0, h, z1))

func _add_side_quads(st: SurfaceTool, tx: int, tz: int, h: float, color: Color) -> void:
	var x0: float = float(tx) * TILE_SIZE
	var x1: float = x0 + TILE_SIZE
	var z0: float = float(tz) * TILE_SIZE
	var z1: float = z0 + TILE_SIZE
	# UV-V skaliert mit der Tile-Hoehe damit die Texturschichten immer
	# gleich "dick" aussehen, egal wie hoch die Klippe ist - bei doppelter
	# Hoehe werden die Schichten einfach zweimal wiederholt statt gestreckt.
	var v_repeat: float = h / HEIGHT_SCALE   # z.B. h=2.4, HEIGHT_SCALE=1.2 → 2.0 Wiederholungen
	var dark_front: Color = color.darkened(0.10)
	var dark_back:  Color = color.darkened(0.18)
	var dark_left:  Color = color.darkened(0.22)
	var dark_right: Color = color.darkened(0.14)

	# Seite Z- (Nord / Vorderseite)
	st.set_color(dark_front); st.set_normal(Vector3(0, 0, -1))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x0, h,   z0))
	st.set_uv(Vector2(1.0, 0.0));       st.add_vertex(Vector3(x1, h,   z0))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z0))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x0, h,   z0))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z0))
	st.set_uv(Vector2(0.0, v_repeat));  st.add_vertex(Vector3(x0, 0.0, z0))

	# Seite Z+ (Süd / Rückseite)
	st.set_color(dark_back); st.set_normal(Vector3(0, 0, 1))
	st.set_uv(Vector2(1.0, 0.0));       st.add_vertex(Vector3(x0, h,   z1))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x0, 0.0, z1))
	st.set_uv(Vector2(0.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z1))
	st.set_uv(Vector2(1.0, 0.0));       st.add_vertex(Vector3(x0, h,   z1))
	st.set_uv(Vector2(0.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z1))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x1, h,   z1))

	# Seite X- (West)
	st.set_color(dark_left); st.set_normal(Vector3(-1, 0, 0))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x0, h,   z1))
	st.set_uv(Vector2(1.0, 0.0));       st.add_vertex(Vector3(x0, h,   z0))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x0, 0.0, z0))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x0, h,   z1))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x0, 0.0, z0))
	st.set_uv(Vector2(0.0, v_repeat));  st.add_vertex(Vector3(x0, 0.0, z1))

	# Seite X+ (Ost)
	st.set_color(dark_right); st.set_normal(Vector3(1, 0, 0))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x1, h,   z0))
	st.set_uv(Vector2(1.0, 0.0));       st.add_vertex(Vector3(x1, h,   z1))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z1))
	st.set_uv(Vector2(0.0, 0.0));       st.add_vertex(Vector3(x1, h,   z0))
	st.set_uv(Vector2(1.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z1))
	st.set_uv(Vector2(0.0, v_repeat));  st.add_vertex(Vector3(x1, 0.0, z0))

# ── Terrain-Kollision (für Raycast) ──────────────────────────────────────────
## Bug-Fix (Klick-Versatz): Die Kollision wurde bisher als FLACHE Box bei y=0
## gebaut, unabhaengig von der tatsaechlichen (variierenden) Tile-Hoehe. Der
## Raycast traf also bei jedem nicht-flachen Tile (Huegel/Berge - praktisch
## ueberall, da WorldGenerator fast immer eine Hoehe > 0 erzeugt) eine falsche
## Ebene, wodurch der getroffene Weltpunkt und damit das ausgewaehlte Tile
## gegenueber der echten Mausposition versetzt war. Fix: Kollisionsform wird
## jetzt direkt aus dem sichtbaren Terrain-Mesh erzeugt (Trimesh), sodass der
## Raycast exakt die gerenderte Oberflaeche trifft.
func _build_collision() -> void:
	if _col_body:
		_col_body.queue_free()
		_col_body = null
	if _terrain_node == null or _terrain_node.mesh == null:
		return
	_col_body = StaticBody3D.new()
	_col_body.name = "TerrainCollider"
	_col_body.collision_layer = 1
	_col_body.collision_mask  = 0

	# Kollisionsstrategie (v11.3):
	# TOP-Flaeche: Trimesh des sichtbaren Meshes - erlaubt praezises Klick-
	#   Raycasting und glattes Laufen ueber Huegel/Steigungen.
	# SEITEN: Pro erhoehetem Tile (h > 0.05) eine eigene BoxShape3D - macht die
	#   Seiten begehbar UND undurchdringbar. Duenne Trimesh-Wand-Quads haben den
	#   Nachteil, dass CharacterBody3D sie bei schraegemAufprall durchdringen
	#   kann (bekanntes Godot-Problem mit Trimesh vs. CharacterBody3D). Mit
	#   soliden Boxen ist das nicht moeglich.
	var cs_top := CollisionShape3D.new()
	cs_top.shape = _terrain_node.mesh.create_trimesh_shape()
	cs_top.position = Vector3.ZERO
	_col_body.add_child(cs_top)

	# Box-Kollisionen fuer Seitenflaechen
	var box_pool: BoxShape3D = BoxShape3D.new()
	box_pool.size = Vector3(TILE_SIZE, 1.0, TILE_SIZE)  # Vorlage, wird je Tile angepasst
	for x in world_w:
		for z in world_h:
			var tile: Dictionary = (world[x] as Array)[z] as Dictionary
			var h: float = float(tile.get("height", 0.0)) * HEIGHT_SCALE
			if h <= 0.05: continue
			var box := BoxShape3D.new()
			box.size = Vector3(TILE_SIZE, h, TILE_SIZE)
			var cs_box := CollisionShape3D.new()
			cs_box.shape = box
			# Mittelpunkt der Box: x-Mitte, halbe Hoehe, z-Mitte des Tiles
			cs_box.position = Vector3(
				float(x) * TILE_SIZE + TILE_SIZE * 0.5,
				h * 0.5,
				float(z) * TILE_SIZE + TILE_SIZE * 0.5
			)
			_col_body.add_child(cs_box)

	_col_body.position = Vector3.ZERO
	add_child(_col_body)

# ── Wasseroberflaeche (Wasserphysik) ──────────────────────────────────────────
## Baut eine eigene, halbtransparente Wasser-Oberflaechen-Mesh - eine Quad pro
## Tile mit water_level > 0, auf Hoehe (Terrain-Bett + simulierter Pegel) statt
## der statischen Terrain-Hoehe. Dadurch sieht man Fluesse/Seen tatsaechlich
## steigen und fallen (Quellen-Zufluss, Verdunstung, Duerre), statt einer
## starren Wasserflaeche. Wird nicht bei jedem Terrain-Refresh neu gebaut
## (zu teuer fuer haeufige Aufrufe wie beim Terrain-Drag), sondern separat
## und gedrosselt ueber refresh_water() von GameController aus.
##
## Bug-Fix/Feature (v10.16): "Uebergaenge zwischen Wassertiles zu hart" -
## bisher bekam JEDES Wasser-Tile eine eigene, in sich FLACHE Quad-Flaeche
## auf seiner eigenen surf-Hoehe. Lagen zwei benachbarte Tiles auf
## unterschiedlichem water_level (z.B. ein flacher Fluss-Arm neben einem
## tiefen Becken, oder die Flanke eines austrocknenden Sees), entstand an
## der gemeinsamen Tile-Kante eine sichtbare, treppenartige Stufe statt
## einer fliessenden Oberflaeche. Die Oberflaeche wird jetzt wie ein echtes
## Hoehenfeld behandelt: jede Gitter-ECKE (nicht mehr jede Tile-FLAECHE)
## bekommt eine gemeinsame Hoehe, gemittelt aus den bis zu 4 angrenzenden
## Wasser-Tiles (_water_corner_data). Da benachbarte Quads dieselbe
## vorberechnete Eckhoehe referenzieren, treffen sie exakt aneinander -
## kontinuierliche, weiche Oberflaeche statt Treppen. Die Tiefenfarbe
## (depth_pct -> Alpha) wird nach demselben Prinzip pro Ecke gemittelt und
## dann ueber die Quad-Flaeche interpoliert, statt hart pro Tile zu wechseln.
func _build_water_mesh(src_world: Array) -> void:
	if _water_node:
		_water_node.queue_free()
		_water_node = null
	if src_world.is_empty():
		return

	var corner_h: Dictionary = _water_corner_data(src_world, true)
	var corner_d: Dictionary = _water_corner_data(src_world, false)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode    = BaseMaterial3D.CULL_DISABLED
	mat.roughness    = 0.05
	mat.metallic     = 0.25
	st.set_material(mat)

	var any_water: bool = false
	for x in world_w:
		var col: Array = src_world[x] as Array
		for z in world_h:
			var tile: Dictionary = col[z] as Dictionary
			var lvl: float = float(tile.get("water_level", 0.0))
			if lvl <= 0.02: continue
			any_water = true
			_add_smooth_water_quad(st, x, z, corner_h, corner_d)

	if not any_water:
		return
	st.generate_normals()
	_water_node = MeshInstance3D.new()
	_water_node.name = "WaterSurface"
	_water_node.mesh = st.commit()
	_water_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_water_node)

## Berechnet pro Gitter-Ecke (gx,gz mit gx in [0,world_w], gz in [0,world_h])
## den Mittelwert ueber die bis zu 4 angrenzenden Wasser-Tiles - entweder der
## Oberflaechenhoehe (want_height=true) oder des depth_pct-Werts
## (want_height=false, fuer die Farbinterpolation). Tiles ohne Wasser
## (water_level <= 0.02) und Tiles ausserhalb der Karte fliessen nicht in
## den Mittelwert ein. Gibt nur Ecken zurueck, an denen mindestens ein
## Wasser-Tile angrenzt.
func _water_corner_data(src_world: Array, want_height: bool) -> Dictionary:
	var result: Dictionary = {}
	for gx in range(world_w + 1):
		for gz in range(world_h + 1):
			var total: float = 0.0
			var count: int = 0
			for ddx in [-1, 0]:
				for ddz in [-1, 0]:
					var tx: int = gx + ddx
					var tz: int = gz + ddz
					if tx < 0 or tz < 0 or tx >= world_w or tz >= world_h: continue
					var tile: Dictionary = (src_world[tx] as Array)[tz] as Dictionary
					var lvl: float = float(tile.get("water_level", 0.0))
					if lvl <= 0.02: continue
					if want_height:
						var bed: float = float(tile.get("height", 0.0)) * HEIGHT_SCALE
						total += bed + lvl * HEIGHT_SCALE
					else:
						total += clampf(lvl / 2.0, 0.0, 1.0)
					count += 1
			if count > 0:
				result["%d,%d" % [gx, gz]] = total / float(count)
	return result

func _add_smooth_water_quad(st: SurfaceTool, tx: int, tz: int, corner_h: Dictionary, corner_d: Dictionary) -> void:
	var x0: float = float(tx) * TILE_SIZE
	var x1: float = x0 + TILE_SIZE
	var z0: float = float(tz) * TILE_SIZE
	var z1: float = z0 + TILE_SIZE

	var h00: float = float(corner_h.get("%d,%d" % [tx,   tz],   0.0))
	var h10: float = float(corner_h.get("%d,%d" % [tx+1, tz],   0.0))
	var h11: float = float(corner_h.get("%d,%d" % [tx+1, tz+1], 0.0))
	var h01: float = float(corner_h.get("%d,%d" % [tx,   tz+1], 0.0))
	var d00: float = float(corner_d.get("%d,%d" % [tx,   tz],   0.0))
	var d10: float = float(corner_d.get("%d,%d" % [tx+1, tz],   0.0))
	var d11: float = float(corner_d.get("%d,%d" % [tx+1, tz+1], 0.0))
	var d01: float = float(corner_d.get("%d,%d" % [tx,   tz+1], 0.0))

	var c00: Color = Color(0.16, 0.42, 0.78, 0.42 + d00 * 0.40)
	var c10: Color = Color(0.16, 0.42, 0.78, 0.42 + d10 * 0.40)
	var c11: Color = Color(0.16, 0.42, 0.78, 0.42 + d11 * 0.40)
	var c01: Color = Color(0.16, 0.42, 0.78, 0.42 + d01 * 0.40)

	st.set_normal(Vector3.UP)
	st.set_color(c00); st.add_vertex(Vector3(x0, h00, z0))
	st.set_color(c10); st.add_vertex(Vector3(x1, h10, z0))
	st.set_color(c11); st.add_vertex(Vector3(x1, h11, z1))

	st.set_color(c00); st.add_vertex(Vector3(x0, h00, z0))
	st.set_color(c11); st.add_vertex(Vector3(x1, h11, z1))
	st.set_color(c01); st.add_vertex(Vector3(x0, h01, z1))

## Oeffentliche API, von GameController in einem gedrosselten Intervall
## aufgerufen (siehe _process()), damit die Wasseroberflaeche der laufenden
## WaterSystem-Simulation folgt, ohne sie bei jedem einzelnen Frame neu zu
## erzeugen (Performance).
func refresh_water(src_world: Array) -> void:
	_build_water_mesh(src_world)

# ── Drought-Update ────────────────────────────────────────────────────────────
## Öffentliche API für Terrain-Neubau (Wege, Höhenänderungen).
## Baut auch die Kollision neu, da sich bei Hoehenaenderungen (z.B. Erde
## aufschuetten) sonst die Klickerkennung von der sichtbaren Oberflaeche
## entkoppeln wuerde (Klick-Versatz-Bug).
func refresh_terrain() -> void:
	_build_terrain_mesh()
	_build_collision()

func apply_drought(drought: bool) -> void:
	if drought == is_drought: return
	is_drought = drought
	_build_terrain_mesh()   # Farben neu backen

# ══════════════════════════════════════════════════════════════════════════════
# GEBÄUDE
# ══════════════════════════════════════════════════════════════════════════════
## Faerbt NUR die Wand-Flaeche eines instanzierten Gebaeude-Modells ein
## (v10.20). Bis v10.19 hatte building.glb nur EIN Material fuer das gesamte
## Modell - material_override auf der MeshInstance3D selbst hat deshalb
## zwangsweise alles (inkl. Dach, Fenster, Sockel etc.) einheitlich
## eingefaerbt. Das ueberarbeitete Modell liefert jetzt 7 getrennte
## Material-Flaechen ("Dach", "Pfeiler_Holzbalken", "Wand", "Gras_Busch",
## "Fenster_Dunkel", "Schornstein", "Sockel_Stein") als eigene Surfaces einer
## einzigen Mesh-Resource. Statt material_override (faerbt ALLE Surfaces)
## wird hier gezielt nur die Surface mit dem Material-Namen "Wand" per
## set_surface_override_material() ersetzt - alle anderen Teile behalten ihr
## importiertes Original-Material (und damit Look/Textur) bei. So bleibt der
## Gesamt-Look des Gebaeudes erhalten, aber die Wandfarbe gibt weiterhin
## Auskunft ueber den Gebaeudetyp.
const BUILDING_WALL_MATERIAL_NAME: String = "Wand"

func _tint_building_wall(node: Node, col: Color) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		var mesh := mi.mesh
		if mesh != null:
			for i in mesh.get_surface_count():
				var base_mat: Material = mesh.surface_get_material(i)
				var mat_name: String = base_mat.resource_name if base_mat != null else ""
				if mat_name == BUILDING_WALL_MATERIAL_NAME:
					var tinted := StandardMaterial3D.new()
					tinted.albedo_color = col
					tinted.roughness = 0.78
					mi.set_surface_override_material(i, tinted)
	for child in node.get_children():
		_tint_building_wall(child, col)

func _rebuild_all_buildings() -> void:
	for key in _building_nodes:
		(_building_nodes[key] as Node).queue_free()
	_building_nodes.clear()
	_storage_labels.clear()
	for x in world_w:
		for y in world_h:
			var tile: Dictionary = (world[x] as Array)[y] as Dictionary
			var bld = tile.get("building")
			if bld != null:
				_spawn_building(bld as BuildingEntity)

func refresh_buildings() -> void:
	_rebuild_all_buildings()

func add_building(b: BuildingEntity) -> void:
	var key: String = "%d,%d" % [b.tile_x, b.tile_y]
	if _building_nodes.has(key):
		(_building_nodes[key] as Node).queue_free()
		_building_nodes.erase(key)
	_storage_labels.erase(key)
	_spawn_building(b)

func remove_building(tx: int, ty: int) -> void:
	var key: String = "%d,%d" % [tx, ty]
	if _building_nodes.has(key):
		(_building_nodes[key] as Node).queue_free()
		_building_nodes.erase(key)
	_storage_labels.erase(key)

func _spawn_building(b: BuildingEntity) -> void:
	var key: String = "%d,%d" % [b.tile_x, b.tile_y]
	var wp:  Vector3 = tile_to_world3d(b.tile_x, b.tile_y)
	var vis: Dictionary = BUILDING_VISUALS.get(
		b.id, {"color": Color(0.65, 0.65, 0.65), "h": 2.0}
	) as Dictionary
	var bh:  float = float(vis.get("h",  2.0)) * (1.0 + float(b.level - 1) * 0.18)
	var col: Color = vis.get("color", Color(0.65, 0.65, 0.65)) as Color

	# ── Root ──
	var root := StaticBody3D.new()
	root.name = "Bld_%s" % key
	root.collision_layer = 2
	root.collision_mask  = 0
	root.set_meta("tile_x", b.tile_x)
	root.set_meta("tile_y", b.tile_y)

	# Kollision
	var cs    := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size   = Vector3(TILE_SIZE * 0.86, bh, TILE_SIZE * 0.86)
	cs.shape     = shape
	cs.position  = Vector3(0.0, bh * 0.5, 0.0)
	root.add_child(cs)

	# ── Hauptkörper ──
	# Feature (v10.16/v10.18, Asset-Wechsel v10.19, materialbasiertes
	# Wand-Tinting v10.20): fertig gebaute Gebaeude nutzen das
	# "Building"-Asset statt der generischen Box+Dach-Darstellung - fuer ALLE
	# Gebaeudetypen. Waehrend der Bauphase bleibt es bei der bisherigen
	# halbtransparenten Box (Baugeruest-Optik) - so bleibt der bekannte
	# "Baustelle"-Look fuer alle Gebaeudetypen einheitlich. Die Skalierung
	# richtet sich nach der individuellen Ziel-Hoehe "bh" des jeweiligen
	# Gebaeudes, damit z.B. ein Brunnen kleiner wirkt als ein Wohnhaus, auch
	# wenn beide dasselbe Modell nutzen.
	var use_building_model: bool = not b.is_under_construction

	if use_building_model:
		var model := BUILDING_SCENE.instantiate()
		var scale_factor: float = (bh / BUILDING_MODEL_RAW_HEIGHT) * BUILDING_MODEL_SCALE_FACTOR
		model.scale      = Vector3.ONE * scale_factor
		# Bug-Fix (v10.19, "Haeuser stehen im Boden"): Modell-Ursprung liegt in
		# der Mitte des Mesh, nicht am Boden - ohne diesen Offset wuerde die
		# untere Haelfte des Modells unter der Tile-Oberflaeche versinken.
		model.position.y = BUILDING_MODEL_BOTTOM_OFFSET * scale_factor
		model.rotation.y = BUILDING_ROT_OFFSET
		# v10.20: faerbt nur noch die "Wand"-Flaeche statt des gesamten
		# Modells (siehe _tint_building_wall()) - Dach, Fensterrahmen,
		# Schornstein, Sockel etc. behalten ihr Original-Aussehen.
		_tint_building_wall(model, col)
		root.add_child(model)
	else:
		var body_mi   := MeshInstance3D.new()
		var body_mesh := BoxMesh.new()
		body_mesh.size = Vector3(TILE_SIZE * 0.82, bh, TILE_SIZE * 0.82)
		body_mi.mesh   = body_mesh
		body_mi.position = Vector3(0.0, bh * 0.5, 0.0)

		var body_mat := StandardMaterial3D.new()
		if b.is_under_construction:
			body_mat.albedo_color = Color(0.90, 0.82, 0.42, 0.65)
			body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		else:
			body_mat.albedo_color = col
		body_mat.roughness = 0.72
		body_mi.material_override = body_mat
		root.add_child(body_mi)

		# ── Dach ──
		var roof_mi   := MeshInstance3D.new()
		var roof_mesh := BoxMesh.new()
		roof_mesh.size = Vector3(TILE_SIZE * 0.90, 0.22, TILE_SIZE * 0.90)
		roof_mi.mesh   = roof_mesh
		roof_mi.position = Vector3(0.0, bh + 0.11, 0.0)
		var roof_mat := StandardMaterial3D.new()
		roof_mat.albedo_color = col.darkened(0.32)
		roof_mat.roughness    = 0.80
		roof_mi.material_override = roof_mat
		if not b.is_under_construction:
			root.add_child(roof_mi)

	# ── Emoji-Label ──
	var lbl := Label3D.new()
	lbl.text       = BUILDING_EMOJIS.get(b.id, "🏠")
	lbl.pixel_size = 0.008
	lbl.font_size  = 60
	lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.no_depth_test = true
	lbl.position   = Vector3(0.0, bh + 0.9, 0.0)
	root.add_child(lbl)

	# ── Baustellen-Overlay ──
	if b.is_under_construction:
		var prog_lbl := Label3D.new()
		prog_lbl.text      = "🚧"
		prog_lbl.pixel_size = 0.008
		prog_lbl.font_size  = 48
		prog_lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
		prog_lbl.no_depth_test = true
		prog_lbl.position   = Vector3(0.0, bh + 1.7, 0.0)
		root.add_child(prog_lbl)

	# ── Lager-Fuellstandsanzeige (v11.0, Lagersystem) ──
	# Produktionsgebaeude haben ein begrenztes lokales Lager fuer die selbst
	# erzeugte Ressource (siehe BuildingEntity.local_storage) - hier wird der
	# Fuellstand direkt am Gebaeude als kleiner Balken aus Blockzeichen
	# angezeigt, der von refresh_storage_labels() periodisch aktualisiert
	# wird, ohne das Gebaeude komplett neu aufzubauen.
	if not b.is_under_construction and b.local_storage_capacity > 0.0:
		var store_lbl := Label3D.new()
		store_lbl.text       = "░░░░░"
		store_lbl.pixel_size = 0.0065
		store_lbl.font_size  = 38
		store_lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
		store_lbl.no_depth_test = true
		store_lbl.position   = Vector3(0.0, bh + 1.35, 0.0)
		root.add_child(store_lbl)
		_storage_labels[key] = store_lbl

	root.position = wp
	_building_root.add_child(root)
	_building_nodes[key] = root

## Feature (v11.0): aktualisiert den Lager-Fuellstandsbalken aller
## Produktionsgebaeude (gruene → rote Faerbung je naeher am Limit), ohne die
## Gebaeude-Nodes selbst neu aufzubauen - regelmaessig (nicht jeden Frame)
## von GameController._process() aufgerufen.
func refresh_storage_labels(buildings: Array) -> void:
	for b in buildings:
		var be: BuildingEntity = b
		if be.is_under_construction or be.local_storage_capacity <= 0.0: continue
		var key: String = "%d,%d" % [be.tile_x, be.tile_y]
		if not _storage_labels.has(key): continue
		var lbl: Label3D = _storage_labels[key] as Label3D
		if lbl == null or not is_instance_valid(lbl): continue
		var pct: float = clampf(be.get_local_storage_total() / maxf(1.0, be.local_storage_capacity), 0.0, 1.0)
		var bars: int = int(round(pct * 5.0))
		var bar_str: String = ""
		for i in range(5):
			bar_str += "▓" if i < bars else "░"
		lbl.text = bar_str
		lbl.modulate = Color(0.30, 0.85, 0.30).lerp(Color(0.92, 0.18, 0.12), pct)

# ══════════════════════════════════════════════════════════════════════════════
# SELEKTION / GHOST
# ══════════════════════════════════════════════════════════════════════════════
func _create_highlight() -> void:
	_sel_mat = StandardMaterial3D.new()
	_sel_mat.albedo_color     = Color(1.0, 0.92, 0.18, 0.70)
	_sel_mat.transparency     = BaseMaterial3D.TRANSPARENCY_ALPHA
	_sel_mat.emission_enabled = true
	_sel_mat.emission         = Color(1.0, 0.85, 0.0) * 0.4
	_sel_mat.cull_mode        = BaseMaterial3D.CULL_DISABLED

	_highlight_node = MeshInstance3D.new()
	_highlight_node.name = "SelectHighlight"
	var m := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.97, 0.06, TILE_SIZE * 0.97)
	_highlight_node.mesh              = m
	_highlight_node.material_override = _sel_mat
	_highlight_node.visible           = false
	_highlight_node.cast_shadow       = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_highlight_node)

func _create_ghost() -> void:
	_ghost_mat = StandardMaterial3D.new()
	_ghost_mat.albedo_color = Color(0.45, 0.80, 1.0, 0.42)
	_ghost_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ghost_mat.cull_mode    = BaseMaterial3D.CULL_DISABLED

	_ghost_node = MeshInstance3D.new()
	_ghost_node.name = "Ghost"
	var m := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.82, 2.0, TILE_SIZE * 0.82)
	_ghost_node.mesh              = m
	_ghost_node.material_override = _ghost_mat
	_ghost_node.visible           = false
	_ghost_node.cast_shadow       = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_ghost_node)

## Feature (v11.1, Logistik-Feinschliff): legt den einmaligen Node fuer alle
## Hauler-Linien an. Unlit/no_depth_test, damit die duennen Linien auch durch
## Gebaeude/Terrain hindurch klar sichtbar bleiben.
func _create_haul_lines() -> void:
	_haul_line_mesh = ImmediateMesh.new()
	_haul_line_node = MeshInstance3D.new()
	_haul_line_node.name = "HaulLines"
	_haul_line_node.mesh = _haul_line_mesh
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.no_depth_test = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_haul_line_node.material_override = mat
	_haul_line_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_haul_line_node)

## Feature (v11.1, Logistik-Feinschliff): zeichnet fuer jedes Frettchen, das
## gerade aktiv Material transportiert (Selbst-Abtransport, Bau-Frettchen auf
## Materialsuche, Lagerarbeiter), eine duenne Linie von seiner aktuellen
## Position zum Transportziel - macht das Logistiknetzwerk auf einen Blick
## sichtbar. Farbcodiert nach Transportart:
##   gelb   = Produktions-Hauler traegt zum Lagerhaus (HAUL_TO_WAREHOUSE)
##   blau   = Bau-Frettchen holt Material vom Lagerhaus (FETCH_TO_WAREHOUSE)
##   gruen  = Material wird gerade zur Baustelle gebracht (FETCH_TO_SITE/WH_TO_SITE)
##   lila   = Lagerarbeiter holt von einem Produktionsgebaeude ab (WH_TO_SOURCE)
const _HAUL_LINE_COLORS: Dictionary = {
	"HAUL_TO_WAREHOUSE":   Color(1.0, 0.85, 0.15, 0.85),
	"FETCH_TO_WAREHOUSE":  Color(0.25, 0.55, 1.0, 0.85),
	"FETCH_TO_SITE":       Color(0.30, 0.90, 0.35, 0.85),
	"WH_TO_SOURCE":        Color(0.75, 0.35, 0.95, 0.85),
	"WH_TO_SITE":          Color(0.30, 0.90, 0.35, 0.85),
}
func refresh_haul_lines(ferrets: Array) -> void:
	if _haul_line_mesh == null: return
	_haul_line_mesh.clear_surfaces()
	# Bug-Fix (v11.2b-Hotfix): surface_end() wirft einen Fehler ("No vertices
	# were added"), wenn kein einziges Frettchen gerade transportiert - also
	# zuerst pruefen, ob ueberhaupt ein aktiver Haul-Transport vorliegt, und
	# nur dann eine Surface eroeffnen.
	var has_lines: bool = false
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.haul_target != null and is_instance_valid(fe.haul_target) \
				and _HAUL_LINE_COLORS.has(fe.work_state):
			has_lines = true; break
	if not has_lines: return
	_haul_line_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.haul_target == null or not is_instance_valid(fe.haul_target): continue
		var col = _HAUL_LINE_COLORS.get(fe.work_state, null)
		if col == null: continue
		var target: BuildingEntity = fe.haul_target
		var from_wp: Vector3 = tile_to_world3d(int(fe.pos.x), int(fe.pos.y))
		from_wp.y += 0.6
		var to_wp: Vector3 = tile_to_world3d(target.tile_x, target.tile_y)
		to_wp.y += 0.6
		_haul_line_mesh.surface_set_color(col as Color)
		_haul_line_mesh.surface_add_vertex(from_wp)
		_haul_line_mesh.surface_set_color(col as Color)
		_haul_line_mesh.surface_add_vertex(to_wp)
	_haul_line_mesh.surface_end()

## Feature (v11.1, Logistik-Feinschliff): legt den Node fuer die statische
## Lieferketten-Vorschau an (gestrichelt wirkende, gedimmte Linien - durch
## kuerzere, durch Luecken getrennte Liniensegmente simuliert, da ImmediateMesh
## kein echtes Dash-Pattern unterstuetzt).
func _create_chain_lines() -> void:
	_chain_line_mesh = ImmediateMesh.new()
	_chain_line_node = MeshInstance3D.new()
	_chain_line_node.name = "ChainLines"
	_chain_line_node.mesh = _chain_line_mesh
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.no_depth_test = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_chain_line_node.material_override = mat
	_chain_line_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_chain_line_node)

func clear_chain_lines() -> void:
	if _chain_line_mesh: _chain_line_mesh.clear_surfaces()

## Feature (v11.1, Logistik-Feinschliff): zeigt beim Anklicken eines Gebaeudes
## dessen potenzielle Lieferkette, unabhaengig davon, ob gerade aktiv
## transportiert wird:
##  - Produktionsgebaeude → naechstes (nach storage_filter passendes) Lagerhaus
##  - Lagerhaus → alle Produktionsgebaeude in Reichweite, die es bedienen
##    koennte, UND alle Baustellen in Reichweite, die noch Material brauchen
##  - Baustelle → naechstes Lagerhaus mit verfuegbarem fehlendem Material
func refresh_chain_lines(b: BuildingEntity) -> void:
	clear_chain_lines()
	if b == null or _chain_line_mesh == null: return
	var lines: Array = []  # Array of [Vector3 from, Vector3 to, Color]
	var dim_warehouse := Color(1.0, 0.85, 0.15, 0.55)
	var dim_source    := Color(0.75, 0.35, 0.95, 0.45)
	var dim_site      := Color(0.30, 0.90, 0.35, 0.55)
	var b_wp: Vector3 = tile_to_world3d(b.tile_x, b.tile_y); b_wp.y += 0.55

	if b.local_storage_capacity > 0.0:
		# Produktionsgebaeude: Linie zum naechsten passenden Lagerhaus.
		var best_wh: BuildingEntity = null; var best_d: float = INF
		for ob in BuildingSys.buildings:
			var obe: BuildingEntity = ob
			if obe.btype != "STORAGE" or obe.is_under_construction or obe.storage_capacity <= 0.0: continue
			var d: float = Vector2(float(b.tile_x), float(b.tile_y)).distance_to(Vector2(float(obe.tile_x), float(obe.tile_y)))
			if d < best_d: best_d = d; best_wh = obe
		if best_wh != null:
			var wh_wp: Vector3 = tile_to_world3d(best_wh.tile_x, best_wh.tile_y); wh_wp.y += 0.55
			lines.append([b_wp, wh_wp, dim_warehouse])
	elif b.btype == "STORAGE" and b.storage_capacity > 0.0:
		# Lagerhaus: Linien zu potenziellen Quellen und zu Baustellen, die es
		# bedienen koennte.
		for ob in BuildingSys.buildings:
			var obe: BuildingEntity = ob
			if obe.is_under_construction or obe.local_storage_capacity <= 0.0: continue
			var d: float = Vector2(float(b.tile_x), float(b.tile_y)).distance_to(Vector2(float(obe.tile_x), float(obe.tile_y)))
			if d > 70.0: continue
			var src_wp: Vector3 = tile_to_world3d(obe.tile_x, obe.tile_y); src_wp.y += 0.55
			lines.append([src_wp, b_wp, dim_source])
		for site in BuildingSys.get_construction_sites():
			var se: BuildingEntity = site
			if se.is_fully_supplied(): continue
			var d2: float = Vector2(float(b.tile_x), float(b.tile_y)).distance_to(Vector2(float(se.tile_x), float(se.tile_y)))
			if d2 > 70.0: continue
			var site_wp: Vector3 = tile_to_world3d(se.tile_x, se.tile_y); site_wp.y += 0.55
			lines.append([b_wp, site_wp, dim_site])
	elif b.is_under_construction:
		# Baustelle: Linie zum naechsten Lagerhaus mit verfuegbarem Material.
		var best_wh2: BuildingEntity = null; var best_d2: float = INF
		for ob in BuildingSys.buildings:
			var obe2: BuildingEntity = ob
			if obe2.btype != "STORAGE" or obe2.is_under_construction or obe2.storage_capacity <= 0.0: continue
			var d3: float = Vector2(float(b.tile_x), float(b.tile_y)).distance_to(Vector2(float(obe2.tile_x), float(obe2.tile_y)))
			if d3 < best_d2: best_d2 = d3; best_wh2 = obe2
		if best_wh2 != null:
			var wh_wp2: Vector3 = tile_to_world3d(best_wh2.tile_x, best_wh2.tile_y); wh_wp2.y += 0.55
			lines.append([wh_wp2, b_wp, dim_site])

	if lines.is_empty(): return
	_chain_line_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	for line in lines:
		var ld: Array = line
		_chain_line_mesh.surface_set_color(ld[2] as Color)
		_chain_line_mesh.surface_add_vertex(ld[0] as Vector3)
		_chain_line_mesh.surface_set_color(ld[2] as Color)
		_chain_line_mesh.surface_add_vertex(ld[1] as Vector3)
	_chain_line_mesh.surface_end()

func set_selection(tx: int, ty: int) -> void:
	selected_tile = Vector2i(tx, ty)
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h:
		_highlight_node.visible = false
		return
	var wp := tile_to_world3d(tx, ty)
	_highlight_node.position = Vector3(wp.x, wp.y + 0.07, wp.z)
	_highlight_node.visible  = true

func clear_selection() -> void:
	selected_tile     = Vector2i(-1, -1)
	selected_building = null
	_highlight_node.visible = false
	clear_chain_lines()

func update_ghost(tx: int, ty: int, building_id: String) -> void:
	if tx < 0 or ty < 0 or tx >= world_w or ty >= world_h or building_id.is_empty():
		_ghost_node.visible = false
		return
	var wp:  Vector3 = tile_to_world3d(tx, ty)
	var vis: Dictionary = BUILDING_VISUALS.get(
		building_id, {"color": Color(0.5, 0.8, 1.0), "h": 2.0}
	) as Dictionary
	var bh: float = float(vis.get("h", 2.0))
	var m  := BoxMesh.new()
	m.size = Vector3(TILE_SIZE * 0.82, bh, TILE_SIZE * 0.82)
	_ghost_node.mesh     = m
	_ghost_node.position = Vector3(wp.x, wp.y + bh * 0.5, wp.z)
	_ghost_node.visible  = true

func clear_ghost() -> void:
	_ghost_node.visible = false

# ══════════════════════════════════════════════════════════════════════════════
# FRETTCHEN
# ══════════════════════════════════════════════════════════════════════════════
func update_ferrets(ferrets: Array) -> void:
	# Prüfen ob genug Nodes vorhanden, sonst neu erstellen
	while _ferret_nodes.size() < ferrets.size():
		var inst := FERRET_SCENE.instantiate() as Node3D
		inst.scale = Vector3.ONE * FERRET_MODEL_SCALE
		_disable_shadows(inst)
		var anim: AnimationPlayer = inst.find_child("AnimationPlayer", true, false) as AnimationPlayer
		if anim and anim.get_animation_list().size() > 0:
			var anim_name: String = "Run" if anim.has_animation("Run") else anim.get_animation_list()[0]
			anim.play(anim_name)
			anim.speed_scale = randf_range(0.85, 1.2)
			inst.set_meta("anim_player", anim)
			inst.set_meta("anim_name", anim_name)
			inst.set_meta("anim_base_speed", anim.speed_scale)
		_ferret_root.add_child(inst)
		_ferret_nodes.append(inst)

	# Überschüssige Nodes verstecken
	for i in _ferret_nodes.size():
		var fn: Node3D = _ferret_nodes[i] as Node3D
		if i >= ferrets.size():
			fn.visible = false
			continue
		fn.visible = true
		var fe: FerretEntity = ferrets[i] as FerretEntity
		# pos ist jetzt Tile-Koordinaten (Floats)
		var ftx: int = clampi(int(fe.pos.x), 0, world_w - 1)
		var fty: int = clampi(int(fe.pos.y), 0, world_h - 1)
		var wp3: Vector3 = tile_to_world3d(ftx, fty)
		# Sub-Tile-Offset
		var sub_x: float = (fe.pos.x - float(ftx)) * TILE_SIZE
		var sub_z: float = (fe.pos.y - float(fty)) * TILE_SIZE
		var is_harvesting: bool = fe.work_state == "HARVESTING"
		var is_building: bool = fe.work_state == "BUILDING"
		var is_idle_at_work: bool = fe.work_state == "WORKING" or is_harvesting or is_building

		# Feature (v10.13): nachts legen sich Frettchen schlafen (siehe
		# FerretEntity._update_sleep()) - mit zugewiesenem Haus dort, sonst an
		# Ort und Stelle auf dem Boden. Das ferret.glb hat keine Liege-Pose,
		# daher wird das Modell stattdessen um 90° auf die Seite gekippt und
		# dicht auf den Boden gesetzt; ein sehr langsames Sinus-Wippen
		# deutet ruhiges Atmen an. Die Lauf-Animation wird dabei komplett
		# angehalten (eingefrorene Pose, siehe v10.12-Fix weiter unten).
		if fe.is_sleeping:
			var anim_s: AnimationPlayer = fn.get_meta("anim_player", null) as AnimationPlayer
			if anim_s != null and anim_s.is_playing():
				anim_s.stop(true)
			var breathe: float = sin(fe.sleep_anim_t * 1.1) * 0.015
			fn.rotation.x = 0.0
			fn.rotation.z = deg_to_rad(92.0)
			fn.position = Vector3(wp3.x + sub_x, wp3.y + FERRET_Y * 0.32 + breathe, wp3.z + sub_z)
			continue

		# Feature (v10.10/v10.11): das ferret.glb hat nur eine "Run"-Animation
		# (siehe Projektnotizen), keine eigene Ernte-/Arbeitsanimation. Als
		# Ersatz: die Lauf-Animation wird angehalten, sobald das Frettchen am
		# Gebaeude/an der Quelle steht (kein Laufen auf der Stelle mehr), und
		# waehrend des Erntens/Arbeitens wird stattdessen eine kleine,
		# prozedurale Pose simuliert - seit v10.11 je nach gesammelter
		# Ressource ein eigenes, passendes Bewegungsmuster (siehe
		# rendering/animations/): Pflücken (BERRIES), Axthieb (WOOD), Schöpfen
		# (WATER). Für STONE/IRON gibt es noch kein eigenes Modul, dafür
		# bleibt das generische Sinus-Wippen als Fallback erhalten.
		var bob_y: float = 0.0
		var rot_x: float = 0.0
		var rot_z: float = 0.0
		var ab_res: String = ""
		if fe.assigned_building != null:
			ab_res = (fe.assigned_building as BuildingEntity).collects_resource

		if is_harvesting:
			match ab_res:
				"BERRIES":
					var pose: Dictionary = BerryHarvestAnimation.compute(fe.harvest_anim_t, FerretEntity.HARVEST_DURATION)
					bob_y = pose.bob_y; rot_x = pose.rot_x; rot_z = pose.rot_z
				"WOOD":
					var pose2: Dictionary = TreeFellingAnimation.compute(fe.harvest_anim_t, FerretEntity.HARVEST_DURATION)
					bob_y = pose2.bob_y; rot_x = pose2.rot_x; rot_z = pose2.rot_z
				_:
					# STONE/IRON (noch kein eigenes Modul) - generisches Wippen
					bob_y = absf(sin(fe.harvest_anim_t * 6.0)) * 0.12
					rot_x = sin(fe.harvest_anim_t * 6.0) * 0.18
		elif fe.work_state == "WORKING" and ab_res == "WATER":
			var pose3: Dictionary = WaterCollectAnimation.compute(fe.work_anim_t, FerretEntity.HARVEST_DURATION)
			bob_y = pose3.bob_y; rot_x = pose3.rot_x; rot_z = pose3.rot_z
		elif is_building:
			# Feature (v10.13): kleines, schnelles Hammer-Wippen fuer
			# Bau-Frettchen, die gerade physisch an einer Baustelle stehen
			# (work_state == "BUILDING", siehe FerretEntity._update_builder_work()).
			bob_y = absf(sin(fe.work_anim_t * 7.0)) * 0.08
			rot_x = sin(fe.work_anim_t * 7.0) * 0.22

		var anim: AnimationPlayer = fn.get_meta("anim_player", null) as AnimationPlayer
		if anim != null:
			if is_idle_at_work:
				# Bug-Fix (v10.12): AnimationPlayer hat in Godot 4 keine
				# pause()/is_paused()-Methoden (Engine-Fehler "Nonexistent
				# function 'is_paused'"). stop(true) haelt die Wiedergabe an
				# UND friert die aktuell animierte Pose ein (kein Zuruecksetzen
				# auf die Standard-Pose) - das ist das Godot-4-Äquivalent zu
				# "pausieren" für AnimationPlayer.
				if anim.is_playing():
					anim.stop(true)
			else:
				if not anim.is_playing():
					anim.play(str(fn.get_meta("anim_name", "Run")))
					anim.speed_scale = float(fn.get_meta("anim_base_speed", 1.0))
		fn.rotation.x = rot_x
		fn.rotation.z = rot_z

		fn.position = Vector3(wp3.x + sub_x, wp3.y + FERRET_Y + bob_y, wp3.z + sub_z)
		var dir: Vector2 = fe.target_pos - fe.pos
		if dir.length() > 0.05 and not is_idle_at_work:
			fn.rotation.y = atan2(dir.x, dir.y) + FERRET_ROT_OFFSET

## Schaltet Schatten für ein importiertes Modell (und alle Kind-Meshes) aus,
## da viele kleine Frettchen-Modelle sonst unnötig Rendering-Last erzeugen.
func _disable_shadows(n: Node) -> void:
	if n is GeometryInstance3D:
		(n as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for c in n.get_children():
		_disable_shadows(c)

func _clear_ferrets() -> void:
	for n in _ferret_nodes:
		if is_instance_valid(n): (n as Node).queue_free()
	_ferret_nodes.clear()

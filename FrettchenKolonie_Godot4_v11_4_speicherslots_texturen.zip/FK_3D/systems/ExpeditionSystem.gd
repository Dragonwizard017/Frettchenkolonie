## ExpeditionSystem.gd
extends Node

class Expedition extends RefCounted:
	var ferrets: Array = []
	var days_total: float = 0.0
	var days_elapsed: float = 0.0
	var exp_name: String = ""

	func update(dt: float) -> bool:
		days_elapsed += dt / 60.0
		return days_elapsed >= days_total

	func get_rewards() -> Dictionary:
		var diff: float = days_total / 12.0
		var r: Dictionary = {}
		r["WOOD"] = randi_range(5, 20)
		r["STONE"] = randi_range(3, 15)
		r["BERRIES"] = randi_range(5, 25)
		if diff > 0.4:
			r["TOOLS"] = randi_range(0, 3)
			r["IRON"] = randi_range(0, 8)
		if diff > 0.7:
			r["IRON_BARS"] = randi_range(0, 3)
			r["COAL"] = randi_range(0, 5)
		return r

	# Bug-Fix (v10.14): "Expeditionen werden nicht gespeichert" - bisher gab
	# es fuer eine einzelne Expedition gar keine Serialisierung, und die
	# mitgereisten Frettchen (die zu diesem Zeitpunkt NICHT mehr in
	# PopMgr.ferrets stehen, siehe send()) waeren beim Speichern schlicht
	# verschwunden.
	func serialize() -> Dictionary:
		var f_data: Array = []
		for f in ferrets:
			f_data.append((f as FerretEntity).serialize())
		return {
			"exp_name": exp_name, "days_total": days_total,
			"days_elapsed": days_elapsed, "ferrets": f_data
		}

	static func deserialize(data: Dictionary) -> Expedition:
		var e := Expedition.new()
		e.exp_name = str(data.get("exp_name", "Expedition"))
		e.days_total = float(data.get("days_total", 5.0))
		e.days_elapsed = float(data.get("days_elapsed", 0.0))
		for fd in (data.get("ferrets", []) as Array):
			e.ferrets.append(FerretEntity.deserialize(fd as Dictionary))
		return e

var active_expeditions: Array = []

func init() -> void:
	active_expeditions = []

func can_send() -> bool:
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if be.btype == "EXPEDITION" and not be.is_under_construction:
			return true
	return false

func send(ferret_count: int, days: float) -> bool:
	if not can_send(): return false
	if PopMgr.get_count() < ferret_count + 2:
		GameState.notify("Nicht genug Frettchen!"); return false
	if not ResourceSys.has("TOOLS", 2):
		GameState.notify("Brauche 2 Werkzeuge fuer Expedition!"); return false
	ResourceSys.remove("TOOLS", 2)
	var expd := Expedition.new()
	expd.days_total = days
	expd.exp_name = "Expedition %d" % (active_expeditions.size() + 1)
	for _i in ferret_count:
		if PopMgr.ferrets.is_empty(): break
		var f: FerretEntity = PopMgr.ferrets.pop_back()
		if f.assigned_building != null:
			var ab: BuildingEntity = f.assigned_building
			ab.remove_worker(f)
		expd.ferrets.append(f)
	active_expeditions.append(expd)
	GameState.notify("%s gestartet! (%d Frettchen, %d Tage)" % [expd.exp_name, ferret_count, int(days)])
	return true

func update(dt: float) -> void:
	var returned: Array = []
	for expd in active_expeditions:
		var e: Expedition = expd
		if e.update(dt): returned.append(e)
	for expd in returned:
		active_expeditions.erase(expd)
		_finish_expedition(expd as Expedition)

func _finish_expedition(expd: Expedition) -> void:
	for f in expd.ferrets:
		PopMgr.ferrets.append(f)
	var rewards: Dictionary = expd.get_rewards()
	for res in rewards:
		ResourceSys.force_add(str(res), float(rewards[res]))
	GameState.expedition_returned.emit(rewards)
	GameState.notify("%s zurueck! Beute erhalten!" % expd.exp_name)
	GameState.hud_update_requested.emit()

func serialize() -> Array:
	var result: Array = []
	for expd in active_expeditions:
		var e: Expedition = expd
		result.append(e.serialize())
	return result

func deserialize(data: Array) -> void:
	# Bug-Fix (v10.14): bisher hat deserialize() den Parameter komplett
	# ignoriert und IMMER auf eine leere Liste zurueckgesetzt - laufende
	# Expeditionen (inkl. der Frettchen darin) gingen beim Laden verloren.
	# Jetzt werden sie inklusive ihrer Frettchen wiederhergestellt; diese
	# Frettchen duerfen NICHT zusaetzlich in PopMgr.ferrets auftauchen (sie
	# waren beim Speichern bereits dort entfernt, siehe send()).
	active_expeditions = []
	for ed in data:
		active_expeditions.append(Expedition.deserialize(ed as Dictionary))

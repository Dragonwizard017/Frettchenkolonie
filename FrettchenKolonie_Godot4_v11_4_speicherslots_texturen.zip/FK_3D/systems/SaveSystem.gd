## SaveSystem.gd
extends Node

const SAVE_DIR: String = "user://saves/"

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)

func get_save_names() -> Array:
	var names: Array = []
	var dir: DirAccess = DirAccess.open(SAVE_DIR)
	if dir == null: return names
	dir.list_dir_begin()
	var fname: String = dir.get_next()
	while fname != "":
		if fname.ends_with(".json"):
			names.append(fname.get_basename())
		fname = dir.get_next()
	return names

## Feature (v11.4, Speicherslot-System): jeder Slot traegt jetzt kompakte
## Kolonie-Metadaten (Name, Seed, Tag, Jahreszeit, Bevoelkerung, Weltgroesse)
## direkt auf oberster Ebene, damit die Welt-Auswahl-Liste (get_save_info)
## diese Werte lesen kann, ohne den kompletten Speicherstand zu deserialisieren.
func save(slot_name: String, game_ctrl: Node) -> bool:
	var meta: Dictionary = {}
	if game_ctrl.has_method("get_save_metadata"):
		meta = game_ctrl.call("get_save_metadata") as Dictionary
	var data: Dictionary = {
		"version": 6,
		"slot": slot_name,
		"colony_name": str(meta.get("colony_name", slot_name)),
		"seed": int(meta.get("seed", 0)),
		"day_count": int(meta.get("day_count", 0)),
		"season_name": str(meta.get("season_name", "")),
		"season_icon": str(meta.get("season_icon", "")),
		"population_count": int(meta.get("population_count", 0)),
		"world_w": int(meta.get("world_w", 0)),
		"world_h": int(meta.get("world_h", 0)),
		"timestamp": Time.get_datetime_string_from_system(),
		"world": game_ctrl.serialize_world(),
		"resources": ResourceSys.serialize(),
		"buildings": BuildingSys.serialize(),
		"population": PopMgr.serialize(),
		"day_night": DayNight.serialize(),
		"tech": TechTreeSys.serialize(),
		"drought": DroughtSys.serialize(),
		"season": SeasonSys.serialize(),
		# Bug-Fix (v10.14): "Expeditionen werden nicht gespeichert" - bisher
		# fehlte dieser Eintrag komplett, laufende Expeditionen (inkl. der
		# mitgereisten Frettchen) gingen beim Speichern/Laden verloren.
		"expeditions": ExpeditionSys.serialize()
	}
	var path: String = SAVE_DIR + slot_name + ".json"
	var file: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("SaveSystem: Cannot open file " + path)
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	GameState.notify("Gespeichert: " + slot_name)
	return true

func load_game(slot_name: String, game_ctrl: Node) -> bool:
	var path: String = SAVE_DIR + slot_name + ".json"
	if not FileAccess.file_exists(path):
		GameState.notify("Speicherstand nicht gefunden: " + slot_name, Color(0.8, 0.2, 0.1))
		return false
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null: return false
	var json_str: String = file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(json_str)
	if parsed == null: return false
	var data: Dictionary = parsed as Dictionary
	game_ctrl.deserialize_world(data.get("world", {}) as Dictionary)
	ResourceSys.deserialize(data.get("resources", {}) as Dictionary)
	BuildingSys.deserialize(data.get("buildings", []) as Array, game_ctrl.world)
	PopMgr.deserialize(data.get("population", {}) as Dictionary)
	DayNight.deserialize(data.get("day_night", {}) as Dictionary)
	TechTreeSys.deserialize(data.get("tech", []) as Array)
	DroughtSys.deserialize(data.get("drought", {}) as Dictionary)
	SeasonSys.deserialize(data.get("season", {}) as Dictionary)
	ExpeditionSys.deserialize(data.get("expeditions", []) as Array)
	# Feature (v11.4, Speicherslot-System): aktuellen Slot + Kolonie-Namen im
	# GameController merken, damit "Speichern" im Pause-Menue automatisch
	# wieder in denselben, benannten Slot schreibt statt in einen festen
	# "quicksave"-Slot.
	game_ctrl.current_save_slot = slot_name
	game_ctrl.current_world_name = str(data.get("colony_name", slot_name))
	# Bug 5-Fix: Gebäude wurden nach deserialize_world in die Tiles geschrieben –
	# Renderer muss jetzt nochmals die Building-Nodes erzeugen.
	if game_ctrl.has_method("post_load_refresh"):
		game_ctrl.call("post_load_refresh")
	GameState.notify("Geladen: " + str(data.get("colony_name", slot_name)))
	return true

## Feature (v11.4, Speicherslot-System): liest nur die kompakten Metadaten
## eines Speicherstands (fuer die Welt-Auswahl-Liste), ohne Welt/Gebaeude/
## Bevoelkerung vollstaendig zu deserialisieren - schnell auch bei vielen Slots.
func get_save_info(slot_name: String) -> Dictionary:
	var path: String = SAVE_DIR + slot_name + ".json"
	if not FileAccess.file_exists(path): return {}
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null: return {}
	var json_str: String = file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(json_str)
	if parsed == null: return {}
	var data: Dictionary = parsed as Dictionary
	return {
		"slot": slot_name,
		"colony_name": str(data.get("colony_name", slot_name)),
		"seed": int(data.get("seed", 0)),
		"day_count": int(data.get("day_count", 0)),
		"season_name": str(data.get("season_name", "")),
		"season_icon": str(data.get("season_icon", "")),
		"population": int(data.get("population_count", 0)),
		"world_w": int(data.get("world_w", 0)),
		"world_h": int(data.get("world_h", 0)),
		"timestamp": str(data.get("timestamp", "")),
	}

## Feature (v11.4, Speicherslot-System): loescht einen benannten Speicherstand
## unwiderruflich (genutzt von der Welt-Auswahl-Liste im "Loeschen"-Button).
func delete_save(slot_name: String) -> bool:
	var dir: DirAccess = DirAccess.open(SAVE_DIR)
	if dir == null: return false
	var fname: String = slot_name + ".json"
	if not dir.file_exists(fname): return false
	var err: int = dir.remove(fname)
	if err == OK:
		GameState.notify("Speicherstand geloescht: " + slot_name)
		return true
	return false

## SoundSystem.gd
## Prozedurales Audio. Verwendet AudioStreamGeneratorPlayback
## statt neue WAV-Objekte zu erzeugen (verhindert den FMallocBinned2 Crash).
extends Node

var master_vol: float = 0.8
var sfx_vol: float    = 0.7
var music_vol: float  = 0.6

var _music_active:   bool  = false
var _music_beat:     int   = 0
var _music_timer:    float = 0.0
var _music_interval: float = 0.60

const POOL_SIZE := 8
const MIX_RATE  := 22050
const BUF_SIZE  := 1024  # Samples per generator buffer chunk

var _sfx_pool:   Array = []  # Array[AudioStreamPlayer]  – Generator-basiert
var _music_pool: Array = []
var _sfx_idx:    int   = 0
var _music_idx:  int   = 0

# Wir speichern pro Player eine laufende Sinus-Phase und den Rest-Samplelcount
var _sfx_state:   Array = []  # [{freq, phase, vol, remaining}]
var _music_state: Array = []

func _ready() -> void:
	for i in POOL_SIZE:
		var p := _make_gen_player(false)
		_sfx_pool.append(p)
		_sfx_state.append({"freq": 0.0, "phase": 0.0, "vol": 0.0, "rem": 0})
	for i in 2:
		var p := _make_gen_player(true)
		_music_pool.append(p)
		_music_state.append({"freq": 0.0, "phase": 0.0, "vol": 0.0, "rem": 0})

func _make_gen_player(is_music: bool) -> AudioStreamPlayer:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = float(MIX_RATE)
	gen.buffer_length = 0.15 if is_music else 0.10
	var p := AudioStreamPlayer.new()
	p.stream = gen
	p.volume_db = -6.0
	add_child(p)
	p.play()
	return p

func _process(dt: float) -> void:
	# SFX-Pool befüllen
	for i in POOL_SIZE:
		var st: Dictionary = _sfx_state[i]
		if int(st["rem"]) <= 0: continue
		var p: AudioStreamPlayer = _sfx_pool[i]
		var pb = p.get_stream_playback()
		if pb == null: continue
		var to_fill: int = mini(pb.get_frames_available(), mini(int(st["rem"]), BUF_SIZE))
		var frame := Vector2.ZERO
		for _s in to_fill:
			var t: float = float(st["phase"]) / float(MIX_RATE)
			var env: float = clampf(float(st["rem"]) / float(MIX_RATE) * 6.0, 0.0, 1.0)
			var s: float = sin(TAU * float(st["freq"]) * t) * float(st["vol"]) * env
			frame = Vector2(s, s)
			pb.push_frame(frame)
			st["phase"] = int(st["phase"]) + 1
			st["rem"] = int(st["rem"]) - 1

	# Musik-Pool befüllen
	if _music_active:
		for i in 2:
			var st: Dictionary = _music_state[i]
			if int(st["rem"]) <= 0: continue
			var p: AudioStreamPlayer = _music_pool[i]
			var pb = p.get_stream_playback()
			if pb == null: continue
			var to_fill: int = mini(pb.get_frames_available(), mini(int(st["rem"]), BUF_SIZE))
			for _s in to_fill:
				var t: float = float(st["phase"]) / float(MIX_RATE)
				var env: float = clampf(float(st["rem"]) / float(MIX_RATE) * 4.0, 0.0, 1.0)
				var s: float = sin(TAU * float(st["freq"]) * t) * float(st["vol"]) * env
				pb.push_frame(Vector2(s, s))
				st["phase"] = int(st["phase"]) + 1
				st["rem"] = int(st["rem"]) - 1

	# Musik-Takt
	if _music_active:
		_music_timer += dt
		if _music_timer >= _music_interval:
			_music_timer -= _music_interval
			_play_music_bar(_music_beat)
			_music_beat += 1

func _tone(freq: float, duration: float, vol: float) -> void:
	var actual: float = vol * master_vol * sfx_vol
	if actual < 0.001: return
	var idx: int = _sfx_idx % POOL_SIZE
	_sfx_idx += 1
	_sfx_state[idx]["freq"] = freq
	_sfx_state[idx]["phase"] = 0
	_sfx_state[idx]["vol"] = actual
	_sfx_state[idx]["rem"] = int(duration * MIX_RATE)

func _music_tone(freq: float, duration: float, vol: float) -> void:
	var actual: float = vol * master_vol * music_vol
	if actual < 0.001: return
	var idx: int = _music_idx % 2
	_music_idx += 1
	_music_state[idx]["freq"] = freq
	_music_state[idx]["phase"] = 0
	_music_state[idx]["vol"] = actual
	_music_state[idx]["rem"] = int(duration * MIX_RATE)

# ── Musik ─────────────────────────────────────────────────────────────────────
func start_music() -> void: _music_active = true; _music_beat = 0; _music_timer = 0.0
func stop_music()  -> void: _music_active = false

func _play_music_bar(beat: int) -> void:
	var penta: Array = [294.0,330.0,370.0,440.0,494.0,587.0,659.0,740.0]
	var melody: Array = [0,2,4,2,5,4,2,0,3,5,4,2,1,3,5,7]
	var b: int = beat % melody.size()
	_music_tone(float(penta[int(melody[b])]), 0.55, music_vol * 0.12)
	if b % 4 == 0:
		_music_tone(float(penta[int(melody[b])]) * 0.5, 1.6, music_vol * 0.07)

# ── Soundeffekte ──────────────────────────────────────────────────────────────
func play_build() -> void:
	_tone(440.0, 0.14, sfx_vol * 0.15)
	_tone(554.0, 0.18, sfx_vol * 0.12)
	_tone(659.0, 0.24, sfx_vol * 0.10)

func play_explosion() -> void:
	# Weißes Rauschen via mehrere verstimmte Sinusse
	for i in 6:
		_tone(randf_range(80.0, 320.0), 0.55, sfx_vol * 0.18)

func play_notify() -> void:
	_tone(880.0,  0.10, sfx_vol * 0.18)
	_tone(1108.0, 0.14, sfx_vol * 0.14)

func play_born() -> void:
	for pair in [[523.0,0.14],[659.0,0.14],[784.0,0.14],[1046.0,0.18]]:
		_tone(float((pair as Array)[0]), float((pair as Array)[1]), sfx_vol * 0.18)

func play_death() -> void:
	for pair in [[440.0,0.20],[370.0,0.22],[311.0,0.24],[262.0,0.28]]:
		_tone(float((pair as Array)[0]), float((pair as Array)[1]), sfx_vol * 0.14)

func play_day()   -> void:
	for freq in [523.0, 659.0, 784.0]: _tone(float(freq), 0.30, sfx_vol * 0.11)

func play_night() -> void:
	for freq in [392.0, 330.0, 262.0]: _tone(float(freq), 0.38, sfx_vol * 0.09)

func set_volumes(master: float, music: float, sfx: float) -> void:
	master_vol = clampf(master / 100.0, 0.0, 1.0)
	music_vol  = clampf(music  / 100.0, 0.0, 1.0)
	sfx_vol    = clampf(sfx   / 100.0, 0.0, 1.0)

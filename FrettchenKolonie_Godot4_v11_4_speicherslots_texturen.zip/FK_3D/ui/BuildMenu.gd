## BuildMenu.gd
extends Control

var _container: VBoxContainer = null
var _epoch_btn: Button = null
var _collapsed: bool = false

func _ready() -> void:
	_container  = get_node_or_null("Outer/ScrollContainer/VBoxContainer")
	_epoch_btn  = get_node_or_null("Outer/Header/EpochBtn")
	if _epoch_btn: _epoch_btn.pressed.connect(_on_epoch_btn_pressed)
	var toggle: Button = get_node_or_null("Outer/Header/ToggleBtn")
	if toggle: toggle.pressed.connect(_toggle_collapse)
	GameState.build_menu_update_requested.connect(refresh)
	GameState.placement_mode_changed.connect(func(_m,_s): refresh())
	GameState.state_changed.connect(_on_state_changed)

## Bug-Fix (fehlender Epochen-Button): Klick auf den Epochen-Button im Header
## versucht direkt, die naechste Epoche freizuschalten. Davor gab es ueberhaupt
## keinen dauerhaft sichtbaren Weg dafuer - der alte Unlock-Button erschien nur
## ganz unten in der Liste und auch nur, wenn man sich die Epoche bereits
## leisten konnte.
func _on_epoch_btn_pressed() -> void:
	var next_id: String = TechTreeSys.get_next_epoch_id()
	if next_id == "":
		return
	if not TechTreeSys.unlock(next_id):
		GameState.notify("Nicht genug Ressourcen fuer die naechste Epoche!")
	refresh()

func _toggle_collapse() -> void:
	_collapsed = !_collapsed
	var sc: Node = get_node_or_null("Outer/ScrollContainer")
	if sc: sc.visible = !_collapsed

func refresh() -> void:
	if not is_inside_tree() or _container == null: return
	for c in _container.get_children(): c.queue_free()
	var unlocked: Array = TechTreeSys.get_unlocked_buildings()
	_update_epoch_btn()
	var all_b: Dictionary = BuildingData.BUILDINGS
	var type_order: Array = ["BUILDER","HOUSING","STORAGE","COLLECTOR","PROCESSOR",
		"MULTIPROCESSOR","HUNTER","FARM","FORESTER","HAPPINESS","WATERWHEEL","DAM","EXPEDITION","GRAVEYARD"]
	var type_labels: Dictionary = {
		"BUILDER":"Bauhoefe","HOUSING":"Wohnen","STORAGE":"Lager","COLLECTOR":"Sammler",
		"PROCESSOR":"Verarbeitung","MULTIPROCESSOR":"Kueche","HUNTER":"Jagd",
		"FARM":"Felder","FORESTER":"Forstwirtschaft","HAPPINESS":"Glueck",
		"WATERWHEEL":"Wasserrad","DAM":"Daemme","EXPEDITION":"Expeditionen","GRAVEYARD":"Gedenkstaette"}
	for btype in type_order:
		var ids: Array = []
		for bid in unlocked:
			if not all_b.has(bid): continue
			var bd: Dictionary = all_b[bid] as Dictionary
			if str(bd.get("type","")) == btype and str(bd.get("type","")) != "DECO": ids.append(str(bid))
		if ids.is_empty(): continue
		_add_header(str(type_labels.get(btype, btype)))
		for bid in ids: _add_building_btn(str(bid))
	_add_header("Wege")
	for ptype in BuildingData.PATH_TYPES: _add_path_btn(str(ptype))
	var decos: Array = []
	for bid in unlocked:
		if not all_b.has(bid): continue
		if str((all_b[bid] as Dictionary).get("type","")) == "DECO": decos.append(str(bid))
	if not decos.is_empty():
		_add_header("Dekorationen")
		for bid in decos: _add_building_btn(str(bid))
	_add_header("Terrain")
	_add_terrain_btn("RAISE","Erde aufschuetten","2 Stein/Tile  Drag=malen", ResourceSys.has("STONE",2))
	var dyn: int = int(float(ResourceSys.resources.get("DYNAMITE",0.0)))
	_add_terrain_btn("DYNAMITE","Sprengstoff (%d)" % dyn,"1 Dynamit  Klick=Legen  Nochmal=Zuenden", dyn>=1)

## Aktualisiert Text/Status des Epochen-Buttons im Header (zeigt aktuelle
## Epoche; falls eine naechste Epoche verfuegbar ist, deren Namen + Kosten;
## der Button ist deaktiviert, solange die Kosten nicht gedeckt sind).
func _update_epoch_btn() -> void:
	if _epoch_btn == null: return
	var cur: int = TechTreeSys.get_epoch()
	var next_id: String = TechTreeSys.get_next_epoch_id()
	if next_id == "":
		_epoch_btn.text = "Epoche %d (Max)" % cur
		_epoch_btn.disabled = true
		_epoch_btn.modulate = Color(0.5,0.5,0.5)
		return
	var nd: Dictionary = TechTreeSys.nodes.get(next_id,{}) as Dictionary
	var costs: Dictionary = nd.get("costs",{}) as Dictionary
	var can: bool = ResourceSys.can_afford(costs)
	_epoch_btn.text = "Epoche %d -> %s\n%s" % [cur, str(nd.get("name", next_id)), _costs_str(costs)]
	_epoch_btn.disabled = not can
	_epoch_btn.modulate = Color(1,1,1) if can else Color(0.6,0.6,0.6)

func _add_header(text: String) -> void:
	var lbl := Label.new()
	lbl.text = "-- " + text + " --"
	lbl.add_theme_font_size_override("font_size", 11)
	lbl.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
	_container.add_child(lbl)

func _add_building_btn(bid: String) -> void:
	var all_b: Dictionary = BuildingData.BUILDINGS
	if not all_b.has(bid): return
	var data: Dictionary = all_b[bid] as Dictionary
	var can: bool = BuildingSys.can_build(bid) or GameState.dev_all_buildings
	var btn: Button = _make_btn(str(data.get("icon","?"))+" "+str(data.get("name",bid)), _costs_str(data.get("costs",{}) as Dictionary), can)
	if GameState.placement_mode == "BUILDING" and GameState.placement_sub == bid:
		btn.add_theme_color_override("font_color", Color(0.96,0.69,0.1))
	var b: String = bid
	btn.pressed.connect(func(): GameState.set_placement("BUILDING", b); refresh())
	_container.add_child(btn)

func _add_path_btn(ptype: String) -> void:
	var pt: Dictionary = BuildingData.PATH_TYPES.get(ptype,{}) as Dictionary
	var costs: Dictionary = pt.get("costs",{}) as Dictionary
	var can: bool = ResourceSys.can_afford(costs) or GameState.dev_all_buildings
	var btn: Button = _make_btn(str(pt.get("name",ptype))+" (Weg)", _costs_str(costs)+" Drag=malen", can)
	var p: String = ptype
	btn.pressed.connect(func(): GameState.set_placement("PATH", p); refresh())
	_container.add_child(btn)

func _add_terrain_btn(sub: String, title: String, desc: String, enabled: bool) -> void:
	var btn: Button = _make_btn(title, desc, enabled)
	if GameState.placement_mode == "TERRAIN" and GameState.placement_sub == sub:
		btn.add_theme_color_override("font_color", Color(0.96,0.69,0.1))
	var s: String = sub
	btn.pressed.connect(func(): GameState.set_placement("TERRAIN", s); refresh())
	_container.add_child(btn)

func _add_tech_btn(tid: String) -> void:
	var nd: Dictionary = TechTreeSys.nodes.get(tid,{}) as Dictionary
	var btn: Button = _make_btn("Freischalten: "+str(nd.get("name",tid)), _costs_str(nd.get("costs",{}) as Dictionary), TechTreeSys.can_unlock(tid))
	var t: String = tid
	btn.pressed.connect(func(): TechTreeSys.unlock(t); refresh())
	_container.add_child(btn)

func _make_btn(title: String, sub: String, enabled: bool) -> Button:
	var btn := Button.new()
	btn.text = title + "\n" + sub
	btn.disabled = not enabled
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.custom_minimum_size = Vector2(0, 46)
	btn.add_theme_font_size_override("font_size", 11)
	if not enabled: btn.modulate = Color(0.5,0.5,0.5)
	return btn

func _costs_str(costs: Dictionary) -> String:
	var parts: Array = []
	var icons: Dictionary = BuildingData.RESOURCE_ICONS
	for res in costs: parts.append(str(icons.get(str(res),"?"))+str(costs[res]))
	return " ".join(parts)

func _on_state_changed(state: GameState.State) -> void:
	visible = (state == GameState.State.PLAYING)

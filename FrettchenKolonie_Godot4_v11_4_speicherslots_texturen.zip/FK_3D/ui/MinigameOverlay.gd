## MinigameOverlay.gd
## Feature (v11.2, First-Person-Modus): generisches Overlay-Panel, das genau
## EINES der vier Minispiel-Typen (Timing-Leiste, Mash, Reaktions-Klick,
## Balance) anzeigt und steuert. Wird komplett dynamisch in _ready() gebaut
## (gleiches Muster wie BuildingInfo.gd/ExpeditionPanel.gd), Main.gd haengt
## nur einen leeren Control mit diesem Script in den UI-Baum.
##
## GameController ruft start_wood()/start_stone()/start_berries()/
## start_iron()/start_water() auf, sobald der Spieler im First-Person-Modus
## eine passende Ressourcenquelle per "interact" (E) anspricht. Bei Abschluss
## (Erfolg ODER Abbruch per ESC) feuert minigame_finished(resource, reward) -
## GameController kuemmert sich dort um Lagerabzug + ResourceSys.add().
extends Control

signal minigame_finished(resource_type: String, reward: float)

const STAGE_SIZE: Vector2 = Vector2(360.0, 150.0)
const BERRY_POOL_SIZE: int = 4

var _bg: ColorRect = null
var _panel: PanelContainer = null
var _title_lbl: Label = null
var _instr_lbl: Label = null
var _progress_lbl: Label = null
var _stage: Control = null

# Timing-Leiste (Holz/Erz)
var _tb_track: ColorRect = null
var _tb_zone: ColorRect = null
var _tb_marker: ColorRect = null

# Mash (Stein)
var _mash_track: ColorRect = null
var _mash_fill: ColorRect = null

# Reaktions-Klick (Beeren)
var _berry_buttons: Array = []   # Array[Button], fester Pool

# Balance (Wasser)
var _bal_track: ColorRect = null
var _bal_knob: ColorRect = null
var _bal_center_marker: ColorRect = null

var _current = null            # TimingBarMinigame | MashMinigame | ReactionClickMinigame | BalanceMinigame
var _current_kind: String = "" # "TIMING" | "MASH" | "REACTION" | "BALANCE"
var _resource_type: String = ""

func _ready() -> void:
	hide()
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_bg = ColorRect.new(); _bg.color = Color(0.0, 0.0, 0.0, 0.55)
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_bg)

	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(cc)

	_panel = PanelContainer.new(); _panel.custom_minimum_size = Vector2(420.0, 0.0)
	cc.add_child(_panel)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 10)
	_panel.add_child(vb)

	_title_lbl = Label.new(); _title_lbl.add_theme_font_size_override("font_size", 20)
	_title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_title_lbl)

	_instr_lbl = Label.new(); _instr_lbl.add_theme_font_size_override("font_size", 13)
	_instr_lbl.add_theme_color_override("font_color", Color(0.75, 0.75, 0.8))
	_instr_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_instr_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	vb.add_child(_instr_lbl)

	_stage = Control.new(); _stage.custom_minimum_size = STAGE_SIZE
	vb.add_child(_stage)
	_build_timing_visuals()
	_build_mash_visuals()
	_build_reaction_visuals()
	_build_balance_visuals()

	_progress_lbl = Label.new(); _progress_lbl.add_theme_font_size_override("font_size", 13)
	_progress_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_progress_lbl)

	var cancel_btn := Button.new(); cancel_btn.text = "Abbrechen (ESC)"
	cancel_btn.pressed.connect(_on_cancel)
	vb.add_child(cancel_btn)

# ── Visuals: Timing-Leiste ───────────────────────────────────────────────────
func _build_timing_visuals() -> void:
	_tb_track = ColorRect.new(); _tb_track.color = Color(0.15, 0.15, 0.18)
	_tb_track.position = Vector2(0.0, 60.0); _tb_track.size = Vector2(STAGE_SIZE.x, 26.0)
	_stage.add_child(_tb_track)
	_tb_zone = ColorRect.new(); _tb_zone.color = Color(0.30, 0.85, 0.30, 0.85)
	_tb_zone.position = Vector2(0.0, 60.0); _tb_zone.size = Vector2(40.0, 26.0)
	_stage.add_child(_tb_zone)
	_tb_marker = ColorRect.new(); _tb_marker.color = Color(1.0, 0.92, 0.3)
	_tb_marker.position = Vector2(0.0, 56.0); _tb_marker.size = Vector2(4.0, 34.0)
	_stage.add_child(_tb_marker)

# ── Visuals: Mash ─────────────────────────────────────────────────────────
func _build_mash_visuals() -> void:
	_mash_track = ColorRect.new(); _mash_track.color = Color(0.15, 0.15, 0.18)
	_mash_track.position = Vector2(0.0, 60.0); _mash_track.size = Vector2(STAGE_SIZE.x, 26.0)
	_stage.add_child(_mash_track)
	_mash_fill = ColorRect.new(); _mash_fill.color = Color(0.95, 0.55, 0.2)
	_mash_fill.position = Vector2(0.0, 60.0); _mash_fill.size = Vector2(0.0, 26.0)
	_stage.add_child(_mash_fill)

# ── Visuals: Reaktions-Klick ─────────────────────────────────────────────────
func _build_reaction_visuals() -> void:
	for i in BERRY_POOL_SIZE:
		var btn := Button.new()
		btn.text = "🫐"
		btn.custom_minimum_size = Vector2(40.0, 40.0)
		btn.size = Vector2(40.0, 40.0)
		btn.add_theme_font_size_override("font_size", 20)
		btn.pressed.connect(_on_berry_pressed.bind(i))
		_stage.add_child(btn)
		_berry_buttons.append(btn)

# ── Visuals: Balance ──────────────────────────────────────────────────────
func _build_balance_visuals() -> void:
	_bal_track = ColorRect.new(); _bal_track.color = Color(0.15, 0.15, 0.18)
	_bal_track.position = Vector2(0.0, 65.0); _bal_track.size = Vector2(STAGE_SIZE.x, 18.0)
	_stage.add_child(_bal_track)
	_bal_center_marker = ColorRect.new(); _bal_center_marker.color = Color(0.4, 0.9, 1.0, 0.6)
	_bal_center_marker.position = Vector2(STAGE_SIZE.x * 0.5 - 2.0, 60.0); _bal_center_marker.size = Vector2(4.0, 28.0)
	_stage.add_child(_bal_center_marker)
	_bal_knob = ColorRect.new(); _bal_knob.color = Color(0.3, 0.7, 1.0)
	_bal_knob.position = Vector2(STAGE_SIZE.x * 0.5 - 7.0, 58.0); _bal_knob.size = Vector2(14.0, 34.0)
	_stage.add_child(_bal_knob)

func _hide_all_stage_visuals() -> void:
	_tb_track.visible = false; _tb_zone.visible = false; _tb_marker.visible = false
	_mash_track.visible = false; _mash_fill.visible = false
	for b in _berry_buttons: (b as Button).visible = false
	_bal_track.visible = false; _bal_knob.visible = false; _bal_center_marker.visible = false

# ── Start-Funktionen pro Ressourcentyp ───────────────────────────────────────
## Holzfaellen: gemaessigte Timing-Leiste, breite Zone, 5 Treffer.
func start_wood(max_reward: float) -> void:
	_resource_type = "WOOD"
	_current_kind = "TIMING"
	_current = TimingBarMinigame.new("WOOD", max_reward, 0.24, 0.55, 5, 18.0)
	_title_lbl.text = "🪓 Holz faellen"
	_instr_lbl.text = "Druecke [E], wenn der Marker im gruenen Bereich ist - 5 gute Treffer!"
	_show_kind()

## Erzabbau: gleiche Mechanik wie Holz, aber deutlich schmalere Zone, hoehere
## Geschwindigkeit und mehr noetige Treffer - spuerbar praeziser/schwerer.
func start_iron(max_reward: float) -> void:
	_resource_type = "IRON"
	_current_kind = "TIMING"
	_current = TimingBarMinigame.new("IRON", max_reward, 0.11, 0.85, 7, 20.0)
	_title_lbl.text = "⛏️ Erz abbauen"
	_instr_lbl.text = "Triff die schmale Ader! Druecke [E] praezise im gruenen Bereich - 7 Treffer."
	_show_kind()

## Steinbrechen: Mash-Minispiel, stetiges Druecken noetig.
func start_stone(max_reward: float) -> void:
	_resource_type = "STONE"
	_current_kind = "MASH"
	_current = MashMinigame.new("STONE", max_reward, 0.13, 0.18, 8.0)
	_title_lbl.text = "🪨 Stein brechen"
	_instr_lbl.text = "Haemmere [E] im Rhythmus - die Leiste sackt staendig wieder ab!"
	_show_kind()

## Beerenpfluecken: Reaktions-Klick.
func start_berries(max_reward: float) -> void:
	_resource_type = "BERRIES"
	_current_kind = "REACTION"
	_current = ReactionClickMinigame.new("BERRIES", max_reward, 10, BERRY_POOL_SIZE, 1.3, 0.55, 12.0, STAGE_SIZE)
	_title_lbl.text = "🫐 Beeren pfluecken"
	_instr_lbl.text = "Klicke die Beeren an, bevor sie verschwinden!"
	_show_kind()

## Wasserschoepfen: Balance-Minispiel.
func start_water(max_reward: float) -> void:
	_resource_type = "WATER"
	_current_kind = "BALANCE"
	_current = BalanceMinigame.new("WATER", max_reward, 1.1, 10.0, 1.0)
	_title_lbl.text = "💧 Wasser schoepfen"
	_instr_lbl.text = "Halte den Eimer mit [A]/[D] im Gleichgewicht - die Stroemung zieht!"
	_show_kind()

func _show_kind() -> void:
	_hide_all_stage_visuals()
	match _current_kind:
		"TIMING":
			_tb_track.visible = true; _tb_zone.visible = true; _tb_marker.visible = true
		"MASH":
			_mash_track.visible = true; _mash_fill.visible = true
		"REACTION":
			for b in _berry_buttons: (b as Button).visible = false
		"BALANCE":
			_bal_track.visible = true; _bal_knob.visible = true; _bal_center_marker.visible = true
	show()
	# Mauszeiger wird gebraucht, um Beeren anzuklicken und den Abbrechen-Button
	# zu treffen - waehrend des Minispiels immer sichtbar/frei, unabhaengig
	# davon, ob gerade im First-Person-Umsehen die Maus gefangen war.
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func is_active() -> bool:
	return _current != null

## Oeffentlicher Abbruch-Einstieg, genutzt von GameController bei ESC waehrend
## eines laufenden Minispiels.
func cancel() -> void:
	_on_cancel()

func _process(dt: float) -> void:
	if _current == null: return
	match _current_kind:
		"TIMING":
			var tb: TimingBarMinigame = _current
			if Input.is_action_just_pressed("interact"): tb.try_hit()
			tb.update(dt)
			var marker: float = tb.get_marker_pos()
			var zr: Vector2 = tb.get_zone_range()
			_tb_marker.position.x = marker * STAGE_SIZE.x - _tb_marker.size.x * 0.5
			_tb_zone.position.x = zr.x * STAGE_SIZE.x
			_tb_zone.size.x = (zr.y - zr.x) * STAGE_SIZE.x
			_progress_lbl.text = "Treffer: %d/%d   Zeit: %.0fs" % [tb.hits_done, tb.hits_required, maxf(0.0, tb.max_time - tb.elapsed)]
			if tb.is_finished(): _finish_current()
		"MASH":
			var mg: MashMinigame = _current
			if Input.is_action_just_pressed("interact"): mg.press()
			mg.update(dt)
			_mash_fill.size.x = mg.fill * STAGE_SIZE.x
			_progress_lbl.text = "Fuellstand: %d%%   Zeit: %.0fs" % [int(mg.fill * 100.0), maxf(0.0, mg.max_time - mg.elapsed)]
			if mg.is_finished(): _finish_current()
		"REACTION":
			var rc: ReactionClickMinigame = _current
			rc.update(dt)
			var active: Array = rc.get_active_targets()
			for i in BERRY_POOL_SIZE:
				var btn: Button = _berry_buttons[i]
				if i < active.size():
					var ad: Dictionary = active[i]
					btn.visible = true
					btn.position = (ad["pos"] as Vector2) - btn.size * 0.5
					var lf: float = float(ad["life_frac"])
					btn.modulate = Color(1.0, 1.0, 1.0, 0.4 + 0.6 * lf)
				else:
					btn.visible = false
			_progress_lbl.text = "Gepflueckt: %d/%d   Zeit: %.0fs" % [rc.total_clicked, rc.total_targets, maxf(0.0, rc.max_time - rc.elapsed)]
			if rc.is_finished(): _finish_current()
		"BALANCE":
			var bm: BalanceMinigame = _current
			var left: bool = Input.is_action_pressed("move_left")
			var right: bool = Input.is_action_pressed("move_right")
			bm.update(dt, left, right)
			var t: float = clampf((bm.value + 1.5) / 3.0, 0.0, 1.0)
			_bal_knob.position.x = t * STAGE_SIZE.x - _bal_knob.size.x * 0.5
			_bal_knob.color = Color(0.95, 0.3, 0.25) if absf(bm.value) >= bm.spill_limit else Color(0.3, 0.7, 1.0)
			_progress_lbl.text = "Balance halten...   Zeit: %.0fs" % maxf(0.0, bm.max_time - bm.elapsed)
			if bm.is_finished(): _finish_current()

func _on_berry_pressed(idx: int) -> void:
	if _current_kind != "REACTION" or _current == null: return
	var rc: ReactionClickMinigame = _current
	var btn: Button = _berry_buttons[idx]
	rc.try_click(btn.position + btn.size * 0.5)

func _finish_current() -> void:
	if _current == null: return
	var reward: float = _current.get_reward()
	var res: String = _resource_type
	_current = null; _current_kind = ""; _resource_type = ""
	hide()
	minigame_finished.emit(res, reward)

func _on_cancel() -> void:
	if _current == null: return
	_current = null; _current_kind = ""
	var res: String = _resource_type
	_resource_type = ""
	hide()
	minigame_finished.emit(res, 0.0)

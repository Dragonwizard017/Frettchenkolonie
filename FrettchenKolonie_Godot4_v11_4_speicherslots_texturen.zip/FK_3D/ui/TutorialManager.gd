## TutorialManager.gd
## Bringt das Tutorial aus der HTML-Version zurueck: Freddy Frettchen fuehrt
## neue Spieler in kurzen Schritten durch die Grundlagen der Kolonie.
## Wird nur bei einer NEUEN Kolonie automatisch gestartet (nicht beim Laden).
extends Control

const STEPS: Array = [
	{"title": "Willkommen!",
	 "text": "Hallo, ich bin Freddy Frettchen! Ich zeige dir kurz, wie deine Kolonie funktioniert."},
	{"title": "Kamera",
	 "text": "Bewege die Kamera mit WASD oder den Pfeiltasten. Mit dem Mausrad zoomst du, mit der rechten Maustaste ziehst du die Ansicht."},
	{"title": "Bau-Menue",
	 "text": "Links findest du das Bau-Menue. Baue jetzt einen Holzfaeller oder Steinbruch - meine Frettchen brauchen Rohstoffe!",
	 "wait_for": "building_placed"},
	{"title": "Ressourcen im Blick",
	 "text": "Oben siehst du deine Ressourcen, den Wasserstand, den Lagerfuellstand und wie viele Frettchen du hast."},
	{"title": "Hunger & Durst",
	 "text": "Meine Frettchen brauchen Essen und Wasser! Baue rechtzeitig einen Brunnen und eine Nahrungsquelle, sonst werden sie krank."},
	{"title": "Tempo",
	 "text": "Die Zeit laeuft automatisch weiter. Mit den Geschwindigkeits-Buttons oben rechts (1x/2x/3x) oder der Leertaste kannst du beschleunigen oder pausieren."},
	{"title": "Terrain formen",
	 "text": "Im Bau-Menue unter 'Terrain' kannst du Erde aufschuetten oder mit Sprengstoff Huegel abtragen."},
	{"title": "Epochen",
	 "text": "Oben im Bau-Menue zeigt dir der Epochen-Button, was du fuer die naechste Epoche brauchst - ein Klick schaltet sie frei, sobald du es dir leisten kannst."},
	{"title": "Speichern",
	 "text": "Ueber das Pause-Menue (Leertaste) kannst du jederzeit speichern, um spaeter weiterzuspielen."},
	{"title": "Viel Erfolg!",
	 "text": "Das war's schon! Erkunde, baue auf und lass deine Kolonie wachsen. Viel Erfolg, Frettchen-Boss!"},
]

var _step: int = 0
var _waiting_for: String = ""
var _box: PanelContainer
var _title_lbl: Label
var _text_lbl: Label
var _next_btn: Button
var _skip_btn: Button
var _step_lbl: Label

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hide()
	_build_ui()
	GameState.building_placed.connect(_on_building_placed)

func _build_ui() -> void:
	_box = PanelContainer.new(); _box.name = "TutorialBox"
	_box.mouse_filter = Control.MOUSE_FILTER_STOP
	_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_box.anchor_left = 0.16; _box.anchor_right = 0.84
	_box.offset_top = -172; _box.offset_bottom = -24
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.09, 0.13, 0.95)
	sb.set_corner_radius_all(10)
	sb.content_margin_left = 18; sb.content_margin_right = 18
	sb.content_margin_top = 14;  sb.content_margin_bottom = 14
	sb.border_width_top = 2; sb.border_color = Color(0.96, 0.69, 0.1)
	_box.add_theme_stylebox_override("panel", sb)
	add_child(_box)

	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8)
	_box.add_child(vb)

	var hdr := HBoxContainer.new(); hdr.add_theme_constant_override("separation", 10)
	vb.add_child(hdr)

	var icon := Label.new(); icon.text = "🦦"
	icon.add_theme_font_size_override("font_size", 30)
	hdr.add_child(icon)

	var hdr_vb := VBoxContainer.new(); hdr_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(hdr_vb)
	_title_lbl = Label.new()
	_title_lbl.add_theme_font_size_override("font_size", 16)
	_title_lbl.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
	hdr_vb.add_child(_title_lbl)
	_step_lbl = Label.new()
	_step_lbl.add_theme_font_size_override("font_size", 11)
	_step_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	hdr_vb.add_child(_step_lbl)

	_text_lbl = Label.new()
	_text_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	_text_lbl.add_theme_font_size_override("font_size", 14)
	_text_lbl.custom_minimum_size = Vector2(0, 44)
	vb.add_child(_text_lbl)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	_skip_btn = Button.new(); _skip_btn.text = "Tutorial ueberspringen"
	_skip_btn.pressed.connect(_on_skip)
	row.add_child(_skip_btn)
	_next_btn = Button.new(); _next_btn.text = "Weiter"
	_next_btn.pressed.connect(_on_next)
	row.add_child(_next_btn)

## Startet das Tutorial von vorne. Wird beim Start einer NEUEN Kolonie gerufen.
func start() -> void:
	_step = 0
	show()
	_show_step()

func _show_step() -> void:
	if _step >= STEPS.size():
		_finish()
		return
	var s: Dictionary = STEPS[_step]
	_title_lbl.text = str(s.get("title",""))
	_text_lbl.text = str(s.get("text",""))
	_step_lbl.text = "Schritt %d/%d" % [_step + 1, STEPS.size()]
	_waiting_for = str(s.get("wait_for",""))
	# Wenn auf eine Spielaktion gewartet wird (z.B. erstes Gebaeude), gibt es
	# keinen "Weiter"-Button - der Schritt geht automatisch weiter.
	_next_btn.visible = _waiting_for.is_empty()

func _on_next() -> void:
	_step += 1
	_show_step()

func _on_skip() -> void:
	_finish()

func _on_building_placed(_b) -> void:
	if visible and _waiting_for == "building_placed":
		_waiting_for = ""
		_step += 1
		_show_step()

func _finish() -> void:
	hide()

## MainMenu.gd
extends Control

@onready var new_game_btn: Button = $VBox/NewGameBtn
@onready var load_btn: Button = $VBox/LoadBtn
@onready var version_lbl: Label = $VBox/VersionLabel

signal new_game_requested
signal load_requested

func _ready() -> void:
	GameState.state_changed.connect(_on_state_changed)
	if new_game_btn: new_game_btn.pressed.connect(func(): new_game_requested.emit())
	if load_btn:     load_btn.pressed.connect(func(): load_requested.emit())
	if version_lbl:  version_lbl.text = "FrettchenKolonie v5.0 Enhanced Edition"

func _on_state_changed(state: GameState.State) -> void:
	visible = (state == GameState.State.MAIN_MENU)

## ─────────────────────────────────────────────────────────────────────────────
## WorldCreation.gd
## ─────────────────────────────────────────────────────────────────────────────
## NOTE: Separate file in production – shown here inline for compactness.
## In Godot, create WorldCreation.tscn with this script attached.

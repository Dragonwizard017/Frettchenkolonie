## PauseMenu.gd
extends CenterContainer

var _vol_master: HSlider = null
var _vol_music: HSlider  = null
var _vol_sfx: HSlider    = null

func _ready() -> void:
	hide()
	GameState.state_changed.connect(_on_state_changed)
	_vol_master = get_node_or_null("Panel/VBox/Audio/MasterSlider")
	_vol_music  = get_node_or_null("Panel/VBox/Audio/MusicSlider")
	_vol_sfx    = get_node_or_null("Panel/VBox/Audio/SfxSlider")
	_connect_btn("Panel/VBox/ResumeBtn", func(): _on_resume())
	_connect_btn("Panel/VBox/SaveBtn",   func(): _on_save())
	# Feature (v11.4, Speicherslot-System): "Speichern unter" legt einen neuen,
	# zusaetzlichen benannten Speicherstand an, ohne den aktuellen Slot zu ueberschreiben.
	_connect_btn("Panel/VBox/SaveAsRow/SaveAsBtn", func(): _on_save_as())
	_connect_btn("Panel/VBox/MenuBtn",   func(): _on_main_menu())
	_connect_btn("Panel/VBox/Speed/Btn1", func(): GameState.set_game_speed(1.0))
	_connect_btn("Panel/VBox/Speed/Btn2", func(): GameState.set_game_speed(2.0))
	_connect_btn("Panel/VBox/Speed/Btn3", func(): GameState.set_game_speed(3.0))
	if _vol_master: _vol_master.value_changed.connect(func(_v): _update_volumes())
	if _vol_music:  _vol_music.value_changed.connect(func(_v): _update_volumes())
	if _vol_sfx:    _vol_sfx.value_changed.connect(func(_v): _update_volumes())

func _connect_btn(path: String, cb: Callable) -> void:
	var btn: Button = get_node_or_null(path)
	if btn: btn.pressed.connect(cb)

func _on_resume() -> void:
	GameState.set_state(GameState.State.PLAYING)
	GameState.game_speed = 1.0

## Feature (v11.4, Speicherslot-System): schreibt jetzt in den zur Kolonie
## gehoerenden, benannten Slot zurueck (statt in einen festen "quicksave"-Slot),
## sodass jede Welt ihren eigenen Speicherstand behaelt.
func _on_save() -> void:
	var gc: Node = get_node_or_null("/root/Main/GameScreen")
	if gc == null: return
	var slot: String = str(gc.current_save_slot)
	if slot.is_empty():
		slot = str(gc.current_world_name) if str(gc.current_world_name) != "" else "Kolonie"
		gc.current_save_slot = slot
	SaveSys.save(slot, gc)

## Feature (v11.4, Speicherslot-System): speichert den aktuellen Stand
## zusaetzlich unter einem neuen Namen als eigenen Speicherstand.
func _on_save_as() -> void:
	var gc: Node = get_node_or_null("/root/Main/GameScreen")
	var input: LineEdit = get_node_or_null("Panel/VBox/SaveAsRow/SaveAsInput")
	if gc == null or input == null: return
	var raw_name: String = input.text.strip_edges()
	if raw_name.is_empty():
		GameState.notify("Bitte zuerst einen Namen eingeben.", Color(0.8,0.2,0.1)); return
	var new_slot: String = str(gc.call("_make_unique_save_slot", raw_name))
	gc.current_save_slot = new_slot
	gc.current_world_name = raw_name
	SaveSys.save(new_slot, gc)
	input.text = ""

func _on_main_menu() -> void:
	SoundSys.stop_music()
	GameState.set_state(GameState.State.MAIN_MENU)

func _update_volumes() -> void:
	SoundSys.set_volumes(
		_vol_master.value if _vol_master else 80.0,
		_vol_music.value  if _vol_music  else 60.0,
		_vol_sfx.value    if _vol_sfx    else 70.0
	)

func _on_state_changed(state: GameState.State) -> void:
	visible = (state == GameState.State.PAUSED)
	# Feature (v11.4, Speicherslot-System): Save-Button zeigt den Namen der
	# aktuellen Kolonie, damit klar ist, in welchen Slot "Speichern" schreibt.
	if visible:
		var gc: Node = get_node_or_null("/root/Main/GameScreen")
		var save_btn: Button = get_node_or_null("Panel/VBox/SaveBtn")
		if gc and save_btn:
			save_btn.text = "Speichern: " + str(gc.current_world_name)

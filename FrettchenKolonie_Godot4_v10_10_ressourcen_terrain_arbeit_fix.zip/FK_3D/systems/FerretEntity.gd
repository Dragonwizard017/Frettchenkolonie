## FerretEntity.gd
class_name FerretEntity
extends RefCounted

const FIRST_NAMES: Array = ["Freddy","Fido","Fiona","Franz","Frieda","Felix","Frida","Frank","Finn","Flora","Frodo","Franzi","Filou","Feli","Fips"]
const LAST_NAMES: Array  = ["Frettchen","Pfote","Flausch","Fell","Schnueffel","Huepfer","Schwanz","Nase","Kralle","Zahn"]

# ── Feature (v10.10): Frettchen gehen jetzt tatsaechlich zu ihrem Arbeitsplatz
# bzw. zu einer Ressourcenquelle, statt nur zufaellig durch die Karte zu
# wandern. Bei Sammel-Gebaeuden (COLLECTOR mit WOOD/STONE/BERRIES/IRON) pendeln
# sie zwischen Gebaeude und einer konkreten, im Tile gespeicherten
# Resource-Node hin und her, "ernten" sie dort (sichtbar als kurze Pause +
# Wipp-Animation in WorldRenderer3D, siehe harvest_anim_t) und die Quelle
# verliert dabei "amount" - bis sie erschoepft ist und eine Zeit lang
# regenerieren muss (siehe WorldGenerator.tick_resource_nodes).
const NODE_RESOURCE_TYPES: Array = ["WOOD", "STONE", "BERRIES", "IRON"]
const HARVEST_DURATION: float = 3.0   # Sekunden pro Ernte-Aktion an einer Quelle
const HARVEST_AMOUNT:   float = 18.0  # wie viel "amount" eine Ernte-Aktion abbaut

var ferret_name: String = ""
var health: float = 100.0
var needs: Dictionary = {"food": 60.0, "water": 60.0, "happiness": 60.0}
var assigned_building = null
var current_construction_site = null
var home = null
var specialization: String = ""
var spec_days: float = 0.0
var age_days: float = 0.0
var is_alive: bool = true
var pos: Vector2 = Vector2.ZERO
var target_pos: Vector2 = Vector2.ZERO
var move_speed: float = 2.0   # Tiles pro Sekunde

# ── Arbeits-/Ernte-Zustand (nicht persistiert, baut sich nach dem Laden von
# selbst wieder auf, genau wie assigned_building) ────────────────────────────
var work_state: String = "IDLE"        # IDLE, TO_BUILDING, WORKING, TO_NODE, HARVESTING, RETURN
var harvest_tile: Vector2i = Vector2i(-1, -1)
var work_timer: float = 0.0
var harvest_anim_t: float = 0.0        # Lese-Flag fuer den Renderer (Wipp-Animation)

static func create_random() -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = FIRST_NAMES[randi() % FIRST_NAMES.size()] + " " + LAST_NAMES[randi() % LAST_NAMES.size()]
	f.health = randf_range(80.0, 100.0)
	f.move_speed = randf_range(1.5, 2.8)
	f.needs = {
		"food": randf_range(50.0, 80.0),
		"water": randf_range(50.0, 80.0),
		"happiness": randf_range(40.0, 70.0)
	}
	# Startposition: isometrische Weltkoordinaten nahe Karte-Mitte (Tile 30,30)
	# tile_to_world(30,30) = (0, 2880) — wir randomisieren etwas drumherum
	f.pos = Vector2(30.0 + randf_range(-4.0, 4.0), 30.0 + randf_range(-4.0, 4.0))
	f.target_pos = f.pos
	return f

func update(dt: float, world: Array = []) -> void:
	age_days += dt / 60.0
	needs["food"] = maxf(0.0, float(needs["food"]) - dt * 0.8)
	needs["water"] = maxf(0.0, float(needs["water"]) - dt * 1.1)
	needs["happiness"] = maxf(0.0, float(needs["happiness"]) - dt * 0.4)
	var avg: float = (float(needs["food"]) + float(needs["water"])) / 2.0
	if avg < 20.0:
		health = maxf(0.0, health - dt * (20.0 - avg) * 0.1)
	elif avg > 60.0:
		health = minf(100.0, health + dt * 0.5)
	if assigned_building != null:
		var ab: BuildingEntity = assigned_building
		if not ab.is_under_construction:
			spec_days += dt / 60.0
			if spec_days >= 5.0 and specialization != ab.btype:
				specialization = ab.btype
	else:
		spec_days = 0.0
	_update_work(dt, world)

## Bewegt pos einen Schritt Richtung target und haelt target_pos synchron, da
## WorldRenderer3D daraus die Blickrichtung des Frettchens berechnet
## (fe.target_pos - fe.pos).
func _move_toward(target: Vector2, dt: float) -> bool:
	target_pos = target
	var diff: Vector2 = target - pos
	if diff.length() < 0.08:
		pos = target
		return true
	pos += diff.normalized() * move_speed * dt
	return false

func _wander(dt: float) -> void:
	var diff: Vector2 = target_pos - pos
	if diff.length() < 0.15:
		target_pos = pos + Vector2(randf_range(-3.5, 3.5), randf_range(-3.5, 3.5))
	else:
		pos += diff.normalized() * move_speed * dt

func _update_work(dt: float, world: Array) -> void:
	harvest_anim_t = 0.0
	if assigned_building == null:
		work_state = "IDLE"
		harvest_tile = Vector2i(-1, -1)
		_wander(dt)
		return
	var ab: BuildingEntity = assigned_building
	if ab.is_under_construction:
		_wander(dt)
		return

	var building_pos: Vector2 = Vector2(float(ab.tile_x) + 0.5, float(ab.tile_y) + 0.5)
	var is_node_collector: bool = (ab.btype == "COLLECTOR"
		and ab.collects_resource in NODE_RESOURCE_TYPES)

	if not is_node_collector:
		# Einfacher Fall (Werkstaetten, Bauernhoefe, Brunnen, ...): das
		# Frettchen geht ins/zum Gebaeude und bleibt dort "drinnen" stehen,
		# waehrend die eigentliche Produktion ueber den Gebaeude-Timer laeuft.
		if work_state != "WORKING" and work_state != "TO_BUILDING":
			work_state = "TO_BUILDING"
		if _move_toward(building_pos, dt):
			work_state = "WORKING"
		return

	# Sammel-Gebaeude mit physischen Ressourcen-Quellen im Terrain: zwischen
	# Gebaeude und Quelle hin- und herpendeln.
	match work_state:
		"TO_NODE":
			var target: Vector2 = Vector2(float(harvest_tile.x) + 0.5, float(harvest_tile.y) + 0.5)
			if _node_still_valid(world):
				if _move_toward(target, dt):
					work_state = "HARVESTING"
					work_timer = 0.0
			else:
				work_state = "WORKING"
		"HARVESTING":
			work_timer += dt
			harvest_anim_t = work_timer
			if work_timer >= HARVEST_DURATION:
				_finish_harvest(world)
				work_state = "RETURN"
		"RETURN":
			if _move_toward(building_pos, dt):
				work_state = "WORKING"
		_:
			var node_tile: Vector2i = _find_harvestable_node(world, ab)
			if node_tile.x >= 0:
				harvest_tile = node_tile
				work_state = "TO_NODE"
			else:
				# Keine erntbare Quelle in der Naehe (alle gerade erschoepft) -
				# am Gebaeude warten, bis wieder eine verfuegbar ist.
				work_state = "WORKING"
				_move_toward(building_pos, dt)

func _node_still_valid(world: Array) -> bool:
	var nd: Dictionary = _get_node_dict(world, harvest_tile)
	if nd.is_empty(): return false
	if bool(nd.get("depleted", false)): return false
	return float(nd.get("amount", 0.0)) > 0.5

func _get_node_dict(world: Array, t: Vector2i) -> Dictionary:
	if t.x < 0 or t.x >= world.size(): return {}
	var col: Array = world[t.x]
	if t.y < 0 or t.y >= col.size(): return {}
	var tile: Dictionary = col[t.y]
	var nd = tile.get("resource_node")
	if nd == null or not (nd is Dictionary): return {}
	return nd

## Sucht eine zufaellige, aktuell erntbare Resource-Node desselben Typs wie
## `ab.collects_resource` im Sammelradius des Gebaeudes.
func _find_harvestable_node(world: Array, ab: BuildingEntity) -> Vector2i:
	var candidates: Array = []
	var r: int = ab.collection_radius
	var bx: int = ab.tile_x
	var by: int = ab.tile_y
	var ww: int = world.size()
	for dx in range(-r, r + 1):
		var tx: int = bx + dx
		if tx < 0 or tx >= ww: continue
		var col: Array = world[tx]
		var hh: int = col.size()
		for dy in range(-r, r + 1):
			var ty: int = by + dy
			if ty < 0 or ty >= hh: continue
			var nd: Dictionary = _get_node_dict(world, Vector2i(tx, ty))
			if nd.is_empty(): continue
			if str(nd.get("type", "")) != ab.collects_resource: continue
			if bool(nd.get("depleted", false)): continue
			if float(nd.get("amount", 0.0)) <= 1.0: continue
			candidates.append(Vector2i(tx, ty))
	if candidates.is_empty(): return Vector2i(-1, -1)
	return candidates[randi() % candidates.size()]

## Baut die geerntete Quelle ab; wird sie leer, gilt sie als "depleted" und
## braucht danach Zeit zum Regenerieren (siehe WorldGenerator.tick_resource_nodes).
func _finish_harvest(world: Array) -> void:
	var nd: Dictionary = _get_node_dict(world, harvest_tile)
	if nd.is_empty(): return
	var amt: float = float(nd.get("amount", 0.0)) - HARVEST_AMOUNT
	if amt <= 0.0:
		nd["amount"] = 0.0
		nd["depleted"] = true
		nd["regen_timer"] = 0.0
	else:
		nd["amount"] = amt

func get_happiness() -> float:
	return float(needs["happiness"])

func serialize() -> Dictionary:
	return {
		"name": ferret_name, "health": health,
		"needs": needs.duplicate(), "age_days": age_days,
		"specialization": specialization, "spec_days": spec_days,
		"pos_x": pos.x, "pos_y": pos.y
	}

static func deserialize(data: Dictionary) -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = str(data.get("name", "Unbekannt"))
	f.health = float(data.get("health", 100.0))
	var n = data.get("needs", {"food": 60.0, "water": 60.0, "happiness": 60.0})
	f.needs = (n as Dictionary).duplicate()
	f.age_days = float(data.get("age_days", 0.0))
	f.specialization = str(data.get("specialization", ""))
	f.spec_days = float(data.get("spec_days", 0.0))
	# Pos: ältere Saves hatten Pixel-Koordinaten (~2880) – sicher auf Tile-Range clampen
	var raw_x: float = float(data.get("pos_x", 30.0))
	var raw_y: float = float(data.get("pos_y", 30.0))
	# Heuristik: Pixel-Koordinaten > 200 stammen aus altem Format
	if absf(raw_x) > 200.0 or absf(raw_y) > 200.0:
		raw_x = 30.0 + randf_range(-3.0, 3.0)
		raw_y = 30.0 + randf_range(-3.0, 3.0)
	f.pos = Vector2(raw_x, raw_y)
	f.target_pos = f.pos
	return f

## AchievementSystem.gd
## Feature (v11.8, Achievement-System - Phase 1 des Langzeit-Content-Pakets).
## Architektur bewusst analog zu TechTree.gd: const-Datendictionary (hier
## ACHIEVEMENTS statt NODES), ein "unlocked"-Array, serialize()/deserialize()
## fuer SaveSystem.gd. Anders als TechTree.gd gibt es hier keine Kosten/
## Freischalt-Buttons - Achievements schalten sich automatisch frei, sobald
## ihre Bedingung erfuellt ist.
##
## WICHTIG (Performance-Vorgabe): Pruefung ist EVENT-GETRIEBEN, nicht per
## Frame-Polling. Es gibt bewusst KEINEN _process()-Tick - alle Bedingungen
## werden ausschliesslich in den GameState-Signal-Handlern unten geprueft,
## jeweils nur fuer die Achievement-Kategorien, die durch das jeweilige
## Signal ueberhaupt betroffen sein koennen.
extends Node

const CATEGORIES: Dictionary = {
	"POPULATION":  {"name": "Bevölkerung", "icon": "🐾"},
	"ECONOMY":     {"name": "Wirtschaft",  "icon": "📦"},
	"SURVIVAL":    {"name": "Überleben",   "icon": "❤️"},
	"EXPLORATION": {"name": "Erkundung",   "icon": "🗺️"},
	"TECH":        {"name": "Tech",        "icon": "🔬"},
}
const CATEGORY_ORDER: Array = ["POPULATION", "ECONOMY", "SURVIVAL", "EXPLORATION", "TECH"]

## "reward" ist IMMER rein kosmetisch (Statue-Skin-Bezeichnung o.ae.) oder
## leer - bewusst KEINE Ressourcen-/Produktionsboni, um Powercreep zu
## vermeiden (siehe Nutzeranfrage).
const ACHIEVEMENTS: Dictionary = {
	"FIRST_STEPS": {
		"name": "Erste Schritte", "desc": "10 lebende Frettchen gleichzeitig in der Kolonie.",
		"icon": "🐣", "category": "POPULATION", "condition_type": "stat_threshold", "reward": ""
	},
	"GROWING_COLONY": {
		"name": "Wachsende Kolonie", "desc": "25 lebende Frettchen gleichzeitig in der Kolonie.",
		"icon": "🏘️", "category": "POPULATION", "condition_type": "stat_threshold", "reward": ""
	},
	"CENTURY": {
		"name": "Erste 100 Frettchen", "desc": "Insgesamt 100 Frettchen wurden im Laufe der Kolonie-Geschichte geboren.",
		"icon": "💯", "category": "POPULATION", "condition_type": "stat_threshold", "reward": ""
	},
	"FULL_HOUSES": {
		"name": "Alle Betten belegt", "desc": "Mindestens 10 Betten vorhanden, alle gleichzeitig belegt.",
		"icon": "🛏️", "category": "POPULATION", "condition_type": "stat_threshold", "reward": ""
	},
	"NO_LOSSES": {
		"name": "50 Tage ohne Verlust", "desc": "50 Tage am Stück ohne einen einzigen Frettchen-Tod.",
		"icon": "🕊️", "category": "POPULATION", "condition_type": "stat_threshold", "reward": ""
	},
	"FULL_STORAGE": {
		"name": "Gut versorgt", "desc": "500 Einheiten einer einzelnen Ressource gleichzeitig gelagert.",
		"icon": "📦", "category": "ECONOMY", "condition_type": "stat_threshold", "reward": ""
	},
	"BIG_BUILDER": {
		"name": "Baumeister", "desc": "20 Gebäude gleichzeitig auf der Karte.",
		"icon": "🏗️", "category": "ECONOMY", "condition_type": "stat_threshold", "reward": ""
	},
	"TEN_REBUILDS": {
		"name": "Modernisierer", "desc": "10 Gebäude-Umbauten abgeschlossen.",
		"icon": "🔧", "category": "ECONOMY", "condition_type": "event_flag", "reward": ""
	},
	"SCIENCE_500": {
		"name": "Gelehrte Kolonie", "desc": "Insgesamt 500 Wissenspunkte in Forschung investiert.",
		"icon": "📚", "category": "ECONOMY", "condition_type": "tech_progress", "reward": ""
	},
	"DROUGHT_SURVIVOR": {
		"name": "Dürre überstanden", "desc": "Eine komplette Dürre ohne einen einzigen Todesfall überstehen.",
		"icon": "🌵", "category": "SURVIVAL", "condition_type": "survive_disaster", "reward": ""
	},
	"WINTER_SURVIVOR": {
		"name": "Erster Winter", "desc": "Die erste Wintersaison erleben.",
		"icon": "❄️", "category": "SURVIVAL", "condition_type": "event_flag", "reward": ""
	},
	"OLD_TIMER": {
		"name": "Methusalem", "desc": "Ein Frettchen erreicht ein Alter von 60 Tagen.",
		"icon": "🦴", "category": "SURVIVAL", "condition_type": "stat_threshold", "reward": ""
	},
	"EPOCH_4": {
		"name": "Moderne Zeitalter", "desc": "Epoche 4 (Moderne) erreicht.",
		"icon": "🏭", "category": "SURVIVAL", "condition_type": "tech_progress", "reward": ""
	},
	"FIRST_EXPEDITION": {
		"name": "Aufbruch", "desc": "Die erste Expedition erfolgreich abgeschlossen.",
		"icon": "🧭", "category": "EXPLORATION", "condition_type": "event_flag", "reward": ""
	},
	"FIVE_EXPEDITIONS": {
		"name": "Vielgereist", "desc": "5 Expeditionen erfolgreich abgeschlossen.",
		"icon": "🗺️", "category": "EXPLORATION", "condition_type": "event_flag", "reward": ""
	},
	"FIRST_TECH": {
		"name": "Forschergeist", "desc": "Den ersten Tech-Knoten erforscht.",
		"icon": "🔬", "category": "TECH", "condition_type": "tech_progress", "reward": ""
	},
	"ALL_SECTIONS": {
		"name": "Universalgelehrte", "desc": "Alle 6 Themenbereiche des Tech Trees zu 100% erforscht.",
		"icon": "🎓", "category": "TECH", "condition_type": "tech_progress", "reward": ""
	},
	"FULL_TECH_TREE": {
		"name": "Meister aller Zünfte", "desc": "Alle 60 Tech-Knoten erforscht.",
		"icon": "👑", "category": "TECH", "condition_type": "tech_progress", "reward": ""
	},
}

signal achievement_unlocked_toast(id: String)

var unlocked: Array = []

# ── interne Zaehler/Snapshots (nicht Teil der ACHIEVEMENTS-Daten, aber Teil
# des Speicherstands - siehe serialize()/deserialize()) ─────────────────────
var lifetime_births: int = 0
var rebuilds_completed: int = 0
var expeditions_completed: int = 0
var last_death_day: int = 0
var drought_death_snapshot: int = -1
var seen_winter: bool = false

func init() -> void:
	unlocked = []
	lifetime_births = 0
	rebuilds_completed = 0
	expeditions_completed = 0
	last_death_day = 0
	drought_death_snapshot = -1
	seen_winter = false

func _ready() -> void:
	GameState.ferret_born.connect(_on_ferret_born)
	GameState.ferret_died.connect(_on_ferret_died)
	GameState.day_changed.connect(_on_day_changed)
	GameState.tech_unlocked.connect(_on_tech_unlocked)
	GameState.drought_started.connect(_on_drought_started)
	GameState.drought_ended.connect(_on_drought_ended)
	GameState.expedition_returned.connect(_on_expedition_returned)
	GameState.building_placed.connect(_on_building_placed)
	GameState.building_rebuilt.connect(_on_building_rebuilt)
	GameState.resource_changed.connect(_on_resource_changed)
	GameState.season_changed.connect(_on_season_changed)

# ══════════════════════════════════════════════════════════════════════════
# FREISCHALTUNG
# ══════════════════════════════════════════════════════════════════════════
func _unlock(id: String) -> void:
	if id in unlocked: return
	if not ACHIEVEMENTS.has(id): return
	unlocked.append(id)
	var ad: Dictionary = ACHIEVEMENTS[id]
	# Feature: normale, unauffaellige Notification-Zeile UND zusaetzlich ein
	# eigenes Signal fuer einen auffaelligeren Toast/Popup-Effekt (siehe
	# AchievementToast.gd) - beide Kanaele wie in der Anfrage gefordert.
	GameState.notify("🏆 Erfolg freigeschaltet: " + str(ad.get("name", id)), Color(0.55, 0.42, 0.08, 0.92))
	achievement_unlocked_toast.emit(id)

func is_unlocked(id: String) -> bool:
	return id in unlocked

func get_progress_count() -> int:
	return unlocked.size()

func get_total_count() -> int:
	return ACHIEVEMENTS.size()

func get_achievements_by_category(category: String) -> Array:
	var result: Array = []
	for aid in ACHIEVEMENTS:
		if str((ACHIEVEMENTS[aid] as Dictionary).get("category", "")) == category:
			result.append(aid)
	return result

# ══════════════════════════════════════════════════════════════════════════
# SIGNAL-HANDLER (jeweils nur die dadurch potenziell betroffenen Achievements)
# ══════════════════════════════════════════════════════════════════════════
func _on_ferret_born(_f) -> void:
	lifetime_births += 1
	if lifetime_births >= 100: _unlock("CENTURY")
	if PopMgr.ferrets.size() >= 10: _unlock("FIRST_STEPS")
	if PopMgr.ferrets.size() >= 25: _unlock("GROWING_COLONY")
	_check_full_houses()

func _on_ferret_died(_f, _cause: String) -> void:
	last_death_day = DayNight.day_count

func _on_day_changed(day: int) -> void:
	# "50 Tage am Stück ohne Frettchen-Tod" - Streak seit dem letzten Tod
	# (bzw. seit Kolonie-Start, falls noch niemand gestorben ist).
	if day - last_death_day >= 50:
		_unlock("NO_LOSSES")
	# "Methusalem" - guenstig genug, um einmal pro Spieltag ueber alle
	# lebenden Frettchen zu iterieren (kein Frame-Polling).
	for f in PopMgr.ferrets:
		var fe: FerretEntity = f
		if float(fe.age_days) >= 60.0:
			_unlock("OLD_TIMER")
			break

func _on_tech_unlocked(tid: String) -> void:
	if not str(tid).begins_with("EPOCH_"):
		_unlock("FIRST_TECH")
	if TechTreeSys.get_epoch() >= 4:
		_unlock("EPOCH_4")
	if TechTreeSys.total_spent >= 500.0:
		_unlock("SCIENCE_500")
	var all_sections_done: bool = true
	for sec in TechTreeSys.SECTION_ORDER:
		if TechTreeSys.get_section_progress(sec) < 10:
			all_sections_done = false
			break
	if all_sections_done: _unlock("ALL_SECTIONS")
	var node_count: int = 0
	for u in TechTreeSys.unlocked:
		if not str(u).begins_with("EPOCH_"): node_count += 1
	if node_count >= 60: _unlock("FULL_TECH_TREE")

func _on_drought_started() -> void:
	drought_death_snapshot = PopMgr.dead_ferrets.size()

func _on_drought_ended() -> void:
	if drought_death_snapshot >= 0 and PopMgr.dead_ferrets.size() == drought_death_snapshot:
		_unlock("DROUGHT_SURVIVOR")
	drought_death_snapshot = -1

func _on_expedition_returned(_result: Dictionary) -> void:
	expeditions_completed += 1
	if expeditions_completed >= 1: _unlock("FIRST_EXPEDITION")
	if expeditions_completed >= 5: _unlock("FIVE_EXPEDITIONS")

func _on_building_placed(_b) -> void:
	if BuildingSys.buildings.size() >= 20: _unlock("BIG_BUILDER")
	_check_full_houses()

func _on_building_rebuilt(_b) -> void:
	rebuilds_completed += 1
	if rebuilds_completed >= 10: _unlock("TEN_REBUILDS")

func _on_resource_changed(_resource: String, amount: float) -> void:
	if amount >= 500.0: _unlock("FULL_STORAGE")

func _on_season_changed(season: String) -> void:
	if season == "Winter" and not seen_winter:
		seen_winter = true
		_unlock("WINTER_SURVIVOR")

func _check_full_houses() -> void:
	var total_beds: int = BuildingSys.get_total_beds()
	if total_beds >= 10 and BuildingSys.get_occupied_beds() >= total_beds:
		_unlock("FULL_HOUSES")

# ══════════════════════════════════════════════════════════════════════════
# SPEICHERN / LADEN
# ══════════════════════════════════════════════════════════════════════════
func serialize() -> Dictionary:
	return {
		"unlocked": unlocked.duplicate(),
		"lifetime_births": lifetime_births,
		"rebuilds_completed": rebuilds_completed,
		"expeditions_completed": expeditions_completed,
		"last_death_day": last_death_day,
		"seen_winter": seen_winter,
	}

func deserialize(data) -> void:
	if not (data is Dictionary):
		init(); return
	var d: Dictionary = data as Dictionary
	unlocked = (d.get("unlocked", []) as Array).duplicate()
	lifetime_births = int(d.get("lifetime_births", 0))
	rebuilds_completed = int(d.get("rebuilds_completed", 0))
	expeditions_completed = int(d.get("expeditions_completed", 0))
	last_death_day = int(d.get("last_death_day", 0))
	seen_winter = bool(d.get("seen_winter", false))
	drought_death_snapshot = -1

## FerretEntity.gd
class_name FerretEntity
extends RefCounted

const FIRST_NAMES: Array = ["Freddy","Fido","Fiona","Franz","Frieda","Felix","Frida","Frank","Finn","Flora","Frodo","Franzi","Filou","Feli","Fips"]
const LAST_NAMES: Array  = ["Frettchen","Pfote","Flausch","Fell","Schnueffel","Huepfer","Schwanz","Nase","Kralle","Zahn"]

var ferret_name: String = ""
var health: float = 100.0
var needs: Dictionary = {"food": 60.0, "water": 60.0, "happiness": 60.0}
var assigned_building = null
var current_construction_site = null
var home = null
var specialization: String = ""
var spec_days: float = 0.0
var age_days: float = 0.0
var is_alive: bool = true
var pos: Vector2 = Vector2.ZERO
var target_pos: Vector2 = Vector2.ZERO
var move_speed: float = 2.0   # Tiles pro Sekunde

static func create_random() -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = FIRST_NAMES[randi() % FIRST_NAMES.size()] + " " + LAST_NAMES[randi() % LAST_NAMES.size()]
	f.health = randf_range(80.0, 100.0)
	f.move_speed = randf_range(1.5, 2.8)
	f.needs = {
		"food": randf_range(50.0, 80.0),
		"water": randf_range(50.0, 80.0),
		"happiness": randf_range(40.0, 70.0)
	}
	# Startposition: isometrische Weltkoordinaten nahe Karte-Mitte (Tile 30,30)
	# tile_to_world(30,30) = (0, 2880) — wir randomisieren etwas drumherum
	f.pos = Vector2(30.0 + randf_range(-4.0, 4.0), 30.0 + randf_range(-4.0, 4.0))
	f.target_pos = f.pos
	return f

func update(dt: float) -> void:
	age_days += dt / 60.0
	needs["food"] = maxf(0.0, float(needs["food"]) - dt * 0.8)
	needs["water"] = maxf(0.0, float(needs["water"]) - dt * 1.1)
	needs["happiness"] = maxf(0.0, float(needs["happiness"]) - dt * 0.4)
	var avg: float = (float(needs["food"]) + float(needs["water"])) / 2.0
	if avg < 20.0:
		health = maxf(0.0, health - dt * (20.0 - avg) * 0.1)
	elif avg > 60.0:
		health = minf(100.0, health + dt * 0.5)
	if assigned_building != null:
		var ab: BuildingEntity = assigned_building
		if not ab.is_under_construction:
			spec_days += dt / 60.0
			if spec_days >= 5.0 and specialization != ab.btype:
				specialization = ab.btype
	else:
		spec_days = 0.0
	var diff: Vector2 = target_pos - pos
	if diff.length() < 0.15:
		# Neues Wanderziel in Tile-Koordinaten
		target_pos = pos + Vector2(randf_range(-3.5, 3.5), randf_range(-3.5, 3.5))
	else:
		pos += diff.normalized() * move_speed * dt

func get_happiness() -> float:
	return float(needs["happiness"])

func serialize() -> Dictionary:
	return {
		"name": ferret_name, "health": health,
		"needs": needs.duplicate(), "age_days": age_days,
		"specialization": specialization, "spec_days": spec_days,
		"pos_x": pos.x, "pos_y": pos.y
	}

static func deserialize(data: Dictionary) -> FerretEntity:
	var f := FerretEntity.new()
	f.ferret_name = str(data.get("name", "Unbekannt"))
	f.health = float(data.get("health", 100.0))
	var n = data.get("needs", {"food": 60.0, "water": 60.0, "happiness": 60.0})
	f.needs = (n as Dictionary).duplicate()
	f.age_days = float(data.get("age_days", 0.0))
	f.specialization = str(data.get("specialization", ""))
	f.spec_days = float(data.get("spec_days", 0.0))
	# Pos: ältere Saves hatten Pixel-Koordinaten (~2880) – sicher auf Tile-Range clampen
	var raw_x: float = float(data.get("pos_x", 30.0))
	var raw_y: float = float(data.get("pos_y", 30.0))
	# Heuristik: Pixel-Koordinaten > 200 stammen aus altem Format
	if absf(raw_x) > 200.0 or absf(raw_y) > 200.0:
		raw_x = 30.0 + randf_range(-3.0, 3.0)
		raw_y = 30.0 + randf_range(-3.0, 3.0)
	f.pos = Vector2(raw_x, raw_y)
	f.target_pos = f.pos
	return f

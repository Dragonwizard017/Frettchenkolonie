## SaveSystem.gd
extends Node

const SAVE_DIR: String = "user://saves/"

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)

func get_save_names() -> Array:
	var names: Array = []
	var dir: DirAccess = DirAccess.open(SAVE_DIR)
	if dir == null: return names
	dir.list_dir_begin()
	var fname: String = dir.get_next()
	while fname != "":
		if fname.ends_with(".json"):
			names.append(fname.get_basename())
		fname = dir.get_next()
	return names

func save(slot_name: String, game_ctrl: Node) -> bool:
	var data: Dictionary = {
		"version": 5,
		"slot": slot_name,
		"timestamp": Time.get_datetime_string_from_system(),
		"world": game_ctrl.serialize_world(),
		"resources": ResourceSys.serialize(),
		"buildings": BuildingSys.serialize(),
		"population": PopMgr.serialize(),
		"day_night": DayNight.serialize(),
		"tech": TechTreeSys.serialize(),
		"drought": DroughtSys.serialize(),
		"season": SeasonSys.serialize()
	}
	var path: String = SAVE_DIR + slot_name + ".json"
	var file: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("SaveSystem: Cannot open file " + path)
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	GameState.notify("Gespeichert: " + slot_name)
	return true

func load_game(slot_name: String, game_ctrl: Node) -> bool:
	var path: String = SAVE_DIR + slot_name + ".json"
	if not FileAccess.file_exists(path):
		GameState.notify("Speicherstand nicht gefunden: " + slot_name, Color(0.8, 0.2, 0.1))
		return false
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null: return false
	var json_str: String = file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(json_str)
	if parsed == null: return false
	var data: Dictionary = parsed as Dictionary
	game_ctrl.deserialize_world(data.get("world", {}) as Dictionary)
	ResourceSys.deserialize(data.get("resources", {}) as Dictionary)
	BuildingSys.deserialize(data.get("buildings", []) as Array, game_ctrl.world)
	PopMgr.deserialize(data.get("population", {}) as Dictionary)
	DayNight.deserialize(data.get("day_night", {}) as Dictionary)
	TechTreeSys.deserialize(data.get("tech", []) as Array)
	DroughtSys.deserialize(data.get("drought", {}) as Dictionary)
	SeasonSys.deserialize(data.get("season", {}) as Dictionary)
	# Bug 5-Fix: Gebäude wurden nach deserialize_world in die Tiles geschrieben –
	# Renderer muss jetzt nochmals die Building-Nodes erzeugen.
	if game_ctrl.has_method("post_load_refresh"):
		game_ctrl.call("post_load_refresh")
	GameState.notify("Geladen: " + slot_name)
	return true

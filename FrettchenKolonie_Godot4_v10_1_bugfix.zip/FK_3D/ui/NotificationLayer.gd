## NotificationLayer.gd
## Zeigt temporäre Benachrichtigungen (entspricht notify() im HTML).
extends Control

const NOTIF_DURATION := 3.5
const MAX_NOTIFS := 5

var _notifs: Array = []

func _ready() -> void:
	GameState.notification_requested.connect(show_notification)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func show_notification(msg: String, color: Color = Color(0.18, 0.38, 0.18, 0.92)) -> void:
	# Alte entfernen wenn zu viele
	if _notifs.size() >= MAX_NOTIFS:
		var oldest = _notifs.pop_front()
		oldest.queue_free()

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 14; sb.content_margin_right = 14
	sb.content_margin_top = 6;   sb.content_margin_bottom = 6
	panel.add_theme_stylebox_override("panel", sb)

	var lbl := Label.new()
	lbl.text = msg
	lbl.add_theme_font_size_override("font_size", 14)
	lbl.add_theme_color_override("font_color", Color.WHITE)
	panel.add_child(lbl)

	add_child(panel)
	_notifs.append(panel)
	_reposition()

	# Timer zum Entfernen
	var timer := get_tree().create_timer(NOTIF_DURATION)
	timer.timeout.connect(func():
		_notifs.erase(panel)
		if is_instance_valid(panel):
			var tw := create_tween()
			tw.tween_property(panel, "modulate:a", 0.0, 0.4)
			tw.tween_callback(panel.queue_free)
		_reposition()
	)

	# Einblend-Animation
	panel.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.25)

func _reposition() -> void:
	var y := 80.0
	for n in _notifs:
		if is_instance_valid(n):
			n.position = Vector2(get_viewport_rect().size.x * 0.5 - n.size.x * 0.5, y)
			y += n.size.y + 8.0

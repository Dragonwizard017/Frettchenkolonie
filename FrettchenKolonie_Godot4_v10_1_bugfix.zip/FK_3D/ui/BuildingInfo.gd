## BuildingInfo.gd
extends PanelContainer

var _building: BuildingEntity = null
var _game_ctrl: Node = null
var _title_lbl: Label = null
var _status_lbl: Label = null
var _workers_lbl: Label = null
var _progress_bar: ProgressBar = null
var _upgrade_btn: Button = null
var _sell_btn: Button = null
var _priority_slider: HSlider = null
var _priority_label: Label = null
var _desc_label: Label = null

func _ready() -> void:
	hide()
	_title_lbl      = get_node_or_null("VBox/TitleRow/TitleLabel")
	_status_lbl     = get_node_or_null("VBox/StatusLabel")
	_workers_lbl    = get_node_or_null("VBox/WorkersLabel")
	_progress_bar   = get_node_or_null("VBox/ProgressBar")
	_upgrade_btn    = get_node_or_null("VBox/Buttons/UpgradeBtn")
	_sell_btn       = get_node_or_null("VBox/Buttons/SellBtn")
	_priority_slider = get_node_or_null("VBox/PriorityRow/PrioritySlider")
	_priority_label = get_node_or_null("VBox/PriorityRow/PriorityLabel")
	_desc_label     = get_node_or_null("VBox/DescLabel")
	var close: Button = get_node_or_null("VBox/TitleRow/CloseBtn")
	if close: close.pressed.connect(func(): GameState.building_deselected.emit())
	if _sell_btn:    _sell_btn.pressed.connect(_on_sell)
	if _upgrade_btn: _upgrade_btn.pressed.connect(_on_upgrade)
	if _priority_slider: _priority_slider.value_changed.connect(func(v): if _building: _building.work_priority = int(v))

func set_game_controller(gc: Node) -> void:
	_game_ctrl = gc

func show_building(b: BuildingEntity, gc: Node) -> void:
	_building = b; _game_ctrl = gc; show(); _refresh()

func _process(_dt: float) -> void:
	if visible and _building != null: _refresh()

func _refresh() -> void:
	if _building == null: return
	if _title_lbl: _title_lbl.text = "%s %s (Stufe %d)" % [_building.icon, _building.name, _building.level]
	if _status_lbl:
		if _building.is_under_construction:
			_status_lbl.text = "Im Bau... %d%%" % int(_building.construction_progress / maxf(1.0, _building.construction_work_needed) * 100.0)
		else:
			_status_lbl.text = "Aktiv" if _building.is_active else "Inaktiv"
	if _workers_lbl:
		_workers_lbl.text = "Arbeiter: %d/%d" % [_building.assigned_workers.size(), _building.max_workers] if _building.max_workers > 0 else ""
	if _progress_bar:
		if _building.is_under_construction:
			_progress_bar.value = _building.construction_progress / maxf(1.0, _building.construction_work_needed) * 100.0; _progress_bar.show()
		elif _building.produces != "" or not _building.recipes.is_empty():
			var ct: float = float(BuildingData.PRODUCTION_CHAINS.get(_building.produces,{}).get("time",5.0))
			_progress_bar.value = _building.production_progress / ct * 100.0; _progress_bar.show()
		else: _progress_bar.hide()
	if _upgrade_btn:
		var uc: Dictionary = _building.get_upgrade_costs()
		_upgrade_btn.text = "Max. Stufe" if uc.is_empty() else "Upgrade (%s)" % _costs_str(uc)
		_upgrade_btn.disabled = uc.is_empty() or not ResourceSys.can_afford(uc)
	if _sell_btn:
		var rd: Dictionary = {}
		for r in _building.costs: rd[r] = int(float(_building.costs[r]) * 0.7)
		_sell_btn.text = "Verkaufen (%s)" % _costs_str(rd)
	if _priority_slider and _building.max_workers > 0:
		_priority_slider.show(); if _priority_label: _priority_label.show()
		_priority_slider.set_value_no_signal(float(_building.work_priority))
		if _priority_label: _priority_label.text = "Prioritaet: %d" % _building.work_priority
	elif _priority_slider:
		_priority_slider.hide(); if _priority_label: _priority_label.hide()
	if _desc_label:
		var desc: String = str(BuildingData.BUILDINGS.get(_building.id,{}).get("desc",""))
		_desc_label.text = desc; _desc_label.visible = desc != ""

func _costs_str(costs: Dictionary) -> String:
	var parts: Array = []
	for r in costs: parts.append(str(BuildingData.RESOURCE_ICONS.get(str(r),"?"))+str(costs[r]))
	return " ".join(parts)

func _on_sell() -> void:
	if _game_ctrl and _game_ctrl.has_method("sell_selected_building"): _game_ctrl.call("sell_selected_building")
	hide()

func _on_upgrade() -> void:
	if _game_ctrl and _game_ctrl.has_method("upgrade_selected_building"): _game_ctrl.call("upgrade_selected_building")

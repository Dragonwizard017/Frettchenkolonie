## PopulationManager.gd
extends Node

var ferrets: Array = []
var dead_ferrets: Array = []
var total_happiness: float = 50.0
var growth_timer: float = 0.0
var _death_count: int = 0
var _last_death_count: int = 0

func init(start_pop: int = 5) -> void:
	ferrets = []
	dead_ferrets = []
	total_happiness = 50.0
	growth_timer = 0.0
	_death_count = 0
	_last_death_count = 0
	for _i in start_pop:
		var f: FerretEntity = FerretEntity.create_random()
		# Tile-Koordinaten: Kartenmitte = (30, 30)
		f.pos = Vector2(30.0 + randf_range(-4.0, 4.0), 30.0 + randf_range(-4.0, 4.0))
		f.target_pos = f.pos
		ferrets.append(f)

func update(dt: float, is_day: bool) -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		fe.update(dt)

	# Nahrung konsumieren
	if not ferrets.is_empty():
		var eat_options: Array = [
			{"r": "STEW",        "eff": 8.0},
			{"r": "COOKED_MEAT", "eff": 6.0},
			{"r": "BREAD",       "eff": 5.0},
			{"r": "FOOD",        "eff": 5.0},
			{"r": "BERRIES",     "eff": 3.0},
			{"r": "MEAT",        "eff": 2.0}
		]
		for opt in eat_options:
			var opt_d: Dictionary = opt
			var res: String = str(opt_d["r"])
			var eff: float = float(opt_d["eff"])
			var avail: float = float(ResourceSys.resources.get(res, 0.0))
			if avail < 0.5: continue
			var consume: float = minf(avail, float(ferrets.size()) * 0.01 * dt)
			ResourceSys.remove(res, consume)
			var per_f: float = (consume / float(ferrets.size())) * eff
			for fv in ferrets:
				var fe: FerretEntity = fv
				fe.needs["food"] = minf(100.0, float(fe.needs["food"]) + per_f)
			break

		# Wasser
		var w_avail: float = ResourceSys.water
		if w_avail > 0.0:
			var consume: float = minf(w_avail, float(ferrets.size()) * 0.018 * dt)
			ResourceSys.remove_water(consume)
			var per_f: float = (consume / float(ferrets.size())) * 4.0
			for fv in ferrets:
				var fe: FerretEntity = fv
				fe.needs["water"] = minf(100.0, float(fe.needs["water"]) + per_f)

	_calculate_happiness()
	if is_day:
		_assign_work()

	# Tote entfernen
	var prev_size: int = ferrets.size()
	var to_die: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.health <= 0.0: to_die.append(fe)
	for f in to_die:
		_kill_ferret(f, "Hunger/Durst")
	var alive: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.health > 0.0: alive.append(fe)
	ferrets = alive

	if ferrets.size() < prev_size:
		_death_count += prev_size - ferrets.size()
	if _death_count != _last_death_count:
		SoundSys.play_death()
		_last_death_count = _death_count

	growth_timer += dt
	if growth_timer > 90.0 and is_day:
		growth_timer = 0.0
		_try_grow()

	if ferrets.is_empty() and dead_ferrets.size() > 0:
		GameState.game_over_triggered.emit("Alle Frettchen sind gestorben!")

func _kill_ferret(f: FerretEntity, cause: String) -> void:
	f.is_alive = false
	if f.assigned_building != null:
		var ab: BuildingEntity = f.assigned_building
		ab.remove_worker(f)
	if f.home != null:
		var hb: BuildingEntity = f.home
		hb.residents.erase(f)
	dead_ferrets.append({
		"name": f.ferret_name, "cause": cause,
		"day": DayNight.day_count, "age": int(f.age_days)
	})
	GameState.ferret_died.emit(f, cause)

func _calculate_happiness() -> void:
	if ferrets.is_empty():
		total_happiness = 50.0; return
	var base: float = 0.0
	for f in ferrets:
		var fe: FerretEntity = f
		base += (float(fe.needs["food"]) + float(fe.needs["water"]) + float(fe.needs["happiness"])) / 3.0
	total_happiness = base / float(ferrets.size())

func _assign_work() -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.assigned_building != null: continue
		if fe.current_construction_site != null: continue
		var best: BuildingEntity = null
		var best_pri: int = -1
		for b in BuildingSys.buildings:
			var be: BuildingEntity = b
			if be.is_under_construction: continue
			if be.btype in ["STORAGE","HAPPINESS","DECO","GRAVEYARD","HOUSING"]: continue
			if be.assigned_workers.size() >= be.max_workers: continue
			if be.work_priority > best_pri:
				best_pri = be.work_priority
				best = be
		if best != null:
			best.assign_worker(fe)

func _try_grow() -> void:
	var free_beds: int = BuildingSys.get_total_beds() - BuildingSys.get_occupied_beds()
	if free_beds <= 0: return
	var has_food: bool = (
		float(ResourceSys.resources.get("FOOD", 0.0)) > 5.0 or
		float(ResourceSys.resources.get("BERRIES", 0.0)) > 15.0 or
		float(ResourceSys.resources.get("STEW", 0.0)) > 2.0 or
		float(ResourceSys.resources.get("BREAD", 0.0)) > 3.0 or
		float(ResourceSys.resources.get("COOKED_MEAT", 0.0)) > 3.0
	)
	if not has_food: return
	if total_happiness < 50.0: return
	var f: FerretEntity = FerretEntity.create_random()
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if be.btype == "HOUSING" and not be.is_under_construction:
			if be.residents.size() < be.max_residents:
				be.residents.append(f)
				f.home = be; break
	ferrets.append(f)
	GameState.ferret_born.emit(f)
	SoundSys.play_born()
	GameState.notify("Ein neues Frettchen ist geboren!")

func get_count() -> int:
	return ferrets.size()

func serialize() -> Dictionary:
	var f_data: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		f_data.append(fe.serialize())
	return {"ferrets": f_data, "dead": dead_ferrets.duplicate(true)}

func deserialize(data: Dictionary) -> void:
	ferrets = []
	var dead = data.get("dead", [])
	dead_ferrets = (dead as Array).duplicate(true)
	var flist = data.get("ferrets", [])
	for fd in flist:
		ferrets.append(FerretEntity.deserialize(fd as Dictionary))

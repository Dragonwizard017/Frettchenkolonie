## TechTree.gd
extends Node

var nodes: Dictionary = {}
var unlocked: Array = []

func init() -> void:
	unlocked = []
	_build_tree()
	unlock("EPOCH_1")

func _build_tree() -> void:
	nodes = {
		"EPOCH_1": {
			"name": "Steinzeit", "epoch": 1, "costs": {},
			"unlocks": ["CONSTRUCTION_YARD_1","LUMBERJACK","QUARRY","BERRY_GATHERER",
				"WELL","STORAGE","HOUSE","GATHERING_PLACE","FORESTER","GRAVEYARD",
				"DECO_FLOWERS","DECO_MUSHROOM","DECO_STONES","DECO_BUSH","DIRT","STONE_PATH"],
			"requires": []
		},
		"EPOCH_2": {
			"name": "Mittelalter", "epoch": 2,
			"costs": {"PLANKS": 50, "STONE": 40, "TOOLS": 10},
			"unlocks": ["CONSTRUCTION_YARD_2","SAWMILL","WORKSHOP","WATER_TOWER","TAVERN",
				"GARDEN","LARGE_STORAGE","CROP_FIELD","WATER_PUMP","RESERVOIR",
				"FOOD_STORE","WATERWHEEL","BATHHOUSE","EXPEDITION_CAMP",
				"COOKHOUSE","DYNAMITE_WORKSHOP","WHEAT_FARM","HUNTER_HUT","DECO_LANTERN",
				"STONE","PLANKS_PATH"],
			"requires": ["EPOCH_1"]
		},
		"EPOCH_3": {
			"name": "Industrialisierung", "epoch": 3,
			"costs": {"PLANKS": 100, "STONE": 80, "IRON_BARS": 30, "TOOLS": 20},
			"unlocks": ["ENGINEERS_GUILD","IRON_MINE","COAL_MINE","SMELTER",
				"AQUEDUCT","THEATER","WAREHOUSE","IRRIGATION"],
			"requires": ["EPOCH_2"]
		},
		"EPOCH_4": {
			"name": "Moderne", "epoch": 4,
			"costs": {"IRON_BARS": 80, "MACHINES": 20, "STEEL": 30},
			"unlocks": ["CONSTRUCTION_OFFICE","MACHINE_FACTORY","BLAST_FURNACE","STATUE"],
			"requires": ["EPOCH_3"]
		}
	}

func unlock(tech_id: String) -> bool:
	if tech_id in unlocked: return false
	if not nodes.has(tech_id): return false
	var node_data: Dictionary = nodes[tech_id]
	var reqs = node_data.get("requires", [])
	for req in reqs:
		if not (str(req) in unlocked): return false
	var costs = node_data.get("costs", {})
	if not ResourceSys.can_afford(costs as Dictionary): return false
	ResourceSys.spend(costs as Dictionary)
	unlocked.append(tech_id)
	GameState.tech_unlocked.emit(tech_id)
	GameState.notify("Epoche freigeschaltet: " + str(node_data.get("name", tech_id)))
	GameState.build_menu_update_requested.emit()
	return true

func can_unlock(tech_id: String) -> bool:
	if tech_id in unlocked: return false
	if not nodes.has(tech_id): return false
	var node_data: Dictionary = nodes[tech_id]
	var reqs = node_data.get("requires", [])
	for req in reqs:
		if not (str(req) in unlocked): return false
	var costs = node_data.get("costs", {})
	return ResourceSys.can_afford(costs as Dictionary)

func get_unlocked_buildings() -> Array:
	var result: Array = []
	for tid in unlocked:
		if not nodes.has(tid): continue
		var nd: Dictionary = nodes[tid]
		var ul = nd.get("unlocks", [])
		for bid in ul:
			result.append(str(bid))
	return result

func get_epoch() -> int:
	var max_e: int = 1
	for tid in unlocked:
		if not nodes.has(tid): continue
		var nd: Dictionary = nodes[tid]
		var e: int = int(nd.get("epoch", 1))
		if e > max_e: max_e = e
	return max_e

func serialize() -> Array:
	return unlocked.duplicate()

func deserialize(data: Array) -> void:
	unlocked = []
	_build_tree()
	for tid in data:
		if not (str(tid) in unlocked):
			unlocked.append(str(tid))

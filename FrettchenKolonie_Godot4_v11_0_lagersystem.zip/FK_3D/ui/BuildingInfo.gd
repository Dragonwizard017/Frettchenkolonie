## BuildingInfo.gd
extends PanelContainer

var _building: BuildingEntity = null
var _game_ctrl: Node = null
var _title_lbl: Label = null
var _status_lbl: Label = null
var _workers_lbl: Label = null
var _worker_minus_btn: Button = null
var _worker_plus_btn: Button = null
var _progress_bar: ProgressBar = null
var _upgrade_btn: Button = null
var _sell_btn: Button = null
var _priority_slider: HSlider = null
var _priority_label: Label = null
var _desc_label: Label = null

func _ready() -> void:
	hide()
	_title_lbl      = get_node_or_null("VBox/TitleRow/TitleLabel")
	_status_lbl     = get_node_or_null("VBox/StatusLabel")
	_workers_lbl    = get_node_or_null("VBox/WorkerRow/WorkersLabel")
	_worker_minus_btn = get_node_or_null("VBox/WorkerRow/WorkerMinusBtn")
	_worker_plus_btn  = get_node_or_null("VBox/WorkerRow/WorkerPlusBtn")
	_progress_bar   = get_node_or_null("VBox/ProgressBar")
	_upgrade_btn    = get_node_or_null("VBox/Buttons/UpgradeBtn")
	_sell_btn       = get_node_or_null("VBox/Buttons/SellBtn")
	_priority_slider = get_node_or_null("VBox/PriorityRow/PrioritySlider")
	_priority_label = get_node_or_null("VBox/PriorityRow/PriorityLabel")
	_desc_label     = get_node_or_null("VBox/DescLabel")
	var close: Button = get_node_or_null("VBox/TitleRow/CloseBtn")
	if close: close.pressed.connect(func(): GameState.building_deselected.emit())
	if _sell_btn:    _sell_btn.pressed.connect(_on_sell)
	if _upgrade_btn: _upgrade_btn.pressed.connect(_on_upgrade)
	if _priority_slider: _priority_slider.value_changed.connect(func(v): if _building: _building.work_priority = int(v))
	if _worker_minus_btn: _worker_minus_btn.pressed.connect(_on_worker_minus)
	if _worker_plus_btn:  _worker_plus_btn.pressed.connect(_on_worker_plus)

func set_game_controller(gc: Node) -> void:
	_game_ctrl = gc

func show_building(b: BuildingEntity, gc: Node) -> void:
	_building = b; _game_ctrl = gc; show(); _refresh()

func _process(_dt: float) -> void:
	if visible and _building != null: _refresh()

func _refresh() -> void:
	if _building == null: return
	if _title_lbl: _title_lbl.text = "%s %s (Stufe %d)" % [_building.icon, _building.name, _building.level]
	if _status_lbl:
		if _building.is_under_construction:
			# Feature (v11.0): solange noch Baumaterial fehlt, gibt es noch
			# gar keinen "echten" Baufortschritt (siehe GameController.
			# _process_construction()) - die Status-Zeile zeigt das jetzt
			# klar an, statt einfach bei 0% zu verharren.
			if not _building.is_fully_supplied():
				_status_lbl.text = "Wartet auf Material: %s" % _missing_str(_building)
			else:
				_status_lbl.text = "Im Bau... %d%%" % int(_building.construction_progress / maxf(1.0, _building.construction_work_needed) * 100.0)
		elif _building.local_storage_capacity > 0.0:
			# Feature (v11.0): Lager-Fuellstand des Gebaeudes selbst (siehe
			# Anfrage: "muss irgendwie am Herstellungsgebaeude angezeigt
			# werden, weil die Resourcen dort gelagert werden").
			var stored: int = int(_building.get_local_storage_total())
			var cap: int = int(_building.local_storage_capacity)
			var status: String = "Aktiv" if _building.is_active else "Inaktiv"
			_status_lbl.text = "%s | Lager: %d/%d" % [status, stored, cap]
		else:
			_status_lbl.text = "Aktiv" if _building.is_active else "Inaktiv"
	if _workers_lbl:
		_workers_lbl.text = "Arbeiter: %d/%d" % [_building.assigned_workers.size(), _building.get_effective_worker_cap()] if _building.max_workers > 0 else ""
	if _worker_minus_btn or _worker_plus_btn:
		var show_controls: bool = _building.max_workers > 0 and not _building.is_under_construction
		if _worker_minus_btn:
			_worker_minus_btn.visible = show_controls
			_worker_minus_btn.disabled = _building.get_effective_worker_cap() <= 0
		if _worker_plus_btn:
			_worker_plus_btn.visible = show_controls
			_worker_plus_btn.disabled = _building.get_effective_worker_cap() >= _building.max_workers
	if _progress_bar:
		if _building.is_under_construction:
			_progress_bar.value = _building.construction_progress / maxf(1.0, _building.construction_work_needed) * 100.0; _progress_bar.show()
		elif _building.produces != "" or not _building.recipes.is_empty():
			var ct: float = float(BuildingData.PRODUCTION_CHAINS.get(_building.produces,{}).get("time",5.0))
			_progress_bar.value = _building.production_progress / ct * 100.0; _progress_bar.show()
		else: _progress_bar.hide()
	if _upgrade_btn:
		var uc: Dictionary = _building.get_upgrade_costs()
		_upgrade_btn.text = "Max. Stufe" if uc.is_empty() else "Upgrade (%s)" % _costs_str(uc)
		_upgrade_btn.disabled = uc.is_empty() or not ResourceSys.can_afford(uc)
	if _sell_btn:
		# Feature (v11.0): Erstattung basiert jetzt auf tatsaechlich
		# angeliefertem Material (delivered_resources), nicht mehr auf den
		# vollen Baukosten - siehe BuildingSystem.sell().
		var rd: Dictionary = {}
		var src: Dictionary = _building.delivered_resources if _building.is_under_construction else _building.costs
		for r in src: rd[r] = int(float(src[r]) * 0.7)
		_sell_btn.text = "Verkaufen (%s)" % _costs_str(rd)
	if _priority_slider and _building.max_workers > 0:
		_priority_slider.show(); if _priority_label: _priority_label.show()
		_priority_slider.set_value_no_signal(float(_building.work_priority))
		if _priority_label: _priority_label.text = "Prioritaet: %d" % _building.work_priority
	elif _priority_slider:
		_priority_slider.hide(); if _priority_label: _priority_label.hide()
	if _desc_label:
		var desc: String = str(BuildingData.BUILDINGS.get(_building.id,{}).get("desc",""))
		_desc_label.text = desc; _desc_label.visible = desc != ""

func _costs_str(costs: Dictionary) -> String:
	var parts: Array = []
	for r in costs: parts.append(str(BuildingData.RESOURCE_ICONS.get(str(r),"?"))+str(costs[r]))
	return " ".join(parts)

## Feature (v11.0): zeigt, was an einer Baustelle noch fehlt, z.B. "🪵15 🪨0"
## - macht sichtbar, worauf Bau-/Lagerfrettchen gerade warten.
func _missing_str(b: BuildingEntity) -> String:
	var parts: Array = []
	for r in b.costs:
		var missing: float = b.get_missing_amount(str(r))
		if missing > 0.01:
			parts.append(str(BuildingData.RESOURCE_ICONS.get(str(r),"?"))+str(int(ceil(missing))))
	return " ".join(parts) if not parts.is_empty() else "-"

func _on_sell() -> void:
	if _game_ctrl and _game_ctrl.has_method("sell_selected_building"): _game_ctrl.call("sell_selected_building")
	hide()

func _on_upgrade() -> void:
	if _game_ctrl and _game_ctrl.has_method("upgrade_selected_building"): _game_ctrl.call("upgrade_selected_building")

func _on_worker_minus() -> void:
	if _building == null: return
	_building.set_worker_cap(_building.get_effective_worker_cap() - 1)

func _on_worker_plus() -> void:
	if _building == null: return
	_building.set_worker_cap(_building.get_effective_worker_cap() + 1)
	PopMgr.try_fill_building(_building)

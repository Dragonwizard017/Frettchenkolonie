## ResourceSystem.gd
extends Node

# Bug-Fix (v10.10): BASE_STORAGE_CAPACITY war 80.0, obwohl die Start-
# Ressourcen (WOOD 50 + STONE 30 + BERRIES 20 = 100) das bereits ueberschreiten.
# get_free_space() = max(0, capacity - total_stored) war dadurch von Anfang an
# IMMER 0 - jede Produktion (add()) lief seither komplett leer, bis genug
# STORAGE-Gebaeude gebaut waren, um die Kapazitaet ueber 100 zu heben. Das war
# der Hauptgrund fuer "Gebaeude gebaut, aber keine Ressourcen produziert".
# Jetzt mit spuerbarem Puffer ueber den Startressourcen.
const BASE_STORAGE_CAPACITY: float = 150.0

var resources: Dictionary = {}
var water: float = 20.0
var water_capacity: float = 50.0
var storage_capacity: float = BASE_STORAGE_CAPACITY

func init() -> void:
	resources = {
		"WOOD": 50.0, "STONE": 30.0, "BERRIES": 20.0,
		"PLANKS": 0.0, "TOOLS": 0.0, "FOOD": 0.0,
		"IRON": 0.0, "IRON_BARS": 0.0, "MACHINES": 0.0,
		"COAL": 0.0, "STEEL": 0.0, "MEAT": 0.0,
		"DYNAMITE": 0.0, "WHEAT": 0.0, "COOKED_MEAT": 0.0,
		"BREAD": 0.0, "STEW": 0.0
	}
	water = 20.0
	water_capacity = 50.0
	storage_capacity = BASE_STORAGE_CAPACITY

func add_water(amount: float) -> void:
	water = minf(water_capacity, water + amount)

func remove_water(amount: float) -> float:
	var actual: float = minf(water, amount)
	water = maxf(0.0, water - actual)
	return actual

func has_water(amount: float) -> bool:
	return water >= amount

func update_water_capacity(buildings: Array) -> void:
	var cap: float = 50.0
	for b in buildings:
		var be: BuildingEntity = b
		if not be.is_under_construction:
			cap += be.water_capacity
	water_capacity = cap

func get_total_stored() -> float:
	var total: float = 0.0
	for key in resources:
		total += float(resources[key])
	return total

func get_free_space() -> float:
	return maxf(0.0, storage_capacity - get_total_stored())

func update_capacity(buildings: Array) -> void:
	var cap: float = BASE_STORAGE_CAPACITY
	for b in buildings:
		var be: BuildingEntity = b
		if not be.is_under_construction:
			cap += be.storage_capacity
	storage_capacity = cap

func add(res_type: String, amount: float) -> float:
	if not resources.has(res_type):
		return 0.0
	var free: float = get_free_space()
	var to_add: float = minf(amount, free)
	if to_add > 0.0:
		resources[res_type] = float(resources[res_type]) + to_add
		GameState.resource_changed.emit(res_type, float(resources[res_type]))
	return to_add

func force_add(res_type: String, amount: float) -> void:
	if resources.has(res_type):
		resources[res_type] = float(resources[res_type]) + amount

func remove(res_type: String, amount: float) -> bool:
	if has(res_type, amount):
		resources[res_type] = float(resources[res_type]) - amount
		GameState.resource_changed.emit(res_type, float(resources[res_type]))
		return true
	return false

func has(res_type: String, amount: float) -> bool:
	return float(resources.get(res_type, 0.0)) >= amount

func can_afford(costs: Dictionary) -> bool:
	for res in costs:
		if res == "WATER":
			if not has_water(float(costs[res])): return false
		elif not has(res, float(costs[res])): return false
	return true

func spend(costs: Dictionary) -> bool:
	if not can_afford(costs): return false
	for res in costs:
		if res == "WATER": remove_water(float(costs[res]))
		else: remove(res, float(costs[res]))
	return true

func can_produce(output: String) -> bool:
	var chains: Dictionary = BuildingData.PRODUCTION_CHAINS
	if not chains.has(output): return false
	var chain: Dictionary = chains[output]
	var inputs: Dictionary = chain["inputs"]
	for res in inputs:
		if not has(res, float(inputs[res])): return false
	return true

func produce(output: String) -> bool:
	if not can_produce(output): return false
	var chain: Dictionary = BuildingData.PRODUCTION_CHAINS[output]
	var inputs: Dictionary = chain["inputs"]
	for res in inputs:
		remove(res, float(inputs[res]))
	add(output, float(chain["output"]))
	return true

func serialize() -> Dictionary:
	return {
		"resources": resources.duplicate(),
		"water": water,
		"water_capacity": water_capacity,
		"storage_capacity": storage_capacity
	}

func deserialize(data: Dictionary) -> void:
	resources = data.get("resources", {}).duplicate()
	water = float(data.get("water", 20.0))
	water_capacity = float(data.get("water_capacity", 50.0))
	storage_capacity = float(data.get("storage_capacity", BASE_STORAGE_CAPACITY))

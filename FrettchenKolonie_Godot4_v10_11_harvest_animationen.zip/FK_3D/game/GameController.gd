## GameController.gd  –  3D-Version
## Kamera = Camera3D mit orthographischer Projektion (klassische Iso-Perspektive).
## Kamerabewegung per WASD / Rechtsklick-Drag.
## Klick-Auswahl per PhysicsRaycast auf Terrain + Gebäude.
extends Node3D

var renderer: WorldRenderer3D = null
var camera:   Camera3D        = null

var world:     Array          = []
var world_gen: WorldGenerator = null
var explosions: Array         = []

# ── Kamera-State ──────────────────────────────────────────────────────────────
const CAM_SPEED:   float = 14.0
const ZOOM_MIN:    float = 12.0
const ZOOM_MAX:    float = 60.0
const ZOOM_STEP:   float = 3.0
const CAM_ANGLE_X: float = -52.0
const CAM_ANGLE_Y: float =  45.0

var _cam_zoom:   float   = 28.0
var _cam_target: Vector3 = Vector3.ZERO

# ── Drag-State ────────────────────────────────────────────────────────────────
var _is_right_drag:  bool    = false
var _drag_world_hit: Vector3 = Vector3.ZERO
var _touch_moved:    bool    = false
var _path_dragging:  bool    = false
var _day_prev:       int     = -1

# ══════════════════════════════════════════════════════════════════════════════
func _ready() -> void:
	renderer = get_node("WorldRenderer3D") as WorldRenderer3D
	camera   = get_node("Camera3D") as Camera3D
	_connect_signals()

func _connect_signals() -> void:
	# Bug7-Fix: Guard gegen doppelte Verbindungen beim Neu-Starten
	if GameState.notification_requested.is_connected(_on_notification): return
	GameState.notification_requested.connect(_on_notification)
	GameState.hud_update_requested.connect(_on_hud_update)
	GameState.build_menu_update_requested.connect(_on_build_menu_update)
	GameState.building_selected.connect(_on_building_selected)
	GameState.building_deselected.connect(_on_building_deselected)
	GameState.game_over_triggered.connect(_on_game_over)
	GameState.placement_mode_changed.connect(_on_placement_mode_changed)

func start_new_game(world_size: String, seed_str: String, _world_name: String) -> void:
	world_gen = WorldGenerator.new()
	world     = world_gen.generate(world_size, seed_str)
	ResourceSys.init(); BuildingSys.init(); PopMgr.init(5)
	DayNight.init(); TechTreeSys.init(); DroughtSys.init()
	SeasonSys.init(); ExpeditionSys.init()
	WaterSys.init(world, world_gen.w, world_gen.h)
	explosions = []; _day_prev = -1
	@warning_ignore("integer_division")
	var cx: int = world_gen.w / 2; var cy: int = world_gen.h / 2
	BuildingSys.build_free("CONSTRUCTION_YARD_1", cx, cy, world)
	_setup_renderer()
	_cam_target = renderer.tile_to_world3d(cx, cy); _cam_target.y = 0.0
	_apply_camera()
	GameState.set_state(GameState.State.PLAYING); SoundSys.start_music()
	GameState.notify("Willkommen in deiner Kolonie!")
	_on_hud_update(); _on_build_menu_update()

func _setup_renderer() -> void:
	if renderer == null: renderer = get_node_or_null("WorldRenderer3D") as WorldRenderer3D
	renderer.world = world; renderer.world_w = world_gen.w; renderer.world_h = world_gen.h
	renderer.build_world()

func _apply_camera() -> void:
	if camera == null: return
	camera.size = _cam_zoom
	var dist: float = _cam_zoom * 1.8
	var rad_y: float = deg_to_rad(CAM_ANGLE_Y); var rad_x: float = deg_to_rad(CAM_ANGLE_X)
	var dx: float = cos(-rad_x) * sin(rad_y); var dy: float = sin(-rad_x)
	var dz: float = cos(-rad_x) * cos(rad_y)
	camera.position = _cam_target + Vector3(dx, dy, dz) * dist
	camera.look_at(_cam_target, Vector3.UP)

# ══════════════════════════════════════════════════════════════════════════════
func _process(delta: float) -> void:
	if not GameState.is_playing(): return
	var dt: float = delta * GameState.game_speed * SeasonSys.production_multiplier
	_handle_camera_keys(delta)
	DayNight.update(dt); DroughtSys.update(dt)
	WaterSys.update(dt, world)
	if _day_prev != DayNight.day_count:
		_day_prev = DayNight.day_count
		SeasonSys.update(DayNight.day_count)
		renderer.refresh_buildings()
	if DroughtSys.is_drought:
		var extra: float = float(PopMgr.get_count()) * 0.03 * dt
		ResourceSys.remove_water(extra)
		if ResourceSys.water < 1.0:
			for f in PopMgr.ferrets:
				var fe: FerretEntity = f as FerretEntity
				fe.needs["water"] = maxf(0.0, float(fe.needs["water"]) - 2.0 * dt)
	BuildingSys.update(dt, DayNight.is_day, world)
	PopMgr.update(dt, DayNight.is_day, world); ExpeditionSys.update(dt)
	# Bug-Fix (Gebäude werden nicht gebaut/kein Baufortschritt): vorher lief
	# dieser Aufruf NUR beim Tageswechsel (alle 180 Sekunden!) und addierte
	# einen einmaligen Sprung - der Fortschrittsbalken stand fast immer
	# still. Jetzt läuft die Konstruktion JEDEN Frame kontinuierlich weiter.
	_process_construction(dt)
	renderer.apply_drought(DroughtSys.is_drought)
	renderer.update_ferrets(PopMgr.ferrets)
	# Wasserphysik: Oberflaechen-Mesh nur gedrosselt neu bauen (kein voller
	# Terrain-Rebuild, aber trotzdem zu teuer fuer jeden einzelnen Frame) -
	# ca. 3x/Sekunde reicht aus, um Fluss/Verdunstung sichtbar zu machen.
	if Engine.get_process_frames() % 20 == 0: renderer.refresh_water(world)
	if Engine.get_process_frames() % 30 == 0: renderer.refresh_vegetation()
	if Engine.get_process_frames() % 60 == 0: _on_hud_update()

## Bug-Fix (Gebäude werden nicht gebaut/kein Baufortschritt): Bisher hing
## JEDER Baufortschritt komplett davon ab, dass mindestens ein Frettchen
## explizit im Bauhof (Typ "BUILDER") arbeitete - ohne das blieb
## construction_progress für immer bei 0, ohne jede Rückmeldung an den
## Spieler. Jetzt gibt es einen garantierten Grundfortschritt (die
## Kolonie baut auch ohne zugewiesene Bauhof-Arbeiter irgendwann fertig),
## plus einen Bonus pro Bauhof-Arbeiter für schnelleren Bau.
func _process_construction(dt: float) -> void:
	if dt <= 0.0: return
	const BASE_RATE: float   = 0.35  # Fortschritt/Sek auch ohne Bauhof-Arbeiter
	const WORKER_RATE: float = 0.5   # zusätzlich je zugewiesenem Bauhof-Arbeiter/Sek
	var worker_count: int = 0
	for byard in BuildingSys.get_builders():
		var by: BuildingEntity = byard as BuildingEntity
		worker_count += by.assigned_workers.size()
	var rate: float = BASE_RATE + float(worker_count) * WORKER_RATE
	for site in BuildingSys.get_construction_sites():
		var s: BuildingEntity = site as BuildingEntity
		s.construction_progress = minf(s.construction_work_needed, s.construction_progress + rate * dt)
		if s.construction_progress >= s.construction_work_needed:
			s.is_under_construction = false
			# Bug6-Fix: assigned_builder ist BuildingEntity – kein current_construction_site-Feld
			s.assigned_builder = null
			SoundSys.play_notify()
			GameState.notify("%s fertig gebaut!" % s.name)

# ══════════════════════════════════════════════════════════════════════════════
# KAMERA
# ══════════════════════════════════════════════════════════════════════════════
func _handle_camera_keys(delta: float) -> void:
	if camera == null: return
	var basis := camera.global_transform.basis
	var cam_right := Vector3(basis.x.x, 0.0, basis.x.z).normalized()
	var cam_fwd   := Vector3(-basis.z.x, 0.0, -basis.z.z).normalized()
	var move := Vector3.ZERO
	if Input.is_action_pressed("move_right"): move += cam_right
	if Input.is_action_pressed("move_left"):  move -= cam_right
	if Input.is_action_pressed("move_down"):  move -= cam_fwd
	if Input.is_action_pressed("move_up"):    move += cam_fwd
	if move != Vector3.ZERO:
		_cam_target += move.normalized() * CAM_SPEED * delta; _apply_camera()

# ══════════════════════════════════════════════════════════════════════════════
# INPUT
# ══════════════════════════════════════════════════════════════════════════════
func _input(event: InputEvent) -> void:
	if not GameState.is_playing(): return
	if event is InputEventKey and (event as InputEventKey).pressed:
		match (event as InputEventKey).keycode:
			KEY_ESCAPE:
				if not GameState.placement_mode.is_empty(): GameState.cancel_placement()
				else: _toggle_pause()
			KEY_SPACE: GameState.toggle_pause()
			KEY_1: GameState.set_game_speed(1.0)
			KEY_2: GameState.set_game_speed(2.0)
			KEY_3: GameState.set_game_speed(3.0)
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		match mb.button_index:
			MOUSE_BUTTON_WHEEL_UP:
				_cam_zoom = clampf(_cam_zoom - ZOOM_STEP, ZOOM_MIN, ZOOM_MAX); _apply_camera()
			MOUSE_BUTTON_WHEEL_DOWN:
				_cam_zoom = clampf(_cam_zoom + ZOOM_STEP, ZOOM_MIN, ZOOM_MAX); _apply_camera()
			MOUSE_BUTTON_RIGHT:
				_is_right_drag = mb.pressed; _touch_moved = false
				if mb.pressed: _drag_world_hit = _raycast_plane(mb.position, 0.0)
			MOUSE_BUTTON_LEFT:
				if mb.pressed:
					_path_dragging = not GameState.placement_mode.is_empty()
					_touch_moved = false; _update_ghost(mb.position)
				else:
					_path_dragging = false
					if not _touch_moved: _handle_click(mb.position)
	if event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if _is_right_drag:
			var cur_hit := _raycast_plane(mm.position, 0.0)
			var diff := _drag_world_hit - cur_hit; diff.y = 0.0
			_cam_target += diff; _apply_camera(); _touch_moved = true
		else:
			_update_ghost(mm.position)
			if _path_dragging: _handle_drag_paint(mm.position)
	if event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		var d0 := _raycast_plane(sd.position - sd.relative, 0.0)
		var d1 := _raycast_plane(sd.position, 0.0)
		var diff := d0 - d1; diff.y = 0.0
		_cam_target += diff; _apply_camera(); _touch_moved = true
	if event is InputEventScreenTouch:
		if (event as InputEventScreenTouch).pressed: _touch_moved = false
		elif not _touch_moved: _handle_click((event as InputEventScreenTouch).position)
	if event is InputEventMagnifyGesture:
		_cam_zoom = clampf(_cam_zoom / (event as InputEventMagnifyGesture).factor, ZOOM_MIN, ZOOM_MAX)
		_apply_camera()

# ══════════════════════════════════════════════════════════════════════════════
# RAYCAST
# ══════════════════════════════════════════════════════════════════════════════
func _raycast_plane(screen_pos: Vector2, plane_y: float) -> Vector3:
	if camera == null: return Vector3.ZERO
	var from := camera.project_ray_origin(screen_pos)
	var dir  := camera.project_ray_normal(screen_pos)
	if absf(dir.y) < 0.0001: return Vector3.ZERO
	var t := (plane_y - from.y) / dir.y
	if t < 0.0: t = 0.0
	return from + dir * t

func _screen_to_tile(screen_pos: Vector2) -> Vector2i:
	if camera == null: return Vector2i(-1, -1)
	var space := get_viewport().find_world_3d().direct_space_state
	var from  := camera.project_ray_origin(screen_pos)
	var to    := from + camera.project_ray_normal(screen_pos) * 500.0
	var params := PhysicsRayQueryParameters3D.create(from, to)
	params.collision_mask = 1
	var hit := space.intersect_ray(params)
	var world_pos: Vector3
	if hit.is_empty(): world_pos = _raycast_plane(screen_pos, 0.0)
	else: world_pos = hit["position"] as Vector3
	return Vector2i(int(world_pos.x / WorldRenderer3D.TILE_SIZE), int(world_pos.z / WorldRenderer3D.TILE_SIZE))

func _update_ghost(screen_pos: Vector2) -> void:
	if GameState.placement_mode == "BUILDING" and not GameState.placement_sub.is_empty():
		var tv := _screen_to_tile(screen_pos)
		renderer.update_ghost(tv.x, tv.y, GameState.placement_sub)
	else: renderer.clear_ghost()

# ══════════════════════════════════════════════════════════════════════════════
# SPIELAKTIONEN
# ══════════════════════════════════════════════════════════════════════════════
func _handle_click(screen_pos: Vector2) -> void:
	var tv := _screen_to_tile(screen_pos)
	var tx: int = tv.x; var ty: int = tv.y
	if world_gen == null: return
	if tx < 0 or ty < 0 or tx >= world_gen.w or ty >= world_gen.h:
		renderer.clear_selection(); GameState.building_deselected.emit(); return
	match GameState.placement_mode:
		"BUILDING": _place_building(tx, ty, GameState.placement_sub)
		"PATH":     _place_path(tx, ty, GameState.placement_sub)
		"TERRAIN":
			if GameState.placement_sub == "RAISE":
				# Crash-Fix: build_world() ist ein KOMPLETTER Neuaufbau (loescht und
				# erzeugt Terrain, Kollision, ALLE Gebaeude und Frettchen neu). Fuer
				# eine einzelne Hoehenaenderung reicht refresh_terrain() (Mesh +
				# Kollision), siehe auch _handle_drag_paint().
				WorldGenerator.raise_terrain(world, tx, ty); renderer.refresh_terrain()
			elif GameState.placement_sub == "DYNAMITE":
				WorldGenerator.place_dynamite(world, tx, ty, explosions)
		_: _select_tile(tx, ty)

func _handle_drag_paint(screen_pos: Vector2) -> void:
	var tv := _screen_to_tile(screen_pos)
	if GameState.placement_mode == "PATH":
		_place_path(tv.x, tv.y, GameState.placement_sub, true)
	elif GameState.placement_mode == "TERRAIN" and GameState.placement_sub == "RAISE":
		# Crash-Fix: InputEventMouseMotion kann mehrfach PRO FRAME ausgeloest
		# werden. Mit dem vorherigen renderer.build_world() (voller Teardown +
		# Neuaufbau von Terrain, Kollision, allen Gebaeuden UND Frettchen) wurden
		# beim Ziehen der Maus etliche StaticBody3D/Mesh-Generationen pro Sekunde
		# erzeugt, deren queue_free() noch ausstand, waehrend schon die naechste
		# Generation aufgebaut wurde. Das haeufte sich beim Aufschuetten von
		# Terrain ueber laengere Zeit auf und liess das Spiel irgendwann
		# abstuerzen. refresh_terrain() baut nur Mesh + Kollision neu, nicht
		# Gebaeude/Frettchen, und ist damit sicher fuer haeufige Aufrufe.
		WorldGenerator.raise_terrain(world, tv.x, tv.y); renderer.refresh_terrain()

func _place_building(tx: int, ty: int, building_id: String) -> void:
	if building_id.is_empty() or world_gen == null: return
	var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
	if tile.get("building") != null: GameState.notify("Hier steht bereits ein Gebaeude!"); return
	# Feature (Wasserphysik): Daemme muessen direkt auf/im Wasser stehen
	# koennen, um den lokalen Abfluss zu drosseln - alle anderen Gebaeude
	# bleiben weiterhin von Wasser-Tiles ausgeschlossen.
	if str(tile.get("biome","")) == "WATER" and building_id != "DAM":
		GameState.notify("Nicht auf Wasser bauen!"); return
	if not GameState.dev_all_buildings and not BuildingSys.can_build(building_id):
		GameState.notify("Nicht genug Ressourcen!"); return
	var b: BuildingEntity = BuildingSys.build(building_id, tx, ty, world, GameState.dev_all_buildings)
	if b != null:
		b.placed_day = DayNight.day_count
		renderer.add_building(b); SoundSys.play_build()
		GameState.cancel_placement(); renderer.clear_ghost()

func _place_path(tx: int, ty: int, path_type: String, silent: bool = false) -> void:
	if world_gen == null: return
	if tx < 0 or ty < 0 or tx >= world_gen.w or ty >= world_gen.h: return
	var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
	if tile.get("building") != null or str(tile.get("biome","")) in ["WATER","MOUNTAIN"]: return
	if tile.get("path") != null: return
	var pt: Dictionary = BuildingData.PATH_TYPES.get(path_type, {}) as Dictionary
	var costs: Dictionary = pt.get("costs", {}) as Dictionary
	if not GameState.dev_all_buildings and not ResourceSys.can_afford(costs):
		if not silent: GameState.notify("Nicht genug Ressourcen fuer Weg!"); return
	if not GameState.dev_all_buildings: ResourceSys.spend(costs)
	tile["path"] = {"type": path_type}
	renderer.refresh_terrain(); _on_hud_update()

func _select_tile(tx: int, ty: int) -> void:
	renderer.set_selection(tx, ty)
	var tile: Dictionary = (world[tx] as Array)[ty] as Dictionary
	var bld = tile.get("building", null)
	if bld != null:
		var b: BuildingEntity = bld as BuildingEntity
		renderer.selected_building = b; GameState.building_selected.emit(b)
	else:
		renderer.selected_building = null; GameState.building_deselected.emit()
		if bool(tile.get("ruin",false)) and ResourceSys.has("TOOLS", 5):
			ResourceSys.remove("TOOLS", 5); tile["ruin"] = false
			ResourceSys.force_add("WOOD", float(randi_range(10,30)))
			ResourceSys.force_add("STONE", float(randi_range(5,20)))
			GameState.notify("Ruine erkundet! Beute gefunden!"); _on_hud_update()

func sell_selected_building() -> void:
	if renderer.selected_building == null: return
	var bname: String = renderer.selected_building.name
	var stx: int = renderer.selected_building.tile_x
	var sty: int = renderer.selected_building.tile_y
	BuildingSys.sell(renderer.selected_building, world)
	renderer.remove_building(stx, sty)
	renderer.selected_building = null; renderer.clear_selection()
	GameState.building_deselected.emit(); GameState.notify(bname + " verkauft!")

func upgrade_selected_building() -> void:
	if renderer.selected_building == null: return
	if renderer.selected_building.upgrade():
		renderer.add_building(renderer.selected_building)
		GameState.notify("Upgrade auf Stufe %d!" % renderer.selected_building.level); _on_hud_update()
	else: GameState.notify("Upgrade nicht moeglich!")

func _toggle_pause() -> void:
	if GameState.current_state == GameState.State.PLAYING:
		GameState.set_state(GameState.State.PAUSED); GameState.game_speed = 0.0
	else:
		GameState.set_state(GameState.State.PLAYING); GameState.game_speed = 1.0

# ── UI-Callbacks ──────────────────────────────────────────────────────────────
func _on_hud_update() -> void:
	var hud := get_node_or_null("GameUI/UIRoot/HUD")
	if hud and hud.has_method("refresh"): hud.call("refresh")

func _on_build_menu_update() -> void:
	var bm := get_node_or_null("GameUI/UIRoot/BuildMenu")
	if bm and bm.has_method("refresh"): bm.call("refresh")

func _on_building_selected(b: BuildingEntity) -> void:
	var bi := get_node_or_null("GameUI/UIRoot/BuildingInfo")
	if bi and bi.has_method("show_building"): bi.call("show_building", b, self)

func _on_building_deselected() -> void:
	var bi := get_node_or_null("GameUI/UIRoot/BuildingInfo")
	if bi: bi.hide()

func _on_notification(msg: String, color: Color) -> void:
	var root := get_tree().get_root()
	var nl := root.find_child("Notifications", true, false)
	if nl and nl.has_method("show_notification"): nl.call("show_notification", msg, color)

func _on_game_over(_cause: String) -> void:
	GameState.set_state(GameState.State.GAME_OVER)

func _on_placement_mode_changed(mode: String, _sub: String) -> void:
	var hint := get_node_or_null("GameUI/UIRoot/PlacementHint")
	if hint == null: return
	if mode.is_empty(): hint.hide(); renderer.clear_ghost(); return
	hint.show()
	match mode:
		"BUILDING": hint.text = "Klicken zum Platzieren  |  ESC = Abbrechen"
		"PATH":     hint.text = "Klicken/Halten zum Malen  |  ESC = Abbrechen"
		"TERRAIN":  hint.text = "Klicken/Halten auf Terrain  |  ESC = Abbrechen"

# ── Speichern / Laden ─────────────────────────────────────────────────────────
func serialize_world() -> Dictionary:
	if world_gen == null: return {}
	var rows: Array = []
	for x in world_gen.w:
		var col_data: Array = []
		for y in world_gen.h:
			var t: Dictionary = (world[x] as Array)[y] as Dictionary
			col_data.append({"biome": str(t.get("biome","PLAINS")), "height": float(t.get("height",0.0)),
				"path": t.get("path"), "ruin": bool(t.get("ruin",false)),
				"resource_node": t.get("resource_node"),
				"water_level": float(t.get("water_level", 0.0)),
				"is_water_source": bool(t.get("is_water_source", false))})
		rows.append(col_data)
	return {"size_w": world_gen.w, "size_h": world_gen.h, "seed": world_gen.seed_val, "tiles": rows}

func deserialize_world(data: Dictionary) -> void:
	if data.is_empty(): return
	world_gen = WorldGenerator.new()
	world_gen.w = int(data.get("size_w",60)); world_gen.h = int(data.get("size_h",60))
	world_gen.seed_val = int(data.get("seed",0)); world = []
	var tiles: Array = data.get("tiles",[]) as Array
	for x in world_gen.w:
		var col: Array = []
		for y in world_gen.h:
			var td: Dictionary = {}
			if x < tiles.size():
				var tc: Array = tiles[x] as Array
				if y < tc.size(): td = tc[y] as Dictionary
			col.append({"biome": str(td.get("biome","PLAINS")), "height": float(td.get("height",0.0)),
				"building": null, "path": td.get("path"), "resource_node": td.get("resource_node"),
				"ruin": bool(td.get("ruin",false)), "dynamite": false,
				"water_level": float(td.get("water_level", 1.0 if str(td.get("biome","PLAINS")) == "WATER" else 0.0)),
				"is_water_source": bool(td.get("is_water_source", false))})
		world.append(col)
	WaterSys.init(world, world_gen.w, world_gen.h)
	_setup_renderer()
	@warning_ignore("integer_division")
	_cam_target = renderer.tile_to_world3d(world_gen.w/2, world_gen.h/2); _cam_target.y = 0.0
	_apply_camera()

## Wird von SaveSystem nach load_game() aufgerufen.
## Terrain ist fertig, Gebäude sind jetzt in den Tiles → Renderer-Nodes erzeugen.
func post_load_refresh() -> void:
	if renderer != null:
		renderer.refresh_buildings()
		renderer.apply_drought(DroughtSys.is_drought)
	_on_hud_update()
	_on_build_menu_update()

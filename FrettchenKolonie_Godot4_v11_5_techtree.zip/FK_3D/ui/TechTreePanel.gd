## TechTreePanel.gd
## Feature (Tech Tree): eigenes Panel fuer den ueberarbeiteten Tech Tree.
## Baut seine komplette UI dynamisch in _refresh() selbst auf (Muster wie
## ExpeditionPanel.gd/GraveyardPanel.gd) - zeigt oben eine Epochen-Uebersicht
## samt Freischalt-Button fuer die naechste Epoche, darunter Reiter fuer jeden
## Themenbereich und darunter die 10 Tech-Knoten des aktuell gewaehlten
## Themenbereichs als scrollbare Liste.
extends PanelContainer

var _current_section: String = "FORESTRY"

func _ready() -> void:
	hide()
	GameState.tech_unlocked.connect(func(_id): if visible: _refresh())
	GameState.hud_update_requested.connect(func(): if visible: _refresh())

func open() -> void:
	show(); _refresh()

func _refresh() -> void:
	for c in get_children(): c.queue_free()
	var outer := VBoxContainer.new(); outer.add_theme_constant_override("separation", 6); add_child(outer)

	# ── Kopfzeile ─────────────────────────────────────────────────────────
	var hdr := HBoxContainer.new(); outer.add_child(hdr)
	var tl := Label.new()
	tl.text = "🔬 Tech Tree – Wissenspunkte: %d" % int(ResourceSys.science)
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 16)
	tl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.75))
	hdr.add_child(tl)
	var cb := Button.new(); cb.text = "X"; cb.pressed.connect(hide); hdr.add_child(cb)
	outer.add_child(HSeparator.new())

	# ── Epochen-Uebersicht ────────────────────────────────────────────────
	outer.add_child(_build_epoch_row())
	outer.add_child(HSeparator.new())

	# ── Themenbereich-Reiter ──────────────────────────────────────────────
	var tabs := HBoxContainer.new(); tabs.add_theme_constant_override("separation", 4)
	outer.add_child(tabs)
	for sid in TechTreeSys.SECTION_ORDER:
		var sdata: Dictionary = TechTreeSys.SECTIONS.get(sid, {})
		var progress: int = TechTreeSys.get_section_progress(sid)
		var tb := Button.new()
		tb.text = "%s %s (%d/10)" % [str(sdata.get("icon","")), str(sdata.get("name",sid)), progress]
		tb.add_theme_font_size_override("font_size", 11)
		tb.toggle_mode = true
		tb.button_pressed = (sid == _current_section)
		if sid == _current_section:
			tb.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
		var s: String = sid
		tb.pressed.connect(func(): _current_section = s; _refresh())
		tabs.add_child(tb)

	# ── Knoten-Liste des aktuellen Themenbereichs ────────────────────────
	var sc := ScrollContainer.new(); sc.custom_minimum_size = Vector2(0, 300)
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(sc)
	var list := VBoxContainer.new(); list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 4); sc.add_child(list)
	for tier in range(1, 11):
		var tid: String = "%s_%d" % [_current_section, tier]
		if not TechTreeSys.NODES.has(tid): continue
		list.add_child(_build_node_row(tid))

func _build_epoch_row() -> Control:
	var row := VBoxContainer.new(); row.add_theme_constant_override("separation", 4)
	var pills := HBoxContainer.new(); pills.add_theme_constant_override("separation", 6); row.add_child(pills)
	var cur_epoch: int = TechTreeSys.get_epoch()
	for eid in ["EPOCH_1","EPOCH_2","EPOCH_3","EPOCH_4"]:
		var ed: Dictionary = TechTreeSys.EPOCHS.get(eid, {})
		var e_num: int = int(ed.get("epoch", 1))
		var lbl := Label.new()
		lbl.text = "%d. %s" % [e_num, str(ed.get("name", eid))]
		lbl.add_theme_font_size_override("font_size", 12)
		if eid in TechTreeSys.unlocked_epochs:
			lbl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.55))
		elif e_num == cur_epoch + 1:
			lbl.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
		else:
			lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		pills.add_child(lbl)
		if e_num < 4:
			var arrow := Label.new(); arrow.text = "→"
			arrow.add_theme_color_override("font_color", Color(0.4,0.4,0.4)); pills.add_child(arrow)

	var next_id: String = TechTreeSys.get_next_epoch_id()
	if next_id != "":
		var ed2: Dictionary = TechTreeSys.EPOCHS.get(next_id, {})
		var req_met: bool = TechTreeSys.epoch_requirement_met(next_id)
		var sec_req: Dictionary = ed2.get("section_req", {})
		var req_node: String = str(sec_req.get("node",""))
		var req_nd: Dictionary = TechTreeSys.NODES.get(req_node, {})
		var sec_data: Dictionary = TechTreeSys.SECTIONS.get(str(req_nd.get("section","")), {})
		var info := Label.new()
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		info.add_theme_font_size_override("font_size", 11)
		if not req_met:
			info.text = "Voraussetzung für %s: „%s“ im Themenbereich %s freischalten (Stufe %d)." % [
				str(ed2.get("name", next_id)), str(req_nd.get("name", req_node)),
				str(sec_data.get("name","")), int(req_nd.get("tier",0))]
			info.add_theme_color_override("font_color", Color(0.85,0.5,0.3))
			row.add_child(info)
		else:
			var btn := Button.new()
			var cost: float = float(ed2.get("cost", 0.0))
			btn.text = "Epoche freischalten: %s (🔬%d)" % [str(ed2.get("name", next_id)), int(cost)]
			btn.disabled = not TechTreeSys.can_unlock_epoch(next_id)
			btn.pressed.connect(func(): TechTreeSys.unlock_epoch(next_id); _refresh())
			row.add_child(btn)
	else:
		var maxlbl := Label.new(); maxlbl.text = "Höchste Epoche erreicht."
		maxlbl.add_theme_font_size_override("font_size", 11)
		maxlbl.add_theme_color_override("font_color", Color(0.5,0.5,0.5))
		row.add_child(maxlbl)
	return row

func _build_node_row(tid: String) -> Control:
	var nd: Dictionary = TechTreeSys.NODES.get(tid, {})
	var panel := PanelContainer.new()
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 2); panel.add_child(vb)

	var top := HBoxContainer.new(); vb.add_child(top)
	var is_unlocked: bool = TechTreeSys.is_node_unlocked(tid)
	var req: String = str(nd.get("requires_node",""))
	var req_ok: bool = req == "" or TechTreeSys.is_node_unlocked(req)
	var can_unlock: bool = TechTreeSys.can_unlock_node(tid)

	var name_lbl := Label.new()
	var status_icon: String = "✅" if is_unlocked else ("🔒" if not req_ok else "🔬")
	name_lbl.text = "%s Stufe %d: %s" % [status_icon, int(nd.get("tier",0)), str(nd.get("name", tid))]
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_lbl.add_theme_font_size_override("font_size", 13)
	if is_unlocked:
		name_lbl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.55))
	elif not req_ok:
		name_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	top.add_child(name_lbl)

	if not is_unlocked:
		var btn := Button.new()
		btn.text = "Erforschen (🔬%d)" % int(nd.get("cost", 0.0))
		btn.disabled = not can_unlock
		btn.add_theme_font_size_override("font_size", 11)
		var t: String = tid
		btn.pressed.connect(func(): TechTreeSys.unlock_node(t); _refresh())
		top.add_child(btn)

	var desc_lbl := Label.new()
	desc_lbl.text = str(nd.get("desc",""))
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.add_theme_font_size_override("font_size", 11)
	desc_lbl.add_theme_color_override("font_color", Color(0.75,0.75,0.75))
	vb.add_child(desc_lbl)

	if not is_unlocked and not req_ok:
		var req_nd: Dictionary = TechTreeSys.NODES.get(req, {})
		var lock_lbl := Label.new()
		lock_lbl.text = "Benötigt zuerst: %s" % str(req_nd.get("name", req))
		lock_lbl.add_theme_font_size_override("font_size", 10)
		lock_lbl.add_theme_color_override("font_color", Color(0.7,0.35,0.3))
		vb.add_child(lock_lbl)

	return panel

## TechTree.gd
## Vollstaendig ueberarbeiteter Tech Tree (Feature-Anfrage: eigene Wissenspunkte-
## Ressource, in Themenbereiche gegliederte, progressive Upgrades, Epochenaufstiege
## die ausschliesslich Wissenspunkte kosten und einen Mindestfortschritt in einem
## Themenbereich voraussetzen, generische Effekte (Produktionsboni, Gebaeude-
## Freischaltungen, Umbau-Freischaltungen, permanente globale Boni) und individuelle
## Namen/Beschreibungen pro Knoten).
extends Node

## Alle Themenbereiche (Abschnitte) des Tech Trees.
const SECTIONS: Dictionary = {
	"FORESTRY": {"name": "Holzwirtschaft", "icon": "🪓"},
	"MINING": {"name": "Bergbau & Steinwirtschaft", "icon": "⛏️"},
	"WATER": {"name": "Wasserwirtschaft", "icon": "💧"},
	"FARMING": {"name": "Landwirtschaft & Ernährung", "icon": "🌾"},
	"BREEDING": {"name": "Zucht & Bevölkerung", "icon": "🐾"},
	"LOGISTICS": {"name": "Bauwesen & Logistik", "icon": "🏗️"},
}

## Reihenfolge der Themenbereiche-Sektionen (fuer die UI).
const SECTION_ORDER: Array = ["FORESTRY", "MINING", "WATER", "FARMING", "BREEDING", "LOGISTICS"]

## Alle regulaeren Tech-Knoten (60, 10 je Themenbereich). Jeder Knoten hat einen
## individuellen Namen + Beschreibung, gehoert zu einer "section", hat eine "tier"
## (1-basiert, Knoten N benoetigt Knoten N-1 DERSELBEN Sektion, ausser tier 1),
## einen Wissenspunkte-"cost" und eine Liste "effects" (siehe Effekt-Typen oben in
## den Kommentaren von get_global_bonus()/get_building_bonuses()).
const NODES: Dictionary = {
	"FORESTRY_1": {
		"name": "Geschärfte Äxte", "desc": "Nachgeschärfte Klingen für die Holzfäller-Äxte sorgen für deutlich mehr Holz pro Hieb.",
		"section": "FORESTRY", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"bstat","building":"LUMBERJACK","field":"production_speed","mode":"mult","value":0.15}]
	},
	"FORESTRY_2": {
		"name": "Effiziente Stämme", "desc": "Optimierte Sägeblätter im Sägewerk verarbeiten Stämme spürbar schneller zu Brettern.",
		"section": "FORESTRY", "tier": 2, "cost": 20, "requires_node": "FORESTRY_1",
		"effects": [{"type":"bstat","building":"SAWMILL","field":"production_speed","mode":"mult","value":0.15}]
	},
	"FORESTRY_3": {
		"name": "Dichte Pflanzung", "desc": "Die Försterei pflanzt in einem größeren Radius neue Setzlinge und hält den Wald weiträumiger am Leben.",
		"section": "FORESTRY", "tier": 3, "cost": 25, "requires_node": "FORESTRY_2",
		"effects": [{"type":"bstat","building":"FORESTER","field":"planting_radius","mode":"add","value":3}]
	},
	"FORESTRY_4": {
		"name": "Schnellwachsende Setzlinge", "desc": "Ausgewähltes Saatgut lässt abgeholzte Bäume merklich schneller nachwachsen.",
		"section": "FORESTRY", "tier": 4, "cost": 35, "requires_node": "FORESTRY_3",
		"effects": [{"type":"global","key":"wood_regen_speed","value":0.2}]
	},
	"FORESTRY_5": {
		"name": "Weitreichende Fällung", "desc": "Holzfäller dürfen jetzt einen größeren Umkreis nach fällbaren Bäumen absuchen.",
		"section": "FORESTRY", "tier": 5, "cost": 45, "requires_node": "FORESTRY_4",
		"effects": [{"type":"bstat","building":"LUMBERJACK","field":"collection_radius","mode":"add","value":2}]
	},
	"FORESTRY_6": {
		"name": "Verstärkte Transportkisten", "desc": "Robustere Kisten am Sammelplatz erhöhen das lokale Zwischenlager aller Holz-Sammelgebäude.",
		"section": "FORESTRY", "tier": 6, "cost": 60, "requires_node": "FORESTRY_5",
		"effects": [{"type":"bstat","building":"LUMBERJACK","field":"local_storage_capacity","mode":"add","value":20}, {"type":"bstat","building":"FORESTER","field":"local_storage_capacity","mode":"add","value":20}]
	},
	"FORESTRY_7": {
		"name": "Harzverwertung", "desc": "Übrig gebliebenes Harz und Restholz werden im Sägewerk zusätzlich verwertet.",
		"section": "FORESTRY", "tier": 7, "cost": 80, "requires_node": "FORESTRY_6",
		"effects": [{"type":"bstat","building":"SAWMILL","field":"production_speed","mode":"mult","value":0.25}]
	},
	"FORESTRY_8": {
		"name": "Waldwächter", "desc": "Die Försterei erkennt kahle Stellen früher und lässt den Wald insgesamt schneller nachwachsen.",
		"section": "FORESTRY", "tier": 8, "cost": 105, "requires_node": "FORESTRY_7",
		"effects": [{"type":"global","key":"wood_regen_speed","value":0.15}]
	},
	"FORESTRY_9": {
		"name": "Werkstatt-Ausbau", "desc": "Neue Vorrichtungen erlauben es, die Werkstatt zu einer Großwerkstatt mit mehr Kapazität umzubauen.",
		"section": "FORESTRY", "tier": 9, "cost": 140, "requires_node": "FORESTRY_8",
		"effects": [{"type":"rebuild","building":"WORKSHOP"}]
	},
	"FORESTRY_10": {
		"name": "Meister der Forstwirtschaft", "desc": "Jahrzehntelange Erfahrung in der Waldbewirtschaftung steigert die Leistung aller holzbezogenen Gebäude spürbar.",
		"section": "FORESTRY", "tier": 10, "cost": 185, "requires_node": "FORESTRY_9",
		"effects": [{"type":"bstat","building":"LUMBERJACK","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"SAWMILL","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"FORESTER","field":"planting_radius","mode":"add","value":2}]
	},
	"MINING_1": {
		"name": "Gehärtete Meißel", "desc": "Härtere Meißelspitzen lassen den Steinbruch spürbar mehr Stein pro Arbeitsgang fördern.",
		"section": "MINING", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"bstat","building":"QUARRY","field":"production_speed","mode":"mult","value":0.15}]
	},
	"MINING_2": {
		"name": "Tiefenbohrung", "desc": "Neue Bohrtechnik erschließt reichhaltigere Erzadern in der Eisenmine.",
		"section": "MINING", "tier": 2, "cost": 20, "requires_node": "MINING_1",
		"effects": [{"type":"bstat","building":"IRON_MINE","field":"production_speed","mode":"mult","value":0.15}]
	},
	"MINING_3": {
		"name": "Kohleveredelung", "desc": "Bessere Sortierung lässt die Kohlemine mehr brauchbare Kohle pro Schicht liefern.",
		"section": "MINING", "tier": 3, "cost": 25, "requires_node": "MINING_2",
		"effects": [{"type":"bstat","building":"COAL_MINE","field":"production_speed","mode":"mult","value":0.15}]
	},
	"MINING_4": {
		"name": "Schmelzofen-Optimierung", "desc": "Eine gleichmäßigere Befeuerung steigert die Ausbeute der Schmelze deutlich.",
		"section": "MINING", "tier": 4, "cost": 35, "requires_node": "MINING_3",
		"effects": [{"type":"bstat","building":"SMELTER","field":"production_speed","mode":"mult","value":0.2}]
	},
	"MINING_5": {
		"name": "Größere Fördermenge", "desc": "Der Steinbruch darf jetzt in einem größeren Umkreis nach Gestein suchen.",
		"section": "MINING", "tier": 5, "cost": 45, "requires_node": "MINING_4",
		"effects": [{"type":"bstat","building":"QUARRY","field":"collection_radius","mode":"add","value":2}]
	},
	"MINING_6": {
		"name": "Stollenausbau", "desc": "Zusätzliche Förderkörbe vergrößern das lokale Zwischenlager der Bergbaugebäude.",
		"section": "MINING", "tier": 6, "cost": 60, "requires_node": "MINING_5",
		"effects": [{"type":"bstat","building":"IRON_MINE","field":"local_storage_capacity","mode":"add","value":20}, {"type":"bstat","building":"COAL_MINE","field":"local_storage_capacity","mode":"add","value":20}, {"type":"bstat","building":"QUARRY","field":"local_storage_capacity","mode":"add","value":20}]
	},
	"MINING_7": {
		"name": "Sprengtechnik", "desc": "Kontrollierte Sprengungen lockern das Gestein vor - der Steinbruch fördert dadurch noch mehr.",
		"section": "MINING", "tier": 7, "cost": 80, "requires_node": "MINING_6",
		"effects": [{"type":"bstat","building":"QUARRY","field":"production_speed","mode":"mult","value":0.2}]
	},
	"MINING_8": {
		"name": "Werkzeugstahl", "desc": "Hochwertigerer Stahl in der Werkstatt beschleunigt die Werkzeugproduktion.",
		"section": "MINING", "tier": 8, "cost": 105, "requires_node": "MINING_7",
		"effects": [{"type":"bstat","building":"WORKSHOP","field":"production_speed","mode":"mult","value":0.2}]
	},
	"MINING_9": {
		"name": "Bergbau-Kooperative", "desc": "Organisierte Schichtpläne erlauben es, den Steinbruch zu einem Großsteinbruch umzubauen.",
		"section": "MINING", "tier": 9, "cost": 140, "requires_node": "MINING_8",
		"effects": [{"type":"rebuild","building":"QUARRY"}]
	},
	"MINING_10": {
		"name": "Meister des Bergbaus", "desc": "Generationen von Bergleuten-Wissen steigert die Leistung aller Bergbau- und Schmelzgebäude spürbar.",
		"section": "MINING", "tier": 10, "cost": 185, "requires_node": "MINING_9",
		"effects": [{"type":"bstat","building":"QUARRY","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"IRON_MINE","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"COAL_MINE","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"SMELTER","field":"production_speed","mode":"mult","value":0.25}]
	},
	"WATER_1": {
		"name": "Tiefere Brunnen", "desc": "Tiefer gegrabene Brunnenschächte erreichen ergiebigere Wasserschichten.",
		"section": "WATER", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"bstat","building":"WELL","field":"production_speed","mode":"mult","value":0.2}]
	},
	"WATER_2": {
		"name": "Aquädukt-Technik", "desc": "Verbesserte Rinnen-Neigung lässt das Aquädukt spürbar mehr Wasser heranführen.",
		"section": "WATER", "tier": 2, "cost": 20, "requires_node": "WATER_1",
		"effects": [{"type":"bstat","building":"AQUEDUCT","field":"production_speed","mode":"mult","value":0.2}]
	},
	"WATER_3": {
		"name": "Verstärkte Dämme", "desc": "Zusätzliche Stützpfeiler lassen Dämme deutlich mehr Wasser zurückhalten.",
		"section": "WATER", "tier": 3, "cost": 25, "requires_node": "WATER_2",
		"effects": [{"type":"global","key":"dam_retention_bonus","value":0.05}]
	},
	"WATER_4": {
		"name": "Größere Wassertürme", "desc": "Verstärkte Tankwände erhöhen das Fassungsvermögen des Wasserturms erheblich.",
		"section": "WATER", "tier": 4, "cost": 35, "requires_node": "WATER_3",
		"effects": [{"type":"bstat","building":"WATER_TOWER","field":"water_capacity","mode":"add","value":150}]
	},
	"WATER_5": {
		"name": "Bewässerungstechnik", "desc": "Feinere Kanalführung steigert die Fördermenge des Bewässerungskanals.",
		"section": "WATER", "tier": 5, "cost": 45, "requires_node": "WATER_4",
		"effects": [{"type":"bstat","building":"IRRIGATION","field":"production_speed","mode":"mult","value":0.2}]
	},
	"WATER_6": {
		"name": "Wasserradoptimierung", "desc": "Neu geformte Schaufeln lassen jedes Wasserrad einen spürbar stärkeren Produktionsschub geben.",
		"section": "WATER", "tier": 6, "cost": 60, "requires_node": "WATER_5",
		"effects": [{"type":"global","key":"waterwheel_boost_bonus","value":0.15}]
	},
	"WATER_7": {
		"name": "Dürrevorsorge", "desc": "Abgedeckte Becken verringern die Verdunstung von Flüssen und Seen während einer Dürre merklich.",
		"section": "WATER", "tier": 7, "cost": 80, "requires_node": "WATER_6",
		"effects": [{"type":"global","key":"drought_evaporation_reduction","value":0.2}]
	},
	"WATER_8": {
		"name": "Reservoir-Ausbau", "desc": "Vertiefte Becken erhöhen das Fassungsvermögen des Wasserreservoirs deutlich.",
		"section": "WATER", "tier": 8, "cost": 105, "requires_node": "WATER_7",
		"effects": [{"type":"bstat","building":"RESERVOIR","field":"water_capacity","mode":"add","value":250}]
	},
	"WATER_9": {
		"name": "Schleusentechnik", "desc": "Steuerbare Schleusentore erlauben es, den Damm zu einer echten Schleuse mit deutlich mehr Rückhalt umzubauen.",
		"section": "WATER", "tier": 9, "cost": 140, "requires_node": "WATER_8",
		"effects": [{"type":"rebuild","building":"DAM"}]
	},
	"WATER_10": {
		"name": "Meister der Wasserwirtschaft", "desc": "Jahrelange Erfahrung im Umgang mit Flüssen und Seen verbessert alle wasserbezogenen Gebäude und senkt die Verdunstung zusätzlich.",
		"section": "WATER", "tier": 10, "cost": 185, "requires_node": "WATER_9",
		"effects": [{"type":"bstat","building":"WELL","field":"production_speed","mode":"mult","value":0.2}, {"type":"bstat","building":"WATER_PUMP","field":"production_speed","mode":"mult","value":0.2}, {"type":"bstat","building":"AQUEDUCT","field":"production_speed","mode":"mult","value":0.2}, {"type":"global","key":"drought_evaporation_reduction","value":0.15}]
	},
	"FARMING_1": {
		"name": "Ausgewählte Samen", "desc": "Sorgfältig ausgewähltes Saatgut lässt den Beerensammler mehr Beeren pro Strauch ernten.",
		"section": "FARMING", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"bstat","building":"BERRY_GATHERER","field":"production_speed","mode":"mult","value":0.15}]
	},
	"FARMING_2": {
		"name": "Fruchtbarer Boden", "desc": "Kompost und Fruchtwechsel steigern den Ertrag des Getreidefelds.",
		"section": "FARMING", "tier": 2, "cost": 20, "requires_node": "FARMING_1",
		"effects": [{"type":"bstat","building":"CROP_FIELD","field":"production_speed","mode":"mult","value":0.2}]
	},
	"FARMING_3": {
		"name": "Gewächshausplanung", "desc": "Durchdachtere Beetanlagen steigern den Ertrag des Gartens.",
		"section": "FARMING", "tier": 3, "cost": 25, "requires_node": "FARMING_2",
		"effects": [{"type":"bstat","building":"GARDEN","field":"production_speed","mode":"mult","value":0.15}]
	},
	"FARMING_4": {
		"name": "Jagdausrüstung", "desc": "Bessere Bögen und Fallen erhöhen die Beute der Jäger-Hütte.",
		"section": "FARMING", "tier": 4, "cost": 35, "requires_node": "FARMING_3",
		"effects": [{"type":"bstat","building":"HUNTER_HUT","field":"production_speed","mode":"mult","value":0.2}]
	},
	"FARMING_5": {
		"name": "Kochkunst", "desc": "Neue Rezepte und Küchengriffe beschleunigen die Zubereitung im Kochhaus.",
		"section": "FARMING", "tier": 5, "cost": 45, "requires_node": "FARMING_4",
		"effects": [{"type":"bstat","building":"COOKHOUSE","field":"production_speed","mode":"mult","value":0.2}]
	},
	"FARMING_6": {
		"name": "Größere Kühlkammern", "desc": "Zusätzliche Vorratskammern vergrößern das lokale Zwischenlager der Nahrungsgebäude.",
		"section": "FARMING", "tier": 6, "cost": 60, "requires_node": "FARMING_5",
		"effects": [{"type":"bstat","building":"GARDEN","field":"local_storage_capacity","mode":"add","value":20}, {"type":"bstat","building":"CROP_FIELD","field":"local_storage_capacity","mode":"add","value":20}, {"type":"bstat","building":"BERRY_GATHERER","field":"local_storage_capacity","mode":"add","value":20}]
	},
	"FARMING_7": {
		"name": "Erweiterte Felder", "desc": "Zusätzlich gerodete Ackerflächen steigern den Ertrag des Getreidefelds weiter.",
		"section": "FARMING", "tier": 7, "cost": 80, "requires_node": "FARMING_6",
		"effects": [{"type":"bstat","building":"CROP_FIELD","field":"production_speed","mode":"mult","value":0.2}]
	},
	"FARMING_8": {
		"name": "Vorratshaltung", "desc": "Zusätzliche Regale erhöhen die Kapazität des Lebensmittellagers deutlich.",
		"section": "FARMING", "tier": 8, "cost": 105, "requires_node": "FARMING_7",
		"effects": [{"type":"bstat","building":"FOOD_STORE","field":"storage_capacity","mode":"add","value":150}]
	},
	"FARMING_9": {
		"name": "Gewächshaustechnik", "desc": "Ein verglastes Dach erlaubt es, den Garten zu einem wetterunabhängigen Gewächshaus umzubauen.",
		"section": "FARMING", "tier": 9, "cost": 140, "requires_node": "FARMING_8",
		"effects": [{"type":"rebuild","building":"GARDEN"}]
	},
	"FARMING_10": {
		"name": "Meister der Landwirtschaft", "desc": "Generationen von Erfahrung in Anbau und Zubereitung steigern alle Nahrungsgebäude und senken den Grundhunger der Kolonie.",
		"section": "FARMING", "tier": 10, "cost": 185, "requires_node": "FARMING_9",
		"effects": [{"type":"bstat","building":"BERRY_GATHERER","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"GARDEN","field":"production_speed","mode":"mult","value":0.25}, {"type":"bstat","building":"CROP_FIELD","field":"production_speed","mode":"mult","value":0.25}, {"type":"global","key":"hunger_decay_reduction","value":0.1}]
	},
	"BREEDING_1": {
		"name": "Gesunde Ernährung", "desc": "Ausgewogenere Mahlzeiten lassen kranke und erschöpfte Frettchen sich schneller erholen.",
		"section": "BREEDING", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"global","key":"health_regen_bonus","value":0.15}]
	},
	"BREEDING_2": {
		"name": "Kuschelnester", "desc": "Weichere Nester und bessere Raumaufteilung schaffen zusätzlichen Platz im Wohnhaus.",
		"section": "BREEDING", "tier": 2, "cost": 20, "requires_node": "BREEDING_1",
		"effects": [{"type":"bstat","building":"HOUSE","field":"max_residents","mode":"add","value":1}]
	},
	"BREEDING_3": {
		"name": "Familienplanung", "desc": "Bessere Organisation der Kolonie senkt die nötige Glücksschwelle für Nachwuchs leicht.",
		"section": "BREEDING", "tier": 3, "cost": 25, "requires_node": "BREEDING_2",
		"effects": [{"type":"global","key":"growth_happiness_threshold_reduction","value":5.0}]
	},
	"BREEDING_4": {
		"name": "Wärmende Decken", "desc": "Zusätzliche Decken lindern den Unmut obdachloser Frettchen spürbar.",
		"section": "BREEDING", "tier": 4, "cost": 35, "requires_node": "BREEDING_3",
		"effects": [{"type":"global","key":"homeless_penalty_reduction","value":0.35}]
	},
	"BREEDING_5": {
		"name": "Ammenpflege", "desc": "Erfahrene Ammen kümmern sich besonders sorgfältig um neugeborene Frettchen.",
		"section": "BREEDING", "tier": 5, "cost": 45, "requires_node": "BREEDING_4",
		"effects": [{"type":"global","key":"newborn_health_bonus","value":20.0}]
	},
	"BREEDING_6": {
		"name": "Größere Betten", "desc": "Zusätzliche Stockbetten erlauben es, ein Wohnhaus zu einem geräumigeren Großen Wohnhaus umzubauen.",
		"section": "BREEDING", "tier": 6, "cost": 60, "requires_node": "BREEDING_5",
		"effects": [{"type":"rebuild","building":"HOUSE"}]
	},
	"BREEDING_7": {
		"name": "Ausdauertraining", "desc": "Regelmäßiges Training lässt Hunger, Durst und Laune der Frettchen langsamer absinken.",
		"section": "BREEDING", "tier": 7, "cost": 80, "requires_node": "BREEDING_6",
		"effects": [{"type":"global","key":"needs_decay_reduction","value":0.1}]
	},
	"BREEDING_8": {
		"name": "Nachtschicht-Training", "desc": "Abgehärtete Frettchen bleiben abends länger wach und gehen später schlafen.",
		"section": "BREEDING", "tier": 8, "cost": 105, "requires_node": "BREEDING_7",
		"effects": [{"type":"global","key":"day_length_extend","value":0.06}]
	},
	"BREEDING_9": {
		"name": "Kinderstube", "desc": "Eine eigene Kinderstube kümmert sich um den Nachwuchs und hebt die Stimmung in der ganzen Kolonie.",
		"section": "BREEDING", "tier": 9, "cost": 140, "requires_node": "BREEDING_8",
		"effects": [{"type":"unlock","building":"NURSERY"}]
	},
	"BREEDING_10": {
		"name": "Meister der Zucht", "desc": "Generationenlange Erfahrung in der Aufzucht steigert die Wachstumsrate der Kolonie deutlich und senkt die Sterblichkeit.",
		"section": "BREEDING", "tier": 10, "cost": 185, "requires_node": "BREEDING_9",
		"effects": [{"type":"global","key":"growth_rate_bonus","value":0.3}, {"type":"global","key":"mortality_reduction","value":0.2}]
	},
	"LOGISTICS_1": {
		"name": "Bessere Werkzeuge", "desc": "Schärferes Werkzeug beschleunigt jede Baustelle spürbar.",
		"section": "LOGISTICS", "tier": 1, "cost": 15, "requires_node": "",
		"effects": [{"type":"global","key":"construction_speed_bonus","value":0.2}]
	},
	"LOGISTICS_2": {
		"name": "Vorfertigung", "desc": "Vorgefertigte Bauteile verkürzen die benötigte Bauzeit weiter.",
		"section": "LOGISTICS", "tier": 2, "cost": 20, "requires_node": "LOGISTICS_1",
		"effects": [{"type":"global","key":"construction_speed_bonus","value":0.15}]
	},
	"LOGISTICS_3": {
		"name": "Lagerlogistik", "desc": "Bessere Organisation schafft einen zusätzlichen Arbeitsplatz im Lager.",
		"section": "LOGISTICS", "tier": 3, "cost": 25, "requires_node": "LOGISTICS_2",
		"effects": [{"type":"bstat","building":"STORAGE","field":"max_workers","mode":"add","value":1}]
	},
	"LOGISTICS_4": {
		"name": "Schnelle Füße", "desc": "Leichteres Schuhwerk lässt alle Frettchen spürbar schneller laufen.",
		"section": "LOGISTICS", "tier": 4, "cost": 35, "requires_node": "LOGISTICS_3",
		"effects": [{"type":"global","key":"move_speed_bonus","value":0.1}]
	},
	"LOGISTICS_5": {
		"name": "Großlager-Planung", "desc": "Zusätzliche Regalreihen erhöhen die Kapazität des Großen Lagers deutlich.",
		"section": "LOGISTICS", "tier": 5, "cost": 45, "requires_node": "LOGISTICS_4",
		"effects": [{"type":"bstat","building":"LARGE_STORAGE","field":"storage_capacity","mode":"add","value":150}]
	},
	"LOGISTICS_6": {
		"name": "Bauhof-Ausbau", "desc": "Zusätzliche Werkbänke schaffen Platz für einen weiteren Bauarbeiter im Bauhof.",
		"section": "LOGISTICS", "tier": 6, "cost": 60, "requires_node": "LOGISTICS_5",
		"effects": [{"type":"bstat","building":"CONSTRUCTION_YARD_1","field":"max_workers","mode":"add","value":1}]
	},
	"LOGISTICS_7": {
		"name": "Kranbau", "desc": "Ein einfacher Baukran erlaubt es, den Bauhof zu einem Großbauhof umzubauen.",
		"section": "LOGISTICS", "tier": 7, "cost": 80, "requires_node": "LOGISTICS_6",
		"effects": [{"type":"rebuild","building":"CONSTRUCTION_YARD_1"}]
	},
	"LOGISTICS_8": {
		"name": "Lagerhaus-Erweiterung", "desc": "Ein zusätzliches Stockwerk erlaubt es, ein Lager zu einem Großlagerhaus umzubauen.",
		"section": "LOGISTICS", "tier": 8, "cost": 105, "requires_node": "LOGISTICS_7",
		"effects": [{"type":"rebuild","building":"STORAGE"}]
	},
	"LOGISTICS_9": {
		"name": "Optimierte Routen", "desc": "Eingespielte Laufwege erlauben es Lagerarbeitern, in einem größeren Umkreis nach Aufgaben zu suchen.",
		"section": "LOGISTICS", "tier": 9, "cost": 140, "requires_node": "LOGISTICS_8",
		"effects": [{"type":"global","key":"warehouse_search_range_bonus","value":25.0}]
	},
	"LOGISTICS_10": {
		"name": "Meister der Logistik", "desc": "Perfekt eingespielte Abläufe beschleunigen jede Baustelle zusätzlich und lassen Frettchen mehr tragen.",
		"section": "LOGISTICS", "tier": 10, "cost": 185, "requires_node": "LOGISTICS_9",
		"effects": [{"type":"global","key":"construction_speed_bonus","value":0.25}, {"type":"global","key":"carry_capacity_bonus","value":10.0}]
	},
}

## Epochen-Aufstiege. Kosten jetzt AUSSCHLIESSLICH Wissenspunkte (siehe Nutzeranfrage).
## Zusaetzlich zum Wissenspunkte-Preis muss im angegebenen Themenbereich mindestens
## der angegebene Tier-Knoten bereits freigeschaltet sein, bevor die naechste Epoche
## ueberhaupt kaeuflich wird ("wenn man genug Wissenspunkte in einem Abschnitt
## ausgegeben hat, kann man sich fuer eine relativ grosse Anzahl Wissenspunkte die
## naechste Epoche freischalten").
const EPOCHS: Dictionary = {
	"EPOCH_1": {
		"name": "Steinzeit", "epoch": 1, "cost": 0, "requires": [], "section_req": {},
		"unlocks": ["CONSTRUCTION_YARD_1","LUMBERJACK","QUARRY","BERRY_GATHERER",
			"WELL","DAM","STORAGE","HOUSE","GATHERING_PLACE","FORESTER","GRAVEYARD",
			"DECO_FLOWERS","DECO_MUSHROOM","DECO_STONES","DECO_BUSH",
			"SAWMILL","WORKSHOP","RESEARCH_HUT"]
	},
	"EPOCH_2": {
		"name": "Mittelalter", "epoch": 2, "cost": 150, "requires": ["EPOCH_1"],
		"section_req": {"node": "FORESTRY_4"},
		"unlocks": ["CONSTRUCTION_YARD_2", "WATER_TOWER", "TAVERN", "GARDEN", "LARGE_STORAGE", "CROP_FIELD", "WATER_PUMP", "RESERVOIR", "FOOD_STORE", "WATERWHEEL", "BATHHOUSE", "EXPEDITION_CAMP", "COOKHOUSE", "DYNAMITE_WORKSHOP", "WHEAT_FARM", "HUNTER_HUT", "DECO_LANTERN"]
	},
	"EPOCH_3": {
		"name": "Industrialisierung", "epoch": 3, "cost": 400, "requires": ["EPOCH_2"],
		"section_req": {"node": "MINING_6"},
		"unlocks": ["ENGINEERS_GUILD", "IRON_MINE", "COAL_MINE", "SMELTER", "AQUEDUCT", "THEATER", "WAREHOUSE", "IRRIGATION"]
	},
	"EPOCH_4": {
		"name": "Moderne", "epoch": 4, "cost": 900, "requires": ["EPOCH_3"],
		"section_req": {"node": "LOGISTICS_8"},
		"unlocks": ["CONSTRUCTION_OFFICE", "MACHINE_FACTORY", "BLAST_FURNACE", "STATUE"]
	},
}
# ══════════════════════════════════════════════════════════════════════════════
# LAUFZEIT-ZUSTAND
# ══════════════════════════════════════════════════════════════════════════════
## Freigeschaltete Tech-Knoten-IDs (OHNE Epochen, siehe unlocked_epochs).
var unlocked: Array = []
## Freigeschaltete Epochen-IDs ("EPOCH_1".."EPOCH_4").
var unlocked_epochs: Array = []
## Wie viele Wissenspunkte insgesamt bereits in Tech-Knoten UND Epochen
## investiert wurden - rein informativ (z.B. fuer eine Fortschrittsanzeige).
var total_spent: float = 0.0

func init() -> void:
	unlocked = []
	unlocked_epochs = ["EPOCH_1"]
	total_spent = 0.0

# ══════════════════════════════════════════════════════════════════════════════
# TECH-KNOTEN FREISCHALTEN
# ══════════════════════════════════════════════════════════════════════════════
func can_unlock_node(tid: String) -> bool:
	if tid in unlocked: return false
	if not NODES.has(tid): return false
	var nd: Dictionary = NODES[tid]
	var req: String = str(nd.get("requires_node", ""))
	if req != "" and not (req in unlocked): return false
	return ResourceSys.has_science(float(nd.get("cost", 0.0)))

func unlock_node(tid: String) -> bool:
	if not can_unlock_node(tid): return false
	var nd: Dictionary = NODES[tid]
	var cost: float = float(nd.get("cost", 0.0))
	if not ResourceSys.spend_science(cost): return false
	unlocked.append(tid)
	total_spent += cost
	GameState.tech_unlocked.emit(tid)
	GameState.notify("Erforscht: " + str(nd.get("name", tid)))
	GameState.build_menu_update_requested.emit()
	return true

func is_node_unlocked(tid: String) -> bool:
	return tid in unlocked

## Wie viele Knoten eines Themenbereichs sind bereits freigeschaltet (= hoechster
## erreichter Tier). Wird fuer die Epochen-Fortschrittsvoraussetzung gebraucht.
func get_section_progress(section: String) -> int:
	var best: int = 0
	for tid in unlocked:
		if not NODES.has(tid): continue
		var nd: Dictionary = NODES[tid]
		if str(nd.get("section", "")) != section: continue
		var tier: int = int(nd.get("tier", 0))
		if tier > best: best = tier
	return best

# ══════════════════════════════════════════════════════════════════════════════
# EPOCHEN FREISCHALTEN (kosten nur noch Wissenspunkte + Sektions-Fortschritt)
# ══════════════════════════════════════════════════════════════════════════════
func get_next_epoch_id() -> String:
	for eid in ["EPOCH_1","EPOCH_2","EPOCH_3","EPOCH_4"]:
		if eid in unlocked_epochs: continue
		return eid
	return ""

## Ist die Voraussetzung ("genug in einem Abschnitt ausgegeben") fuer die
## naechste Epoche bereits erfuellt - unabhaengig davon, ob man sich die
## Wissenspunkte-Kosten selbst schon leisten kann?
func epoch_requirement_met(eid: String) -> bool:
	if not EPOCHS.has(eid): return false
	var ed: Dictionary = EPOCHS[eid]
	var sec_req: Dictionary = ed.get("section_req", {})
	if sec_req.is_empty(): return true
	var req_node: String = str(sec_req.get("node", ""))
	return req_node in unlocked

func can_unlock_epoch(eid: String) -> bool:
	if eid in unlocked_epochs: return false
	if not EPOCHS.has(eid): return false
	var ed: Dictionary = EPOCHS[eid]
	for req in ed.get("requires", []):
		if not (str(req) in unlocked_epochs): return false
	if not epoch_requirement_met(eid): return false
	return ResourceSys.has_science(float(ed.get("cost", 0.0)))

func unlock_epoch(eid: String) -> bool:
	if not can_unlock_epoch(eid): return false
	var ed: Dictionary = EPOCHS[eid]
	var cost: float = float(ed.get("cost", 0.0))
	if not ResourceSys.spend_science(cost): return false
	unlocked_epochs.append(eid)
	total_spent += cost
	GameState.tech_unlocked.emit(eid)
	GameState.notify("Epoche freigeschaltet: " + str(ed.get("name", eid)))
	GameState.build_menu_update_requested.emit()
	return true

func get_epoch() -> int:
	var max_e: int = 1
	for eid in unlocked_epochs:
		if not EPOCHS.has(eid): continue
		var e: int = int((EPOCHS[eid] as Dictionary).get("epoch", 1))
		if e > max_e: max_e = e
	return max_e

# ══════════════════════════════════════════════════════════════════════════════
# FREIGESCHALTETE GEBAEUDE (Epochen-Unlocks + einzelne Tech-Knoten mit
# "unlock"-Effekt, z.B. die Kinderstube ueber BREEDING_9)
# ══════════════════════════════════════════════════════════════════════════════
func get_unlocked_buildings() -> Array:
	var result: Array = []
	for eid in unlocked_epochs:
		if not EPOCHS.has(eid): continue
		for bid in (EPOCHS[eid] as Dictionary).get("unlocks", []):
			result.append(str(bid))
	for tid in unlocked:
		if not NODES.has(tid): continue
		for eff in (NODES[tid] as Dictionary).get("effects", []):
			var e: Dictionary = eff
			if str(e.get("type","")) == "unlock":
				result.append(str(e.get("building","")))
	return result

# ══════════════════════════════════════════════════════════════════════════════
# GEBAEUDE-STAT-BONI (angewendet in BuildingEntity.from_type()/finish_rebuild())
# ══════════════════════════════════════════════════════════════════════════════
## Wendet alle freigeschalteten "bstat"-Effekte fuer die Gebaeude-ID von b auf
## dessen bereits gesetzte Basiswerte an. "add" addiert direkt auf den Wert,
## "mult" addiert value auf einen laufenden Multiplikator (1.0 + summe), der
## am Ende auf den urspruenglichen Basiswert angewendet wird - so stapeln sich
## mehrere "mult"-Boni additiv statt sich zu potenzieren (vorhersehbarer fuer
## die Balance).
func apply_building_bonuses(b) -> void:
	var mult_sums: Dictionary = {}   # field -> summierter Multiplikator-Zuschlag
	var add_sums: Dictionary = {}    # field -> summierter Additions-Zuschlag
	for tid in unlocked:
		if not NODES.has(tid): continue
		for eff in (NODES[tid] as Dictionary).get("effects", []):
			var e: Dictionary = eff
			if str(e.get("type","")) != "bstat": continue
			if str(e.get("building","")) != b.id: continue
			var field: String = str(e.get("field",""))
			var mode: String = str(e.get("mode","add"))
			var value: float = float(e.get("value", 0.0))
			if mode == "mult":
				mult_sums[field] = float(mult_sums.get(field, 0.0)) + value
			else:
				add_sums[field] = float(add_sums.get(field, 0.0)) + value
	var fields: Array = ["production_speed","collection_radius","planting_radius",
		"storage_capacity","water_capacity","max_residents","max_workers",
		"local_storage_capacity","happiness_bonus"]
	for field in fields:
		var has_mult: bool = mult_sums.has(field)
		var has_add: bool = add_sums.has(field)
		if not has_mult and not has_add: continue
		var base_val: float = float(b.get(field))
		var new_val: float = base_val
		if has_mult:
			new_val = base_val * (1.0 + float(mult_sums[field]))
		if has_add:
			new_val += float(add_sums[field])
		if field in ["collection_radius","planting_radius","max_residents","max_workers"]:
			b.set(field, int(round(new_val)))
		else:
			b.set(field, new_val)

# ══════════════════════════════════════════════════════════════════════════════
# GLOBALE, PERMANENTE BONI (abgefragt von PopulationManager/FerretEntity/
# WaterSystem/DayNightSystem/GameController/BuildingSystem an der jeweiligen
# Wirkstelle). Bekannte Keys:
#   carry_capacity_bonus, move_speed_bonus, construction_speed_bonus,
#   needs_decay_reduction, hunger_decay_reduction, waterwheel_boost_bonus,
#   dam_retention_bonus, drought_evaporation_reduction, homeless_penalty_reduction,
#   growth_happiness_threshold_reduction, warehouse_search_range_bonus,
#   health_regen_bonus, growth_rate_bonus, mortality_reduction,
#   day_length_extend, wood_regen_speed, newborn_health_bonus
# ══════════════════════════════════════════════════════════════════════════════
func get_global_bonus(key: String) -> float:
	var total: float = 0.0
	for tid in unlocked:
		if not NODES.has(tid): continue
		for eff in (NODES[tid] as Dictionary).get("effects", []):
			var e: Dictionary = eff
			if str(e.get("type","")) == "global" and str(e.get("key","")) == key:
				total += float(e.get("value", 0.0))
	return total

# ══════════════════════════════════════════════════════════════════════════════
# GEBAEUDE-UMBAU (Rebuild) - Nachschlagen, ob/wofuer ein Gebaeudetyp umgebaut
# werden kann. Die eigentlichen Umbau-Daten (Ziel-Gebaeude, Kosten, Bauzeit)
# stehen in BuildingData.REBUILDS; hier wird nur geprueft, ob der dafuer
# noetige Tech-Knoten bereits freigeschaltet ist.
# ══════════════════════════════════════════════════════════════════════════════
func can_rebuild(building_id: String) -> bool:
	var rd: Dictionary = BuildingData.REBUILDS.get(building_id, {})
	if rd.is_empty(): return false
	var req: String = str(rd.get("requires_tech", ""))
	return req == "" or (req in unlocked)

func get_rebuild_info(building_id: String) -> Dictionary:
	return BuildingData.REBUILDS.get(building_id, {})

# ══════════════════════════════════════════════════════════════════════════════
# SPEICHERN / LADEN
# ══════════════════════════════════════════════════════════════════════════════
func serialize() -> Dictionary:
	return {
		"unlocked": unlocked.duplicate(),
		"unlocked_epochs": unlocked_epochs.duplicate(),
		"total_spent": total_spent
	}

func deserialize(data) -> void:
	# Abwaertskompatibilitaet: alte Saves (vor diesem Feature) speicherten hier
	# ein einfaches Array aus Epochen-IDs statt eines Dictionarys.
	if data is Array:
		unlocked = []
		unlocked_epochs = []
		for tid in data:
			if str(tid).begins_with("EPOCH_"):
				unlocked_epochs.append(str(tid))
		if unlocked_epochs.is_empty(): unlocked_epochs = ["EPOCH_1"]
		total_spent = 0.0
		return
	var d: Dictionary = data as Dictionary
	unlocked = (d.get("unlocked", []) as Array).duplicate()
	unlocked_epochs = (d.get("unlocked_epochs", ["EPOCH_1"]) as Array).duplicate()
	if unlocked_epochs.is_empty(): unlocked_epochs = ["EPOCH_1"]
	total_spent = float(d.get("total_spent", 0.0))

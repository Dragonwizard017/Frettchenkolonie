## PopulationManager.gd
extends Node

var ferrets: Array = []
var dead_ferrets: Array = []
var total_happiness: float = 50.0
var growth_timer: float = 0.0
var _death_count: int = 0
var _last_death_count: int = 0

func init(start_pop: int = 5) -> void:
	ferrets = []
	dead_ferrets = []
	total_happiness = 50.0
	growth_timer = 0.0
	_death_count = 0
	_last_death_count = 0
	for _i in start_pop:
		var f: FerretEntity = FerretEntity.create_random()
		# Tile-Koordinaten: Kartenmitte = (30, 30)
		f.pos = Vector2(30.0 + randf_range(-4.0, 4.0), 30.0 + randf_range(-4.0, 4.0))
		f.target_pos = f.pos
		ferrets.append(f)

func update(dt: float, is_day: bool, world: Array = []) -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		# Feature (v11.9, Legendäre Frettchen): Uebergang false→true erkennen,
		# um GENAU einmal zu benachrichtigen (kein separates "announced"-Flag
		# noetig - is_legendary ist einmal wahr fuer immer wahr, siehe
		# FerretEntity.update()/deserialize()).
		var was_legendary: bool = fe.is_legendary
		fe.update(dt, world, is_day)
		if fe.is_legendary and not was_legendary:
			GameState.ferret_became_legendary.emit(fe)
	if not world.is_empty():
		WorldGenerator.tick_resource_nodes(world, dt)

	# Nahrung konsumieren
	# Bug-Fix (Frettchen sterben viel zu schnell): FerretEntity.update() lässt
	# needs["food"] mit -0.8/Sek und needs["water"] mit -1.1/Sek verfallen.
	# Die bisherigen Konsum-Konstanten (0.01 bzw. 0.018) ergaben selbst mit
	# vollen Lagern nur ca. +0.05-0.08 Nahrung/Sek und +0.07 Wasser/Sek -
	# zehn- bis fünfzehnmal zu wenig, um den Verfall jemals auszugleichen.
	# Frettchen sind dadurch unabhängig vom Spielerverhalten innerhalb
	# weniger Minuten verhungert/verdurstet. Jetzt großzügig genug bemessen,
	# damit ausreichende Produktion den Bedarf tatsächlich decken kann.
	if not ferrets.is_empty():
		var eat_options: Array = [
			{"r": "STEW",        "eff": 8.0},
			{"r": "COOKED_MEAT", "eff": 6.0},
			{"r": "BREAD",       "eff": 5.0},
			{"r": "FOOD",        "eff": 5.0},
			{"r": "BERRIES",     "eff": 3.0},
			{"r": "MEAT",        "eff": 2.0}
		]
		for opt in eat_options:
			var opt_d: Dictionary = opt
			var res: String = str(opt_d["r"])
			var eff: float = float(opt_d["eff"])
			var avail: float = float(ResourceSys.resources.get(res, 0.0))
			if avail < 0.5: continue
			var consume: float = minf(avail, float(ferrets.size()) * 0.4 * dt)
			ResourceSys.remove(res, consume)
			var per_f: float = (consume / float(ferrets.size())) * eff
			for fv in ferrets:
				var fe: FerretEntity = fv
				fe.needs["food"] = minf(100.0, float(fe.needs["food"]) + per_f)
			break

		# Wasser
		var w_avail: float = ResourceSys.water
		if w_avail > 0.0:
			var consume: float = minf(w_avail, float(ferrets.size()) * 0.6 * dt)
			ResourceSys.remove_water(consume)
			var per_f: float = (consume / float(ferrets.size())) * 4.0
			for fv in ferrets:
				var fe: FerretEntity = fv
				fe.needs["water"] = minf(100.0, float(fe.needs["water"]) + per_f)

	_apply_happiness_bonuses(dt)
	_calculate_happiness()
	if is_day:
		_assign_work()
	_assign_homes()

	# Tote entfernen
	var prev_size: int = ferrets.size()
	var to_die: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.health <= 0.0: to_die.append(fe)
	for f in to_die:
		_kill_ferret(f, "Hunger/Durst")
	var alive: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.health > 0.0: alive.append(fe)
	ferrets = alive

	if ferrets.size() < prev_size:
		_death_count += prev_size - ferrets.size()
	if _death_count != _last_death_count:
		SoundSys.play_death()
		_last_death_count = _death_count

	growth_timer += dt
	# Feature (Tech Tree): "Meister der Zucht" (BREEDING) verkuerzt das
	# Intervall zwischen zwei Wachstumsversuchen - die Kolonie waechst dadurch
	# spuerbar schneller.
	var growth_interval: float = 90.0 / (1.0 + TechTreeSys.get_global_bonus("growth_rate_bonus"))
	if growth_timer > growth_interval and is_day:
		growth_timer = 0.0
		_try_grow()

	if ferrets.is_empty() and dead_ferrets.size() > 0:
		GameState.game_over_triggered.emit("Alle Frettchen sind gestorben!")

## Bug-Fix (v10.16): "Frettchen vermehren sich nicht" - Gebaeude mit
## happiness_bonus/happiness_radius (Versammlungsplatz, Taverne, Wohnhaus,
## Statue, etc.) lasen ihre Werte zwar aus BuildingData.gd in BuildingEntity
## ein, wurden aber NIRGENDS tatsaechlich auf needs["happiness"] angewendet.
## Dieser Bedarf sank seit Spielstart nur noch (-0.4/Sek, FerretEntity.gd)
## und erreichte nach 100-175 Sek. dauerhaft 0, ohne je wieder zu steigen.
## Da total_happiness der Durchschnitt aus food/water/happiness ist
## (_calculate_happiness), blieb die Kolonie dadurch praktisch immer unter
## der 50%-Wachstumsschwelle in _try_grow() - die Bevoelkerung konnte kaum
## je wachsen, unabhaengig von Nahrungsversorgung. Jetzt erhalten Frettchen
## im happiness_radius eines fertigen Gebaeudes kontinuierlich
## happiness_bonus * 0.08 Punkte/Sek (z.B. Wohnhaus mit Bonus 5: +0.4/Sek,
## gleicht die Abklingrate genau aus; Versammlungsplatz/Taverne mit
## Bonus 8-15: deutlicher Ueberschuss in ihrer Reichweite).
func _apply_happiness_bonuses(dt: float) -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		for b in BuildingSys.buildings:
			var be: BuildingEntity = b
			if be.is_under_construction or be.happiness_bonus <= 0.0: continue
			var dx: float = fe.pos.x - float(be.tile_x)
			var dy: float = fe.pos.y - float(be.tile_y)
			if dx * dx + dy * dy <= be.happiness_radius * be.happiness_radius:
				# Feature (v11.8, Frettchen-Persoenlichkeiten): "Glueckspilz"
				# profitiert deutlich mehr von Gluecklichkeits-Gebaeuden,
				# "Eigenbroetler" deutlich weniger (siehe FerretEntity.
				# get_happiness_bonus_multiplier()).
				var trait_mult: float = fe.get_happiness_bonus_multiplier()
				fe.needs["happiness"] = minf(100.0, float(fe.needs["happiness"]) + be.happiness_bonus * 0.08 * dt * trait_mult)

## Feature (v10.13): bisher bekamen NUR neu geborene Frettchen (_try_grow())
## ein Haus zugewiesen. Die Start-Population (und Frettchen, deren Haus
## abgerissen/verkauft wurde) blieb dauerhaft heimatlos und musste laut
## Spielwunsch dann naechtlich "auf dem Boden schlafen" - das ist als
## Fallback so gewollt, aber sobald ein freies Bett verfuegbar ist, soll es
## auch tatsaechlich vergeben werden. Wird jeden Frame aufgerufen, ist aber
## fuer Frettchen mit Haus ein reines No-Op (continue sofort).
func _assign_homes() -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.home != null: continue
		for b in BuildingSys.buildings:
			var be: BuildingEntity = b
			if be.btype != "HOUSING" or be.is_under_construction: continue
			if be.residents.size() < be.max_residents:
				be.residents.append(fe)
				fe.home = be
				break

func _kill_ferret(f: FerretEntity, cause: String) -> void:
	f.is_alive = false
	if f.assigned_building != null:
		var ab: BuildingEntity = f.assigned_building
		ab.remove_worker(f)
	if f.home != null:
		var hb: BuildingEntity = f.home
		hb.residents.erase(f)
	var entry: Dictionary = {
		"name": f.ferret_name, "cause": cause,
		"day": DayNight.day_count, "age": int(f.age_days)
	}
	# Feature (v11.9, Legendäre Frettchen): prominenterer Eintrag mit
	# Titel + kurzer Karriere-Zusammenfassung statt nur Name/Tag/Ursache.
	if f.is_legendary:
		entry["is_legendary"] = true
		entry["legendary_title"] = f.legendary_title
		entry["career_days"] = int(f.career_days)
	dead_ferrets.append(entry)
	GameState.ferret_died.emit(f, cause)

func _calculate_happiness() -> void:
	if ferrets.is_empty():
		total_happiness = 50.0; return
	var base: float = 0.0
	for f in ferrets:
		var fe: FerretEntity = f
		base += (float(fe.needs["food"]) + float(fe.needs["water"]) + float(fe.needs["happiness"])) / 3.0
	total_happiness = base / float(ferrets.size())

## Vom Spieler über die Gebäude-UI ("+"-Button) aufgerufen: weist sofort ein
## freies Frettchen der Kolonie diesem Gebäude zu, falls eines verfügbar ist
## und noch ein Arbeitsplatz frei ist.
func try_fill_building(b: BuildingEntity) -> bool:
	if b.assigned_workers.size() >= b.get_effective_worker_cap(): return false
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.assigned_building == null and fe.current_construction_site == null:
			return b.assign_worker(fe)
	return false

func _assign_work() -> void:
	for f in ferrets:
		var fe: FerretEntity = f
		if fe.assigned_building != null: continue
		if fe.current_construction_site != null: continue
		var best: BuildingEntity = null
		var best_pri: int = -1
		for b in BuildingSys.buildings:
			var be: BuildingEntity = b
			if be.is_under_construction: continue
			if be.btype in ["STORAGE","HAPPINESS","DECO","GRAVEYARD","HOUSING"]: continue
			if be.assigned_workers.size() >= be.get_effective_worker_cap(): continue
			if be.work_priority > best_pri:
				best_pri = be.work_priority
				best = be
		if best != null:
			best.assign_worker(fe)

func _try_grow() -> void:
	var free_beds: int = BuildingSys.get_total_beds() - BuildingSys.get_occupied_beds()
	if free_beds <= 0: return
	var has_food: bool = (
		float(ResourceSys.resources.get("FOOD", 0.0)) > 5.0 or
		float(ResourceSys.resources.get("BERRIES", 0.0)) > 15.0 or
		float(ResourceSys.resources.get("STEW", 0.0)) > 2.0 or
		float(ResourceSys.resources.get("BREAD", 0.0)) > 3.0 or
		float(ResourceSys.resources.get("COOKED_MEAT", 0.0)) > 3.0
	)
	if not has_food: return
	# Feature (Tech Tree): "Familienplanung" (BREEDING) senkt die noetige
	# Glueckschwelle fuer Nachwuchs; "Meister der Zucht" beschleunigt das
	# Wachstum zusaetzlich per Wahrscheinlichkeits-Bonus pro Aufruf.
	var threshold: float = 50.0 - TechTreeSys.get_global_bonus("growth_happiness_threshold_reduction")
	if total_happiness < threshold: return
	var f: FerretEntity = FerretEntity.create_random()
	# Feature (Tech Tree): "Ammenpflege" (BREEDING) gibt neugeborenen
	# Frettchen einen Gesundheits-Vorsprung.
	f.health = minf(100.0, f.health + TechTreeSys.get_global_bonus("newborn_health_bonus"))
	for b in BuildingSys.buildings:
		var be: BuildingEntity = b
		if be.btype == "HOUSING" and not be.is_under_construction:
			if be.residents.size() < be.max_residents:
				be.residents.append(f)
				f.home = be; break
	ferrets.append(f)
	GameState.ferret_born.emit(f)
	SoundSys.play_born()
	GameState.notify("Ein neues Frettchen ist geboren!")

func get_count() -> int:
	return ferrets.size()

func serialize() -> Dictionary:
	var f_data: Array = []
	for f in ferrets:
		var fe: FerretEntity = f
		f_data.append(fe.serialize())
	return {"ferrets": f_data, "dead": dead_ferrets.duplicate(true)}

func deserialize(data: Dictionary) -> void:
	ferrets = []
	var dead = data.get("dead", [])
	dead_ferrets = (dead as Array).duplicate(true)
	var flist = data.get("ferrets", [])
	for fd in flist:
		ferrets.append(FerretEntity.deserialize(fd as Dictionary))

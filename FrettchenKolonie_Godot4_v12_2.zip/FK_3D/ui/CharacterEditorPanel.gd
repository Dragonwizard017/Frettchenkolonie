## CharacterEditorPanel.gd
## Feature (v12.2, Phase 4 - Frettchen-Ich-Anpassung). Charakter-Editor im
## Pause-Menue: zeigt eine LIVE rotierende 3D-Vorschau des Frettchen-Ich
## (eigenes, isoliertes SubViewport mit eigenem World3D/Licht/Kamera - siehe
## "Minecraft-Skin-Editor"-Anfrage) und pro Slot (HEAD/NECK/FACE/BACK) eine
## Auswahl mit Links/Rechts-Pfeilen ueber alle FREIGESCHALTETEN Accessoires
## dieses Slots (siehe PlayerAccessories.gd). Baut seine UI komplett dynamisch
## in _refresh() selbst auf, analog zu AchievementPanel.gd - Main.gd erzeugt
## nur den leeren PanelContainer mit diesem Skript.
extends PanelContainer

const SLOT_ORDER: Array = ["HEAD", "NECK", "FACE", "BACK"]
const SLOT_NAMES: Dictionary = {"HEAD": "Kopf", "NECK": "Hals", "FACE": "Gesicht", "BACK": "Rücken"}
const PREVIEW_SIZE: Vector2i = Vector2i(280, 220)
const ROTATE_SPEED: float = 0.6  # rad/Sek

var _preview_model: Node3D = null
var _sub_viewport: SubViewport = null

func _ready() -> void:
	hide()

func open() -> void:
	show(); _refresh()

func _process(delta: float) -> void:
	if not visible or _preview_model == null: return
	_preview_model.rotation.y += delta * ROTATE_SPEED

func _refresh() -> void:
	for c in get_children(): c.queue_free()
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8); add_child(vb)

	var hdr := HBoxContainer.new(); vb.add_child(hdr)
	var tl := Label.new()
	tl.text = "🎨 Charakter-Editor"
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 15)
	tl.add_theme_color_override("font_color", Color(0.96, 0.78, 0.25))
	hdr.add_child(tl)
	var cb := Button.new(); cb.text = "X"; cb.pressed.connect(hide); hdr.add_child(cb)
	vb.add_child(HSeparator.new())

	# ── Live-3D-Vorschau ──────────────────────────────────────────────────
	var svc := SubViewportContainer.new()
	svc.custom_minimum_size = Vector2(PREVIEW_SIZE)
	svc.stretch = true
	vb.add_child(svc)
	_sub_viewport = SubViewport.new()
	_sub_viewport.size = PREVIEW_SIZE
	_sub_viewport.own_world_3d = true  # eigene, isolierte 3D-Welt - kein Ueberlappen mit der Kolonie-Szene
	_sub_viewport.transparent_bg = true
	svc.add_child(_sub_viewport)
	_build_preview_scene(_sub_viewport)

	var hint := Label.new()
	hint.text = "Dreht sich automatisch – ausgeruestete Accessoires siehst du hier direkt."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 10)
	hint.add_theme_color_override("font_color", Color(0.55, 0.55, 0.55))
	vb.add_child(hint)
	vb.add_child(HSeparator.new())

	# ── Slot-Reihen ───────────────────────────────────────────────────────
	var sc := ScrollContainer.new(); sc.custom_minimum_size = Vector2(0, 210); vb.add_child(sc)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 10)
	sc.add_child(inner)
	for slot in SLOT_ORDER:
		inner.add_child(_build_slot_row(slot))

func _build_preview_scene(sv: SubViewport) -> void:
	var cam := Camera3D.new()
	cam.position = Vector3(0.0, 0.85, 1.9)
	cam.look_at(Vector3(0.0, 0.55, 0.0), Vector3.UP)
	cam.fov = 45.0
	sv.add_child(cam)

	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(deg_to_rad(-50.0), deg_to_rad(-30.0), 0.0)
	sun.light_energy = 1.1
	sv.add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation = Vector3(deg_to_rad(-20.0), deg_to_rad(150.0), 0.0)
	fill.light_energy = 0.4
	sv.add_child(fill)

	# Feature (v12.2): dieselbe Bau-Logik wie PlayerController.gd
	# (_apply_player_tint() + refresh_accessories()) - EIGENE, unabhaengige
	# Instanz, damit die Vorschau nicht am tatsaechlichen Spieler-Node haengt
	# (der z.B. gerade unsichtbar im First-Person-Modus stecken koennte).
	_preview_model = PlayerController.FERRET_SCENE.instantiate() as Node3D
	_preview_model.scale = Vector3.ONE * PlayerController.FERRET_MODEL_SCALE
	_tint_recursive(_preview_model)
	sv.add_child(_preview_model)
	_equip_recursive_refresh()

## Faerbt die Vorschau exakt wie das echte Frettchen-Ich (siehe
## PlayerController._apply_player_tint() - bewusst dieselbe Logik dupliziert
## statt eine Instanz-Methode auf dem echten Spieler-Node aufzurufen, da die
## Vorschau ein voellig unabhaengiges Preview-Modell ist).
func _tint_recursive(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		if mi.mesh:
			for i in mi.mesh.get_surface_count():
				var src_mat: Material = mi.get_active_material(i)
				var new_mat: Material = (src_mat.duplicate() as Material) if src_mat else StandardMaterial3D.new()
				if new_mat is BaseMaterial3D:
					(new_mat as BaseMaterial3D).albedo_color *= PlayerController.PLAYER_TINT
				mi.set_surface_override_material(i, new_mat)
	for c in n.get_children():
		_tint_recursive(c)

func _equip_recursive_refresh() -> void:
	if _preview_model == null: return
	for c in _preview_model.get_children():
		if str(c.name).begins_with("AccessoryItem_"): c.queue_free()
	for slot in PlayerAccessories.equipped:
		var aid: String = str(PlayerAccessories.equipped[slot])
		if aid == "": continue
		var ad: Dictionary = FerretAccessories.get_accessory(aid)
		if ad.is_empty(): continue
		var scene: PackedScene = load(str(ad.get("glb", "")))
		if scene == null: continue
		var inst := scene.instantiate() as Node3D
		if inst == null: continue
		inst.name = "AccessoryItem_" + aid
		inst.position = ad.get("offset", Vector3.ZERO) as Vector3
		inst.rotation.x = float(ad.get("rot_x", 0.0))
		inst.rotation.y = float(ad.get("rot_y", 0.0))
		_preview_model.add_child(inst)

func _build_slot_row(slot: String) -> Control:
	var options: Array = []  # Array[String], "" = "leer"
	options.append("")
	for aid in FerretAccessories.ACCESSORIES:
		var ad: Dictionary = FerretAccessories.ACCESSORIES[aid]
		if str(ad.get("slot", "")) == slot and PlayerAccessories.is_unlocked(aid):
			options.append(aid)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	box.add_child(row)

	var slot_lbl := Label.new()
	slot_lbl.text = str(SLOT_NAMES.get(slot, slot))
	slot_lbl.custom_minimum_size = Vector2(52, 0)
	slot_lbl.add_theme_font_size_override("font_size", 12)
	slot_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	row.add_child(slot_lbl)

	var prev_btn := Button.new(); prev_btn.text = "◀"; prev_btn.custom_minimum_size = Vector2(28, 28)
	row.add_child(prev_btn)

	var name_lbl := Label.new()
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_font_size_override("font_size", 12)
	row.add_child(name_lbl)

	var next_btn := Button.new(); next_btn.text = "▶"; next_btn.custom_minimum_size = Vector2(28, 28)
	row.add_child(next_btn)

	var count_lbl := Label.new()
	var unlocked_count: int = options.size() - 1
	var total_count: int = 0
	for aid2 in FerretAccessories.ACCESSORIES:
		if str((FerretAccessories.ACCESSORIES[aid2] as Dictionary).get("slot", "")) == slot: total_count += 1
	count_lbl.text = "%d/%d freigeschaltet" % [unlocked_count, total_count]
	count_lbl.add_theme_font_size_override("font_size", 9)
	count_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	count_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(count_lbl)

	var current_id: String = str(PlayerAccessories.equipped.get(slot, ""))
	var current_idx: int = options.find(current_id)
	if current_idx < 0: current_idx = 0

	var refresh_label := func():
		var aid: String = options[current_idx]
		if aid == "":
			name_lbl.text = "— leer —"
			name_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		else:
			var ad: Dictionary = FerretAccessories.get_accessory(aid)
			name_lbl.text = str(ad.get("name", aid))
			name_lbl.add_theme_color_override("font_color", Color(0.95, 0.85, 0.4))
	refresh_label.call()

	var apply_selection := func():
		var aid: String = options[current_idx]
		if aid == "":
			PlayerAccessories.unequip_slot(slot)
		else:
			PlayerAccessories.equip(aid)
		_equip_recursive_refresh()

	prev_btn.pressed.connect(func():
		if options.size() <= 1: return
		current_idx = (current_idx - 1 + options.size()) % options.size()
		refresh_label.call(); apply_selection.call()
	)
	next_btn.pressed.connect(func():
		if options.size() <= 1: return
		current_idx = (current_idx + 1) % options.size()
		refresh_label.call(); apply_selection.call()
	)
	if options.size() <= 1:
		prev_btn.disabled = true; next_btn.disabled = true

	return box

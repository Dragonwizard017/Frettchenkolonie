## DevToolsPanel.gd
## Feature (v11.10, Dev Mode): kompaktes Werkzeug-Panel, das NUR sichtbar ist,
## wenn DevMode.enabled true ist (siehe DevMode.gd, Aktivierung per Passwort
## in den Einstellungen). Bündelt allgemeine Test-Aktionen; spezifischere
## Dev-Werkzeuge sitzen direkt dort, wo sie kontextuell hingehören (z.B. der
## "Sofort legendär machen"-Button im FerretProfilePanel.gd, statt hier eine
## Frettchen-Auswahl nachzubauen).
extends PanelContainer

func _ready() -> void:
	DevMode.dev_mode_changed.connect(func(_e): _refresh())
	_refresh()

func _refresh() -> void:
	visible = DevMode.enabled
	if not visible: return
	for c in get_children(): c.queue_free()

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.14, 0.08, 0.94)
	sb.border_color = Color(0.35, 0.85, 0.4)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 10; sb.content_margin_right = 10
	sb.content_margin_top = 8;   sb.content_margin_bottom = 8
	add_theme_stylebox_override("panel", sb)

	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 4); add_child(vb)
	var tl := Label.new(); tl.text = "🛠️ Dev Tools"
	tl.add_theme_font_size_override("font_size", 13)
	tl.add_theme_color_override("font_color", Color(0.5, 0.95, 0.55))
	vb.add_child(tl)

	_add_btn(vb, "+500 Holz/Stein/Nahrung/Wasser", func():
		for res in ["WOOD", "STONE", "FOOD", "WATER"]:
			ResourceSys.add(res, 500.0)
		GameState.notify("🛠️ +500 Grundressourcen"))

	_add_btn(vb, "+200 Wissenspunkte", func():
		ResourceSys.science += 200.0
		GameState.notify("🛠️ +200 Wissenspunkte"))

	_add_btn(vb, "Nächste Epoche gratis freischalten", func():
		var next_id: String = TechTreeSys.get_next_epoch_id()
		if next_id == "":
			GameState.notify("🛠️ Höchste Epoche bereits erreicht.")
			return
		if not TechTreeSys.unlocked_epochs.has(next_id):
			TechTreeSys.unlocked_epochs.append(next_id)
			GameState.tech_unlocked.emit(next_id)
			GameState.notify("🛠️ Epoche freigeschaltet: " + next_id))

	_add_btn(vb, "Alle Achievements freischalten", func():
		for aid in AchievementSys.ACHIEVEMENTS:
			if not AchievementSys.is_unlocked(aid):
				AchievementSys.unlocked.append(aid)
		GameState.notify("🛠️ Alle Achievements freigeschaltet"))

	_add_btn(vb, "Dev Mode ausschalten", func(): DevMode.disable())

func _add_btn(vb: VBoxContainer, text: String, cb: Callable) -> void:
	var btn := Button.new(); btn.text = text
	btn.add_theme_font_size_override("font_size", 10)
	btn.pressed.connect(cb)
	vb.add_child(btn)

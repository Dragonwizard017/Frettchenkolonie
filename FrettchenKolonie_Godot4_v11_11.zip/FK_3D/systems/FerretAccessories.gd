## FerretAccessories.gd
## Feature (v11.9, Legendäre Frettchen - Accessoires). Reine Datenquelle nach
## demselben Muster wie FerretTraits.gd: const-Dictionary + statische
## Hilfsfunktionen, kein Autoload noetig (kein Laufzeit-Zustand).
##
## 10 Accessoires (siehe assets/accessories/*.glb, generiert per trimesh -
## Details siehe General.md) verteilt auf 4 Slots (HEAD/NECK/FACE/BACK).
## "Kombinierbar" heisst hier: pro Slot maximal EIN Accessoire (sonst wuerden
## sich z.B. zwei Kopfbedeckungen visuell ueberlagern), aber die Slots werden
## unabhaengig voneinander gewuerfelt - ein legendaeres Frettchen kann also
## z.B. gleichzeitig Krone (HEAD) + Schal (NECK) + Monokel (FACE) + Umhang
## (BACK) tragen. Siehe pick_random_set() fuer die Zusammenstellung.
extends RefCounted
class_name FerretAccessories

const SLOTS: Array = ["HEAD", "NECK", "FACE", "BACK"]

## "offset"/"rot_y" sind lokale Transform-Werte relativ zum AccessoryAnchor-
## Node (siehe WorldRenderer3D._attach_ferret_accessories() - ein Kind-Node
## des Frettchens, das den 2.2x-Modell-Scale wieder herausrechnet, damit
## diese Werte direkt in Metern gelten). Grobe Schaetzung der Anhaltspunkte
## am Frettchen-Koerper (Kopf vorne/oben, Hals mittig, Ruecken hinten/oben) -
## ohne Skelett-Bones im ferret.glb ist das der pragmatischste Ansatz.
const ACCESSORIES: Dictionary = {
	"CROWN":     {"name": "Krone",         "slot": "HEAD", "glb": "res://assets/accessories/crown.glb",      "offset": Vector3(0.0, 0.30, 0.10), "rot_y": 0.0},
	"TOP_HAT":   {"name": "Zylinder",      "slot": "HEAD", "glb": "res://assets/accessories/top_hat.glb",    "offset": Vector3(0.0, 0.30, 0.10), "rot_y": 0.0},
	"WIZARD_HAT":{"name": "Zauberhut",     "slot": "HEAD", "glb": "res://assets/accessories/wizard_hat.glb", "offset": Vector3(0.0, 0.28, 0.10), "rot_y": 0.0},
	"BANDANA":   {"name": "Bandana",       "slot": "HEAD", "glb": "res://assets/accessories/bandana.glb",    "offset": Vector3(0.0, 0.26, 0.11), "rot_y": 0.0},
	"BOWTIE":    {"name": "Fliege",        "slot": "NECK", "glb": "res://assets/accessories/bowtie.glb",     "offset": Vector3(0.0, 0.20, 0.14), "rot_y": 0.0},
	"SCARF":     {"name": "Schal",         "slot": "NECK", "glb": "res://assets/accessories/scarf.glb",      "offset": Vector3(0.0, 0.19, 0.13), "rot_y": 0.0},
	"MEDAL":     {"name": "Medaille",      "slot": "NECK", "glb": "res://assets/accessories/medal.glb",      "offset": Vector3(0.0, 0.17, 0.14), "rot_y": 0.0},
	"MONOCLE":   {"name": "Monokel",       "slot": "FACE", "glb": "res://assets/accessories/monocle.glb",    "offset": Vector3(0.04, 0.25, 0.14), "rot_y": 0.0},
	"EYEPATCH":  {"name": "Augenklappe",   "slot": "FACE", "glb": "res://assets/accessories/eyepatch.glb",   "offset": Vector3(-0.04, 0.25, 0.14), "rot_y": 0.0},
	"CAPE":      {"name": "Umhang",        "slot": "BACK", "glb": "res://assets/accessories/cape.glb",       "offset": Vector3(0.0, 0.22, -0.10), "rot_y": PI},
}

## Wuerfelt pro Slot unabhaengig (70% Chance auf ein Accessoire in diesem
## Slot, davon gleichverteilt eines der Slot-Optionen) - liefert ein
## individuelles Set (Array von Accessoire-IDs) fuer ein neu legendaer
## gewordenes Frettchen. Mindestens 1 Accessoire garantiert, damit kein
## legendaeres Frettchen komplett "leer" bleibt.
static func pick_random_set() -> Array:
	var by_slot: Dictionary = {}
	for aid in ACCESSORIES:
		var slot: String = str((ACCESSORIES[aid] as Dictionary).get("slot", ""))
		if not by_slot.has(slot): by_slot[slot] = []
		(by_slot[slot] as Array).append(aid)

	var result: Array = []
	for slot in SLOTS:
		if randf() < 0.7:
			var options: Array = by_slot.get(slot, [])
			if not options.is_empty():
				result.append(options[randi() % options.size()])

	if result.is_empty():
		var all_slots: Array = SLOTS.duplicate()
		all_slots.shuffle()
		var fallback: Array = by_slot.get(all_slots[0], [])
		if not fallback.is_empty(): result.append(fallback[randi() % fallback.size()])
	return result

static func get_accessory(aid: String) -> Dictionary:
	return ACCESSORIES.get(aid, {})

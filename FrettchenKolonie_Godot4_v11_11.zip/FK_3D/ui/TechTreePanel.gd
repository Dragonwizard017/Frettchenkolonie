## TechTreePanel.gd
## Feature (v11.10, Skilltree-Redesign): UI-Layout jetzt an der vom Nutzer
## vorgegebenen Referenz (Legends of Aethereus "Skill Tree" - Screenshot)
## orientiert: pro Themenbereich (siehe TechTreeSys.SECTION_ORDER) eine
## HORIZONTALE Reihe aus quadratischen Knoten-Zellen, die durch dünne
## Verbindungslinien aneinandergereiht sind, statt der vorherigen simplen
## vertikalen Liste. Eigene Illustrationen/Rahmen-Grafiken wie im Referenzbild
## gibt es nicht - die Struktur (Zeilen-pro-Kategorie, verbundene quadratische
## Zellen, Status per Rahmenfarbe) ist der zentrale Stilaspekt, der uebernommen
## wurde, gerendert mit einfachen StyleBoxFlat-Rahmen statt Artwork.
##
## Anders als im Referenzbild ist unser System kein "Punkte verteilen dann
## Confirm/Undo"-Modell, sondern schaltet Knoten SOFORT gegen Wissenspunkte
## frei (siehe TechTreeSys.unlock_node()) - Undo/Confirm-Buttons entfallen
## daher bewusst, die "Wissenspunkte"-Anzeige im Kopfbereich uebernimmt die
## Rolle der "POINTS LEFT"-Anzeige aus der Referenz.
##
## Baut seine komplette UI dynamisch in _refresh() selbst auf (Muster wie
## ExpeditionPanel.gd/GraveyardPanel.gd).
extends PanelContainer

var _current_epoch: int = 1
var _selected_node_id: String = ""

const CELL_SIZE := 52.0
const COL_LOCKED := Color(0.28, 0.28, 0.3)
const COL_LOCKED_BORDER := Color(0.4, 0.4, 0.42)
const COL_AVAILABLE := Color(0.32, 0.26, 0.08)
const COL_AVAILABLE_BORDER := Color(0.96, 0.78, 0.25)
const COL_UNLOCKED := Color(0.1, 0.28, 0.14)
const COL_UNLOCKED_BORDER := Color(0.45, 0.9, 0.5)
const COL_CONNECTOR_ACTIVE := Color(0.85, 0.7, 0.3)
const COL_CONNECTOR_INACTIVE := Color(0.35, 0.35, 0.38)

func _ready() -> void:
	hide()
	GameState.tech_unlocked.connect(func(_id): if visible: _refresh())
	GameState.hud_update_requested.connect(func(): if visible: _refresh())

func open() -> void:
	_current_epoch = TechTreeSys.get_epoch()
	show(); _refresh()

func _refresh() -> void:
	for c in get_children(): c.queue_free()

	# ── Kopfleiste im Stil der Referenz: dunkler Rahmen, goldener Titel,
	# Wissenspunkte anstelle von "POINTS LEFT" ─────────────────────────────
	var header_sb := StyleBoxFlat.new()
	header_sb.bg_color = Color(0.08, 0.08, 0.1, 0.97)
	header_sb.border_color = Color(0.7, 0.58, 0.22)
	header_sb.set_border_width_all(2)
	header_sb.set_corner_radius_all(8)
	header_sb.content_margin_left = 12; header_sb.content_margin_right = 12
	header_sb.content_margin_top = 8;   header_sb.content_margin_bottom = 8
	add_theme_stylebox_override("panel", header_sb)

	var outer := VBoxContainer.new(); outer.add_theme_constant_override("separation", 6); add_child(outer)

	var hdr := HBoxContainer.new(); outer.add_child(hdr)
	var tl := Label.new()
	tl.text = "🔬 TECH TREE"
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 17)
	tl.add_theme_color_override("font_color", Color(0.93, 0.8, 0.4))
	hdr.add_child(tl)
	var pts_lbl := Label.new()
	pts_lbl.text = "🔬 %d Wissenspunkte" % int(ResourceSys.science)
	pts_lbl.add_theme_font_size_override("font_size", 13)
	pts_lbl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.75))
	hdr.add_child(pts_lbl)
	var cb := Button.new(); cb.text = "X"; cb.custom_minimum_size = Vector2(28, 0)
	cb.pressed.connect(hide)
	hdr.add_child(cb)
	outer.add_child(HSeparator.new())

	outer.add_child(_build_epoch_progress_row())
	outer.add_child(HSeparator.new())

	# ── Epochen-Reiter ──────────────────────────────────────────────────────
	var tabs := HBoxContainer.new(); tabs.add_theme_constant_override("separation", 4)
	outer.add_child(tabs)
	var cur_unlocked_epoch: int = TechTreeSys.get_epoch()
	for e_num in range(1, 5):
		var eid: String = "EPOCH_%d" % e_num
		var ed: Dictionary = TechTreeSys.EPOCHS.get(eid, {})
		var is_unlocked_epoch: bool = eid in TechTreeSys.unlocked_epochs
		var done: int = TechTreeSys.get_epoch_unlocked_count(e_num)
		var total: int = TechTreeSys.get_node_ids_for_epoch(e_num).size()
		var tb := Button.new()
		var lock_icon: String = "" if is_unlocked_epoch else "🔒 "
		tb.text = "%s%d. %s (%d/%d)" % [lock_icon, e_num, str(ed.get("name", eid)), done, total]
		tb.add_theme_font_size_override("font_size", 11)
		tb.toggle_mode = true
		tb.button_pressed = (e_num == _current_epoch)
		if e_num == _current_epoch:
			tb.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
		elif not is_unlocked_epoch:
			tb.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		var en: int = e_num
		tb.pressed.connect(func(): _current_epoch = en; _refresh())
		tabs.add_child(tb)

	if _current_epoch > cur_unlocked_epoch:
		var hint := Label.new()
		hint.text = "🔒 Epoche %d ist noch nicht freigeschaltet – Vorschau der kommenden Upgrades." % _current_epoch
		hint.add_theme_font_size_override("font_size", 11)
		hint.add_theme_color_override("font_color", Color(0.85, 0.5, 0.3))
		outer.add_child(hint)

	# ── Skilltree-Reihen: eine horizontale, verbundene Knoten-Kette pro
	# Themenbereich - das Kernstueck des Redesigns (siehe Referenzbild) ─────
	var sc := ScrollContainer.new(); sc.custom_minimum_size = Vector2(0, 360)
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(sc)
	var list := VBoxContainer.new(); list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 14); sc.add_child(list)

	for sid in TechTreeSys.SECTION_ORDER:
		var sdata: Dictionary = TechTreeSys.SECTIONS.get(sid, {})
		var section_nodes: Array = []
		for tier in range(1, 11):
			var tid: String = "%s_%d" % [sid, tier]
			if not TechTreeSys.NODES.has(tid): continue
			if int((TechTreeSys.NODES[tid] as Dictionary).get("epoch", 1)) != _current_epoch: continue
			section_nodes.append(tid)
		if section_nodes.is_empty(): continue
		list.add_child(_build_section_row(sid, sdata, section_nodes))

	# ── Detail-Panel des zuletzt angeklickten Knotens (statt Tooltip-only,
	# da Tooltips leicht uebersehen werden) ─────────────────────────────────
	if _selected_node_id != "" and TechTreeSys.NODES.has(_selected_node_id):
		outer.add_child(HSeparator.new())
		outer.add_child(_build_detail_panel(_selected_node_id))

func _build_section_row(sid: String, sdata: Dictionary, node_ids: Array) -> Control:
	var row_vb := VBoxContainer.new(); row_vb.add_theme_constant_override("separation", 4)

	var label_row := HBoxContainer.new()
	var head := Label.new()
	head.text = "%s %s" % [str(sdata.get("icon", "")), str(sdata.get("name", sid)).to_upper()]
	head.add_theme_font_size_override("font_size", 12)
	head.add_theme_color_override("font_color", Color(0.75, 0.75, 0.8))
	label_row.add_child(head)
	row_vb.add_child(label_row)

	var chain := HBoxContainer.new(); chain.add_theme_constant_override("separation", 0)
	row_vb.add_child(chain)

	var prev_unlocked: bool = true  # Startpunkt der Kette gilt immer als "aktiv"
	for i in node_ids.size():
		var tid: String = node_ids[i]
		if i > 0:
			var connector := ColorRect.new()
			connector.custom_minimum_size = Vector2(16, 3)
			connector.color = COL_CONNECTOR_ACTIVE if prev_unlocked else COL_CONNECTOR_INACTIVE
			var conn_wrap := CenterContainer.new()
			conn_wrap.custom_minimum_size = Vector2(16, CELL_SIZE)
			conn_wrap.add_child(connector)
			chain.add_child(conn_wrap)
		chain.add_child(_build_node_cell(tid))
		prev_unlocked = TechTreeSys.is_node_unlocked(tid)

	return row_vb

func _build_node_cell(tid: String) -> Control:
	var nd: Dictionary = TechTreeSys.NODES.get(tid, {})
	var is_unlocked: bool = TechTreeSys.is_node_unlocked(tid)
	var node_epoch: int = int(nd.get("epoch", 1))
	var epoch_ok: bool = node_epoch <= TechTreeSys.get_epoch()
	var req: String = str(nd.get("requires_node", ""))
	var req_ok: bool = req == "" or TechTreeSys.is_node_unlocked(req)
	var can_unlock: bool = TechTreeSys.can_unlock_node(tid)

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(CELL_SIZE, CELL_SIZE)
	btn.flat = true
	btn.tooltip_text = "%s\n%s\nKosten: 🔬%d" % [str(nd.get("name", tid)), str(nd.get("desc", "")), int(nd.get("cost", 0.0))]

	var sb := StyleBoxFlat.new()
	sb.set_corner_radius_all(6)
	sb.set_border_width_all(2 if not is_unlocked else 3)
	if is_unlocked:
		sb.bg_color = COL_UNLOCKED; sb.border_color = COL_UNLOCKED_BORDER
	elif can_unlock:
		sb.bg_color = COL_AVAILABLE; sb.border_color = COL_AVAILABLE_BORDER
	else:
		sb.bg_color = COL_LOCKED; sb.border_color = COL_LOCKED_BORDER
	btn.add_theme_stylebox_override("normal", sb)
	btn.add_theme_stylebox_override("hover", sb)
	btn.add_theme_stylebox_override("pressed", sb)
	btn.add_theme_stylebox_override("disabled", sb)

	var content := CenterContainer.new()
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	var lbl := Label.new()
	if is_unlocked:
		lbl.text = "✅"
		lbl.add_theme_font_size_override("font_size", 16)
	elif not epoch_ok or not req_ok:
		lbl.text = "🔒"
		lbl.add_theme_font_size_override("font_size", 16)
	else:
		lbl.text = "Stufe\n%d" % int(nd.get("tier", 0))
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.add_theme_font_size_override("font_size", 10)
	lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(lbl)
	btn.add_child(content)

	var t: String = tid
	btn.pressed.connect(func():
		_selected_node_id = t
		if not is_unlocked and can_unlock:
			TechTreeSys.unlock_node(t)
		_refresh()
	)
	return btn

func _build_detail_panel(tid: String) -> Control:
	var nd: Dictionary = TechTreeSys.NODES.get(tid, {})
	var is_unlocked: bool = TechTreeSys.is_node_unlocked(tid)
	var can_unlock: bool = TechTreeSys.can_unlock_node(tid)
	var node_epoch: int = int(nd.get("epoch", 1))
	var epoch_ok: bool = node_epoch <= TechTreeSys.get_epoch()
	var req: String = str(nd.get("requires_node", ""))
	var req_ok: bool = req == "" or TechTreeSys.is_node_unlocked(req)

	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 3)
	var name_lbl := Label.new()
	name_lbl.text = "Stufe %d: %s" % [int(nd.get("tier", 0)), str(nd.get("name", tid))]
	name_lbl.add_theme_font_size_override("font_size", 13)
	name_lbl.add_theme_color_override("font_color", COL_UNLOCKED_BORDER if is_unlocked else COL_AVAILABLE_BORDER)
	vb.add_child(name_lbl)

	var desc_lbl := Label.new()
	desc_lbl.text = str(nd.get("desc", ""))
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.add_theme_font_size_override("font_size", 11)
	desc_lbl.add_theme_color_override("font_color", Color(0.75, 0.75, 0.75))
	vb.add_child(desc_lbl)

	if is_unlocked:
		var ok_lbl := Label.new(); ok_lbl.text = "✅ Bereits erforscht."
		ok_lbl.add_theme_font_size_override("font_size", 10)
		ok_lbl.add_theme_color_override("font_color", COL_UNLOCKED_BORDER)
		vb.add_child(ok_lbl)
	elif not epoch_ok:
		var lock_lbl := Label.new(); lock_lbl.text = "🔒 Benötigt Epoche %d." % node_epoch
		lock_lbl.add_theme_font_size_override("font_size", 10)
		lock_lbl.add_theme_color_override("font_color", Color(0.7, 0.35, 0.3))
		vb.add_child(lock_lbl)
	elif not req_ok:
		var req_nd: Dictionary = TechTreeSys.NODES.get(req, {})
		var lock_lbl2 := Label.new(); lock_lbl2.text = "🔒 Benötigt zuerst: %s" % str(req_nd.get("name", req))
		lock_lbl2.add_theme_font_size_override("font_size", 10)
		lock_lbl2.add_theme_color_override("font_color", Color(0.7, 0.35, 0.3))
		vb.add_child(lock_lbl2)
	else:
		var row := HBoxContainer.new(); row.add_theme_constant_override("separation", 8)
		var btn := Button.new()
		btn.text = "Erforschen (🔬%d)" % int(nd.get("cost", 0.0))
		btn.disabled = not can_unlock
		var t: String = tid
		btn.pressed.connect(func(): TechTreeSys.unlock_node(t); _refresh())
		row.add_child(btn)
		vb.add_child(row)
	return vb

func _build_epoch_progress_row() -> Control:
	var row := VBoxContainer.new(); row.add_theme_constant_override("separation", 4)
	var cur: int = TechTreeSys.get_epoch()
	var cur_name: String = str(TechTreeSys.EPOCHS.get("EPOCH_%d" % cur, {}).get("name", ""))
	var done: int = TechTreeSys.get_epoch_unlocked_count(cur)
	var total: int = TechTreeSys.get_node_ids_for_epoch(cur).size()
	var required: int = TechTreeSys.get_epoch_unlock_requirement(cur)
	var pct: int = int(round(float(done) / maxf(1.0, float(total)) * 100.0))

	var prog_lbl := Label.new()
	prog_lbl.text = "Aktuelle Epoche: %d. %s – Fortschritt %d/%d (%d%%), benötigt %d für den nächsten Aufstieg" % [
		cur, cur_name, done, total, pct, required]
	prog_lbl.add_theme_font_size_override("font_size", 12)
	prog_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	row.add_child(prog_lbl)

	var next_id: String = TechTreeSys.get_next_epoch_id()
	if next_id != "":
		var ed2: Dictionary = TechTreeSys.EPOCHS.get(next_id, {})
		var req_met: bool = TechTreeSys.epoch_requirement_met(next_id)
		if not req_met:
			var info := Label.new()
			info.text = "Noch %d weitere Knoten in Epoche %d nötig, um „%s“ freizuschalten." % [
				maxi(0, required - done), cur, str(ed2.get("name", next_id))]
			info.add_theme_font_size_override("font_size", 11)
			info.add_theme_color_override("font_color", Color(0.85, 0.5, 0.3))
			row.add_child(info)
		else:
			var btn := Button.new()
			var cost: float = float(ed2.get("cost", 0.0))
			btn.text = "Epoche freischalten: %s (🔬%d)" % [str(ed2.get("name", next_id)), int(cost)]
			btn.disabled = not TechTreeSys.can_unlock_epoch(next_id)
			btn.pressed.connect(func(): TechTreeSys.unlock_epoch(next_id); _refresh())
			row.add_child(btn)
	else:
		var maxlbl := Label.new(); maxlbl.text = "Höchste Epoche erreicht."
		maxlbl.add_theme_font_size_override("font_size", 11)
		maxlbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		row.add_child(maxlbl)
	return row

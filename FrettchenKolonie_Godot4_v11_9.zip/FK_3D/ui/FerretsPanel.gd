## FerretsPanel.gd
## Feature (v11.8, Frettchen-Persoenlichkeiten): einfaches Roster aller
## lebenden Frettchen mit Name, aktueller Spezialisierung und Trait
## (Icon + Tooltip mit Beschreibung). Ersetzt mangels 3D-Klick-Interaktion
## auf einzelne Frettchen ein vollwertiges Frettchen-Profil-Panel - siehe
## Main.gd._build_ferrets_panel().
extends PanelContainer

func _ready() -> void:
	hide()
	GameState.hud_update_requested.connect(func(): if visible: _refresh())

func open() -> void:
	show(); _refresh()

func _refresh() -> void:
	for c in get_children(): c.queue_free()
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 6); add_child(vb)

	var hdr := HBoxContainer.new(); vb.add_child(hdr)
	var tl := Label.new()
	tl.text = "Frettchen – %d" % PopMgr.ferrets.size()
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 15)
	tl.add_theme_color_override("font_color", Color(0.96, 0.69, 0.1))
	hdr.add_child(tl)
	var cb := Button.new(); cb.text = "X"; cb.pressed.connect(hide); hdr.add_child(cb)
	vb.add_child(HSeparator.new())

	var sc := ScrollContainer.new(); sc.custom_minimum_size = Vector2(0, 300); vb.add_child(sc)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 4)
	sc.add_child(inner)

	for f in PopMgr.ferrets:
		var fe: FerretEntity = f
		var row := Button.new(); row.flat = true
		# Feature (v11.9, Frettchen-Klick-Interaktion): Klick auf eine
		# Roster-Zeile oeffnet ebenfalls das Profil-Panel - dieselbe
		# Zielfunktion wie beim direkten Anklicken in der 3D-Welt.
		row.pressed.connect(func(): GameState.ferret_selected.emit(fe))
		inner.add_child(row)
		var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 8)
		hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(hb)

		var trait_data: Dictionary = fe.get_trait_data()
		var trait_lbl := Label.new()
		trait_lbl.text = ("👑" if fe.is_legendary else str(trait_data.get("icon", "❔")))
		trait_lbl.custom_minimum_size = Vector2(24, 0)
		trait_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		trait_lbl.tooltip_text = "%s: %s" % [str(trait_data.get("name", "Unbekannt")), str(trait_data.get("desc", ""))]
		hb.add_child(trait_lbl)

		var name_lbl := Label.new()
		var spec_txt: String = (" (%s)" % fe.specialization) if fe.specialization != "" else ""
		name_lbl.text = "%s%s" % [fe.ferret_name, spec_txt]
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		name_lbl.add_theme_font_size_override("font_size", 12)
		if fe.is_legendary:
			name_lbl.add_theme_color_override("font_color", Color(0.96, 0.78, 0.25))
		hb.add_child(name_lbl)

	if PopMgr.ferrets.is_empty():
		var empty := Label.new(); empty.text = "Keine lebenden Frettchen."
		empty.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5)); inner.add_child(empty)

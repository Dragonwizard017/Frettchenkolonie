## FerretProfilePanel.gd
## Feature (v11.9, Frettchen-Klick-Interaktion): oeffnet sich beim Anklicken
## eines Frettchens in der 3D-Welt (siehe WorldRenderer3D.find_ferret_at_screen_pos()
## + GameController._on_ferret_selected()). Baut seine UI dynamisch in
## _refresh() selbst auf, analog zu FerretsPanel.gd/GraveyardPanel.gd.
##
## Feature: bei einem LEGENDAEREN Frettchen (fe.is_legendary) faerbt sich der
## gesamte Panel-Rahmen golden ein (siehe _apply_style()) statt der normalen
## neutralen Farbe - deutliches visuelles Feedback zusaetzlich zum Titel/Icon.
extends PanelContainer

var _ferret: FerretEntity = null

const NORMAL_STYLE_COLOR := Color(0.13, 0.13, 0.15, 0.94)
const NORMAL_BORDER := Color(0.35, 0.35, 0.4)
const LEGENDARY_STYLE_COLOR := Color(0.20, 0.16, 0.03, 0.96)
const LEGENDARY_BORDER := Color(0.98, 0.82, 0.25)

func _ready() -> void:
	hide()
	GameState.ferret_died.connect(_on_any_ferret_died)

func show_ferret(f) -> void:
	_ferret = f as FerretEntity
	show(); _refresh()

func _process(_dt: float) -> void:
	if visible and _ferret != null: _refresh()

func _on_any_ferret_died(f, _cause: String) -> void:
	if f == _ferret: hide()

func _apply_style(legendary: bool) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = LEGENDARY_STYLE_COLOR if legendary else NORMAL_STYLE_COLOR
	sb.border_color = LEGENDARY_BORDER if legendary else NORMAL_BORDER
	sb.set_border_width_all(3 if legendary else 1)
	sb.set_corner_radius_all(10)
	sb.content_margin_left = 14; sb.content_margin_right = 14
	sb.content_margin_top = 10;  sb.content_margin_bottom = 10
	add_theme_stylebox_override("panel", sb)

func _refresh() -> void:
	if _ferret == null: return
	_apply_style(_ferret.is_legendary)
	for c in get_children(): c.queue_free()
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 6); add_child(vb)

	var hdr := HBoxContainer.new(); vb.add_child(hdr)
	var tl := Label.new()
	tl.text = ("👑 " if _ferret.is_legendary else "") + _ferret.ferret_name
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.add_theme_font_size_override("font_size", 16)
	tl.add_theme_color_override("font_color", LEGENDARY_BORDER if _ferret.is_legendary else Color(0.9, 0.9, 0.92))
	hdr.add_child(tl)
	var cb := Button.new(); cb.text = "X"; cb.pressed.connect(hide); hdr.add_child(cb)

	if _ferret.is_legendary and _ferret.legendary_title != "":
		var title_lbl := Label.new()
		title_lbl.text = _ferret.legendary_title
		title_lbl.add_theme_font_size_override("font_size", 12)
		title_lbl.add_theme_color_override("font_color", LEGENDARY_BORDER)
		vb.add_child(title_lbl)

	vb.add_child(HSeparator.new())

	var trait_data: Dictionary = _ferret.get_trait_data()
	var trait_row := HBoxContainer.new(); trait_row.add_theme_constant_override("separation", 6); vb.add_child(trait_row)
	var trait_icon := Label.new(); trait_icon.text = str(trait_data.get("icon", "❔")); trait_row.add_child(trait_icon)
	var trait_lbl := Label.new()
	trait_lbl.text = str(trait_data.get("name", "Unbekannt")) + " – " + str(trait_data.get("desc", ""))
	trait_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	trait_lbl.add_theme_font_size_override("font_size", 10)
	trait_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	trait_row.add_child(trait_lbl)

	var spec_lbl := Label.new()
	spec_lbl.text = "Beruf: %s" % (_ferret.specialization if _ferret.specialization != "" else "Ungelernt")
	spec_lbl.add_theme_font_size_override("font_size", 11)
	vb.add_child(spec_lbl)

	var age_lbl := Label.new()
	age_lbl.text = "Alter: %d Tage" % int(_ferret.age_days)
	age_lbl.add_theme_font_size_override("font_size", 11)
	vb.add_child(age_lbl)

	_add_bar(vb, "Gesundheit", _ferret.health, Color(0.8, 0.25, 0.25))
	_add_bar(vb, "Nahrung", float(_ferret.needs.get("food", 0.0)), Color(0.75, 0.55, 0.2))
	_add_bar(vb, "Wasser", float(_ferret.needs.get("water", 0.0)), Color(0.25, 0.55, 0.85))
	_add_bar(vb, "Glück", float(_ferret.needs.get("happiness", 0.0)), Color(0.35, 0.75, 0.35))

	if _ferret.is_legendary:
		vb.add_child(HSeparator.new())
		var acc_hdr := Label.new(); acc_hdr.text = "Accessoires"
		acc_hdr.add_theme_font_size_override("font_size", 11)
		acc_hdr.add_theme_color_override("font_color", LEGENDARY_BORDER)
		vb.add_child(acc_hdr)
		if _ferret.legendary_accessories.is_empty():
			var none_lbl := Label.new(); none_lbl.text = "– keine –"
			none_lbl.add_theme_font_size_override("font_size", 10)
			vb.add_child(none_lbl)
		for aid in _ferret.legendary_accessories:
			var ad: Dictionary = FerretAccessories.get_accessory(str(aid))
			var acc_lbl := Label.new()
			acc_lbl.text = "• " + str(ad.get("name", aid))
			acc_lbl.add_theme_font_size_override("font_size", 10)
			vb.add_child(acc_lbl)
	else:
		# Feature: dezenter Fortschrittshinweis Richtung "Legendär", NICHT
		# als exakte Zahl (spoilert sonst den genauen Schwellwert) - nur ein
		# Fortschrittsbalken relativ zu FerretEntity.LEGENDARY_THRESHOLD_DAYS.
		vb.add_child(HSeparator.new())
		var prog_lbl := Label.new(); prog_lbl.text = "Karriere-Fortschritt"
		prog_lbl.add_theme_font_size_override("font_size", 10)
		prog_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		vb.add_child(prog_lbl)
		var pb := ProgressBar.new()
		pb.max_value = FerretEntity.LEGENDARY_THRESHOLD_DAYS
		pb.value = _ferret.career_days
		pb.custom_minimum_size = Vector2(0, 10)
		pb.show_percentage = false
		vb.add_child(pb)

func _add_bar(vb: VBoxContainer, label: String, value: float, color: Color) -> void:
	var row := HBoxContainer.new(); row.add_theme_constant_override("separation", 6); vb.add_child(row)
	var lbl := Label.new(); lbl.text = label; lbl.custom_minimum_size = Vector2(64, 0)
	lbl.add_theme_font_size_override("font_size", 10)
	row.add_child(lbl)
	var pb := ProgressBar.new()
	pb.min_value = 0; pb.max_value = 100; pb.value = clampf(value, 0.0, 100.0)
	pb.custom_minimum_size = Vector2(140, 10); pb.show_percentage = false
	pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var fill_sb := StyleBoxFlat.new(); fill_sb.bg_color = color; fill_sb.set_corner_radius_all(3)
	pb.add_theme_stylebox_override("fill", fill_sb)
	row.add_child(pb)
